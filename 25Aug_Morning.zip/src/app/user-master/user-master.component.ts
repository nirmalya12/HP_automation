import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import {FormGroup, FormBuilder, Validators} from '@angular/forms';
import { RestApiService } from '../rest-api.service';
import { ToastrService } from 'ngx-toastr';
import { MatDialog } from '@angular/material/dialog';
import { StepperSelectionEvent } from '@angular/cdk/stepper';
import { MatStepper } from '@angular/material/stepper'; 


interface SubModule {
  submodule_name: string;
  checked:boolean
}

interface Module {
  module_name: string;
  module_id: string;
  icon?: string;
  checked : boolean;
  submodules?: SubModule[];
}


@Component({
  selector: 'app-user-master',
  templateUrl: './user-master.component.html',
  styleUrl: './user-master.component.css'
})
export class UserMasterComponent {

  profileFormGroup !: FormGroup;
  @ViewChild('formDialog') formDialog!: TemplateRef<any>;
  @ViewChild('editDialog') editDialog!: TemplateRef<any>;
  @ViewChild('filterDialog') filterDialog!: TemplateRef<any>;
  @ViewChild('deleteDialog') deleteDialog!: TemplateRef<any>;
  @ViewChild('viewDialog') viewDialog!: TemplateRef<any>;
  @ViewChild('stepper') stepper!: MatStepper;


  public selectedUserType : String = '';
  public selectedUserName : String = '';
  public finalUserName : String = '';
  public finalPassword : String = '';
  public pre_user_name : String = '';
  public pre_user_type : String = '';
  public row_id : String = '';
  public currentTime : string = "";
  public currentDate  : String = "";
  
  public all_user = [];
  public user_details = [];
  public moduleList: Module[] = [];
  public subModulelist: SubModule[] = [];
  public checkedSubmodules: string[] = [];
  public checkedModule: string[] = [];


  public total_users : number = 0;
  public p : number = 1;
  public current_id : number  = 0;
  public row_header_id : number  = 0;


  public isFilterActive : boolean= false;
  public isUserSection : boolean = false;
  public isModuleSection : boolean = false;
  placeholders = Array(8);

  constructor(private fb: FormBuilder, private rest: RestApiService, private toastr: ToastrService, public dialog: MatDialog){}

  ngOnInit(){
    this.updatedTime()
    this.profileFormGroup = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      usertype: ['', Validators.required],
    })

    this.moduleDetails()
    this.userList()
  }


  updatedTime(){
    const now = new Date();
    this.currentDate = now.toDateString();
    this.currentTime = now.toLocaleTimeString();
  }


  inactive(): void {
    this.isFilterActive = false;
    this.selectedUserName = '';
    this.selectedUserType = '';
    this.userList()
    
  }


  openFormDialog(): void {
    this.finalUserName = '';
    this.finalPassword = '';
    this.selectedUserType = '';
    this.checkedModule = [];
    this.checkedSubmodules = [];

    const dialogRef = this.dialog.open(this.formDialog, {
      width: '75%',
      height: '75%',
      // position: { right: '0' },
      // panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  viewUserDetails(user:any,i:any){
    this.row_id = this.user_details[i]['id']
    console.log("this.row_id >>>>>>",this.row_id);
    this.pre_user_name = this.user_details[i]['user_name'];
    console.log("this.pre_user_name >>>>>>>",this.pre_user_name);
    this.pre_user_type = this.user_details[i]['user_type'];
    console.log("this.pre_user_type >>>>>>>",this.pre_user_type);
    this.userModuleDetails(this.pre_user_name)
    const dialogRef = this.dialog.open(this.viewDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }


  editUserDetails(user:any,i:any){
    this.row_id = this.user_details[i]['id']
    console.log("this.row_id >>>>>>",this.row_id);
    this.pre_user_name = this.user_details[i]['user_name'];
    console.log("this.pre_user_name >>>>>>>",this.pre_user_name);
    this.pre_user_type = this.user_details[i]['user_type'];
    console.log("this.pre_user_type >>>>>>>",this.pre_user_type);
   
    const dialogRef = this.dialog.open(this.editDialog, {
      width: '35%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }


  filterFormDialog():void{
    const dialogRef = this.dialog.open(this.filterDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });

  }

  deleteFormDialog(press:any,i:any): void {
    this.current_id  = i;
    this.row_header_id = i+1;
    console.log("this.row_header_id >>>>",this.row_header_id)
    this.row_id = this.user_details[i]['id']
    console.log("this.row_id >>>>>>",this.row_id)
    const dialogRef = this.dialog.open(this.deleteDialog, {
      width: '25%',
      height: '35%',
      
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  onOptionUserTypeChange(event:any){
    this.selectedUserType = event.option.value;
    console.log("this.selectedUserType >>>>>>>",this.selectedUserType)

  }

  onOptionUserName(event:any){
    this.selectedUserName = event.option.value;
    console.log("this.selectedUserName >>>>>>>",this.selectedUserName)
  }

  onUserNameChange(event:any){
    this.pre_user_name = event.target.value;
  }

  userName(event:any){
    this.finalUserName = event.target.value;
  }

  userPassword(event:any){
    this.finalPassword = event.target.value;
  }

  onNoClick(): void {
    this.dialog.closeAll();
  }


  deleteUser(){
    try{

      let data = {
        "id": this.row_id
      }

      this.rest.deleteUserDetails(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success('user name - '+this.pre_user_name+' has been deleted', 'Success', {timeOut: 4000});
          this.user_details.splice(this.current_id,1);
          setTimeout(()=>{
            this.dialog.closeAll();
            this.p=1
          },2000)
          this.userList()
        }
      },(err:any)=>{
        this.toastr.error('user name -'+this.pre_user_name+' is not deleted', 'Error', {timeOut: 4000});
      })



    }catch(e){
      console.log("deleteUser err >>",e);
    }

    
  }

  userList(){

    try{

      this.rest.getUserDetails().subscribe((res: any) => {
        console.log("user res >>>",res)
        if(res.success){
          this.toastr.success('All user list', 'Success', {timeOut: 4000});
          this.user_details = res.result;
          this.total_users = this.user_details.length;
          
          for(let i=0; i<this.user_details.length; i++){
            if(!this.all_user.includes(this.user_details[i]['user_name'])){
              this.all_user.push(this.user_details[i]['user_name'])
            }
          }

          console.log("this.all_user >>>>>",this.all_user)

          // setTimeout(()=>{
          //   this.dialog.closeAll();
          // },2000)

        }
      },(err:any)=>{
        this.toastr.error(err['error']['message'], 'Error', {timeOut: 4000});
      })

    }catch(e){
      console.log("userList error >>>>>",e)
    }
  }

   userModuleDetails(userName:String){
    try{

      console.log("userName >>>>>>>",userName)

      let data = {
        "user_name":userName
      }

      this.rest.specificUserModule(data).subscribe((res: any) => {
        if(res.success){
          console.log("user module res >>>>>>>>>>>",res)
          this.moduleList = res.result;
          // this.nestedDataSource.data = this.moduleList;
          // nestedTreeControl = new NestedTreeControl<CourseNode>(node => node.children);
        }
        
        },(err:any)=>{
          console.log("moduleDetails error >>>>>",err)
        })

    }catch(e){
      console.log("moduleDetails err >>>>",e)
    }
  }

  moduleDetails(){
    try{

      this.rest.getModuleDetails().subscribe((res: any) => {
        if(res.success){
          console.log("module res >>>>>>>>>>>",res)
          this.moduleList = res.result;
          console.log("this.moduleList >>>>>>",this.moduleList)
          // for(let obj of this.moduleList){
          //   console.log("obj >>>>>",obj)
          //   // if(obj.length > 0){
          //   //   this.subModulelist = obj['submodule_name']
          //   // }
          // }

          console.log("this.subModulelist >>>>>",this.subModulelist)
        }
        
        },(err:any)=>{
          console.log("moduleDetails error >>>>>",err)
        })

    }catch(e){
      console.log("moduleDetails err >>>>",e)
    }
  }

  // onStepChange(event: StepperSelectionEvent) {
  onStepChange(event: any) {
    console.log("event.selectedIndex >>>>>>>>>",event.selectedIndex)
    if (event.selectedIndex === 1) { 
        this.goToModule();
    }

    if (event.selectedIndex === 2) { 

      event.preventDefault();
      this.stepper.selectedIndex = event.previouslySelectedIndex;
      // console.log("ABC")// "Done" step
      // if (this.checkedModule.length === 0 && this.checkedSubmodules.length === 0) {
      //   console.log("DEF")
      //   this.toastr.error("Please select at least one module or submodule before proceeding.", 'Error', { timeOut: 2000 });
      //   // Prevent navigation to the last step
      //   this.stepper.selectedIndex = event.previouslySelectedIndex;
      //   return;
      // }
      // else{
      //   this.updateRoles();
      // }
    }
  }

  goToModule(){

    try{

      if(this.finalUserName == ''){
        this.toastr.error('Please fill User Name','Required !!', {timeOut:4000})
      }

      else if(this.finalPassword == ''){
        this.toastr.error('Please fill password','Required !!', {timeOut:4000})
      }

      else if(this.selectedUserType == ''){
        this.toastr.error('Please fill User Type','Required !!', {timeOut:4000})
      }

      if(this.finalUserName != '' && this.finalPassword != '' && this.selectedUserType != ''){

        let data = {
          "user_name" : this.finalUserName,
          "password" : this.finalPassword,
          "user_type" : this.selectedUserType
        }

        this.rest.createUser(data).subscribe((res: any) => {
        if(res.success){
          console.log("res >>>>>>>>>>>",res)
          this.toastr.success("You've moved into module section" ,'Success', {timeOut:2000})
          this.isUserSection = true
        }
        
        },(err:any)=>{
          console.log("Create user section error >>>>>",err)
        })

      }

    }catch(e){
      console.log("goToModule err >",e)
    }
  }

  submitForm(){

    try{

      const dialogRef = this.dialog.open(this.formDialog, {
        width: '25%',
        height: '25%'
        // position: { center: '0' },
        // panelClass: 'custom-dialog-container'
      });

      dialogRef.afterClosed().subscribe(result => {
        console.log('The dialog was closed');
      });

    }catch(e){
      console.log("submitForm err >>>>>>",e)
    }
  }

  closeDialog(): void {
    this.dialog.closeAll();
  }

  toggleModule(module: any): void {
    console.log("toggleModule >>>>>",module)
    module.checked = !module.checked;
    module.submodules.forEach((subModule: any) => {
      subModule.checked = module.checked;
    });

    // if(module.checked == false){

    // }

    this.updateCheckedSubmodules();
  }

  toggleSubModule(module: any, subModule: any): void {
    subModule.checked = !subModule.checked;

    if (!subModule.checked) {
      module.submodules.forEach((sm: any) => {
        if (sm !== subModule) sm.checked = false;
      });
    } else {
      module.checked = module.submodules.every((sm: any) => sm.checked);
    }

    // this.selectedSubModule.push({'sub':subModule['submodule_name']})
    this.updateCheckedSubmodules();
  }


  updateCheckedSubmodules(): void {
    // this.checkedSubmodules = [];
    this.moduleList.forEach(module => {
      console.log("module >>>>>>>",module)
      if(module.checked){
         // this.checkedModule.push(module.module_id);
         if (!this.checkedModule.includes(module.module_id)) {
          this.checkedModule.push(module.module_id);
        }
      }
      else {
        // If the module is unchecked, ensure it is removed from the checkedModule array
        const index = this.checkedModule.indexOf(module.module_id);
        if (index !== -1) {
            this.checkedModule.splice(index, 1);
        }
      }

      
      module.submodules?.forEach((subModule: any) => {

        if (subModule.checked) {
          this.checkedSubmodules.push(subModule.submodule_id);
           if (!this.checkedModule.includes(subModule.module_id)) {
            this.checkedModule.push(subModule.module_id);
          }
        }

      });
    });
    console.log("Checked Submodules:", this.checkedSubmodules);
    console.log("Checked Modules:", this.checkedModule);
  }

  updateRoles(){
    try{

      let data = {

        "new_user_name" : this.finalUserName,
        "module_id" :     this.checkedModule,
        "submodule_id" :  this.checkedSubmodules
      }

      if(this.checkedModule.length === 0 || this.checkedSubmodules.length === 0){
        this.toastr.error("Please select at least one module or submodule before proceeding." ,'Error', {timeOut:2000})
        this.isModuleSection = false;
        return;
      }

      else{

        this.rest.userModuleAccess(data).subscribe((res: any) => {
        if(res.success){
          console.log("res >>>>>>>>>>>",res)
          this.toastr.success("Access given to user - "+this.finalUserName ,'Success', {timeOut:2000})
          this.isModuleSection = true;
          this.stepper.next();
        }

        
        },(err:any)=>{
          console.log("updateRoles error >>>>>",err)
        })
      }

    }catch(e){
      console.log("updateRoles err >>",e)
    }
  }


  filterMaster(){

    try{

      let data = {
        "user_name" : this.selectedUserName,
        "user_type" : this.selectedUserType
      }

      this.rest.filterUserDetails(data).subscribe((res: any) => {
        if(res.success){
          this.p = 1
          this.user_details = res.result;
          this.total_users = this.user_details.length;
          setTimeout(()=>{
            this.dialog.closeAll();
            this.isFilterActive = !this.isFilterActive;

            if(this.selectedUserName!= '' && this.selectedUserType!= ''){
              this.toastr.success('User details is filtered', 'Success', {timeOut: 4000});
            }

            else if(this.selectedUserName!= ''){
              this.toastr.success('User details is filtered with User name - '+this.selectedUserName, 'Success', {timeOut: 4000});
            }

            else if(this.selectedUserType!= ''){
              this.toastr.success('User details is filtered with User type - '+this.selectedUserType, 'Success', {timeOut: 4000});
            }
          },2000)
        }
      },(err:any)=>{
        this.toastr.error('User details is not filtered', 'Error', {timeOut: 4000});
      })

    }catch(e){
      console.log("filterMaster err >",e)
    }
  }


  // updateUser(){

  //   try{

  //     let data = {
  //       "id" : this.row_id,
  //       "user_name" : this.pre_user_name,
  //       "user_type" : this.pre_user_type
  //     }

  //     this.rest.updateUserDetails(data).subscribe((res: any) => {
  //       if(res.success){
  //         this.toastr.success('User details is updated', 'Success', {timeOut: 4000});
  //         setTimeout(()=>{
  //           this.dialog.closeAll();
  //         },2000)
  //       }
  //       this.userList()
  //     },(err:any)=>{
  //       this.toastr.error('User details is not updated', 'Error', {timeOut: 4000});
  //     })

  //   }catch(e){
  //     console.log("updateUser err >>>>>.",e)
  //   }
  // }


  updateUser(){

    try{

      let data = {
        // "id" : this.row_id,
        "user_name" : this.pre_user_name,
        "module_id" : this.pre_user_type,
        "submodule_id" : this.pre_user_type
      }

      this.rest.editUserModule(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success('User details is updated', 'Success', {timeOut: 4000});
          setTimeout(()=>{
            this.dialog.closeAll();
          },2000)
        }
        this.userList()
      },(err:any)=>{
        this.toastr.error('User details is not updated', 'Error', {timeOut: 4000});
      })

    }catch(e){
      console.log("updateUser err >>>>>.",e)
    }
  }

}
