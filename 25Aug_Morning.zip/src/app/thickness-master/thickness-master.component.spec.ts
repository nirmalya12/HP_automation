import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ThicknessMasterComponent } from './thickness-master.component';

describe('ThicknessMasterComponent', () => {
  let component: ThicknessMasterComponent;
  let fixture: ComponentFixture<ThicknessMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ThicknessMasterComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ThicknessMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
