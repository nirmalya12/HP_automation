import { Component, ViewChild, TemplateRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { RestApiService } from '../rest-api.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-pressure-master',
  templateUrl: './pressure-master.component.html',
  styleUrl: './pressure-master.component.css'
})
export class PressureMasterComponent {

  @ViewChild('formDialog') formDialog!: TemplateRef<any>;
  @ViewChild('editDialog') editDialog!: TemplateRef<any>;
  @ViewChild('viewDialog') viewDialog!: TemplateRef<any>;
  @ViewChild('filterDialog') filterDialog!: TemplateRef<any>;
  @ViewChild('deleteDialog') deleteDialog!: TemplateRef<any>;
  


  constructor(public dialog: MatDialog, private rest: RestApiService, private toastr: ToastrService){}


  public pre_division_code            : String = '';
  public employee                     : String = "";
  public targeted_pressure            : String = "";
  public min_pressure                 : String = "";
  public max_pressure                 : String = "";
  public pm_code                      : String = "";
  public division_code                : String = "";
  public section_code                 : String = "";
  public pre_target_pressure          : String = "";
  public pre_min_pressure             : String = "";
  public pre_max_pressure             : String = "";
  public pre_employee_code            : String = "";
  public pre_pm_code                  : String = "";
  public pre_department_code          : String = "";
  public pre_section_code             : String = "";
  public selected_pm_code             : String = "";
  public selected_pc_code             : String = "";
  public selected_size                : String = "";
  public selected_resource_code       : String = "";
  public pre_selected_pm_code         : String = "";
  public pre_selected_resource        : String = "";
  public pre_selected_pc_code         : String = "";
  public pre_selected_size            : String = "";
  public selected_division_code       : String = "";
  public pre_selected_division_code   : String ="";
  public selected_department_code     : String = "";
  public pre_selected_department_code : String ="";
  public selected_section_code        : String = "";
  public pre_selected_section_code    : String = "";
  public filtering_division_code      : String = "";
  public filtering_employee           : String = "";
  public filtering_employee_code      : String = "";
  public filtering_target_pressure    : String = "";
  public filtering_min_pressure       : String = "";
  public filtering_max_pressure       : String = "";
  public filtering_pm_code            : String = ""; 
  public filtering_resource           : String = "";
  public filtering_pc_code            : String = ""; 
  public filtering_size_code          : String = "";
  public filtering_department_code    : String = "";
  public filtering_section_code       : String = "";
  public row_id                       : String = "";
  public resource_details_id          : String = "";
  public currentTime                  : string = "";
  public currentDate                  : String = "";
  public all_division_codes           : String[]= [];
  public all_division_codes_filter    : String[]= [];
  public all_department_codes_filter  : String[]= [];
  public all_section_codes_filter     : String[]= [];
  public all_pm_codes_filter          : String[]= [];
  public all_resources_filter         : String[]= [];
  public all_pc_code_filter           : String[]= [];
  public all_target_pressure_filter   : String[]= [];
  public all_min_pressure_filter      : String[]= [];
  public all_max_pressure_filter      : String[]= [];
  public all_size_filter              : String[]= [];  
  public all_department_codes         : String[]= [];
  public all_section_codes            : String[]= [];
  public all_pm_codes                 : String[]= [];
  public all_pc_codes                 : String[]= [];
  public all_size_nos                 : String[]= [];
  public all_resource                 :string[]= [];
  public employee_details                      = [];
  public resource_details                      = [];
  public pm_master_deatils                     = [];
  public pc_master_deatils                     = [];
  public pm_details                            = [];
  public pc_details                            = [];
  public size_details                          = [];
  public division_details                      = [];
  public department_details                    = [];
  public section_details                       = [];
  public resource_list                         = [];
  public division_codes               : any;
  public resource_codes               : any;
  public department_codes             : any;
  public pc_codess                    : any;
  public target_pressures             : any;
  public min_pressures                : any;
  public max_pressures                : any;
  public sizes                        : any;
  public pm_codes                     : any;
  public pc_codes                     : any;
  public size_no                      : any;
  public emp_codes                    : any;
  public section_codes                : any;
  public resource_index               : any;
  public resource_id                  :any="";
  public total_resource               : number = 0;
  public p                            : number = 1;
  public isFilterActive               : boolean= false;
  

  placeholders = Array(6);
  


  ngOnInit(): void {
    
    const now = new Date();
    this.currentDate = now.toDateString();
    this.currentTime = now.toLocaleTimeString();
    this.pressureList()
    this.pmList()
    this.pcList()
    // this.divisionList()
    // this.departmentList()
    // this.sectionList()
    this.sizeList()


  }

  openFormDialog(): void {
    // this.employee=''
    this.targeted_pressure=''
    this.min_pressure = ''
    this.max_pressure =''
    this.selected_pm_code=''
    this.selected_pc_code=''
    this.selected_size=''
    this.selected_resource_code=''
    // this.selected_division_code=''
    // this.selected_department_code=''

    const dialogRef = this.dialog.open(this.formDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }
  inactive(): void {
    this.isFilterActive = false;
    this.pressureList()
    
  }
  openFilterDialog(): void {
    
    const dialogRef = this.dialog.open(this.filterDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  pmList(){
    try{

      this.rest.pmList().subscribe((res: any) => {
        if(res.success){
          this.pm_details = res.result;
          for(let i =0;i<this.pm_details.length;i++){
            this.pm_codes = this.pm_details[i]
            this.pm_codes = this.pm_codes.PM_CODE
            this.all_pm_codes.push(this.pm_codes)
          }
          // console.log("this.all_pm_codes",this.all_pm_codes)

        }
      })
    }
    
    catch(e){
      console.log(e);
    }
  }
  pcList(){
    try{

      this.rest.getTemperatureDetaiils().subscribe((res: any) => {
        if(res.success){
          this.pc_details = res.result;
          // console.log("this.pc_details=====>",this.pc_details)
          for(let i =0;i<this.pc_details.length;i++){
            this.pc_codes = this.pc_details[i]
            this.pc_codes = this.pc_codes.pc_code
            this.all_pc_codes.push(this.pc_codes)
          }

        }
      })
    }
    
    catch(e){
      console.log(e);
    }
  }
  sizeList(){
    try{

      this.rest.allSize().subscribe((res: any) => {
        // console.log("========",res)
        if(res.success){
          this.size_details = res.result;
          // console.log("this.size_details=====>",this.size_details)
          for(let i =0;i<this.size_details.length;i++){
            this.size_no = this.size_details[i]
            this.size_no = this.size_no.SIZE
            this.all_size_nos.push(this.size_no)
          }

        }
      })
    }
    
    catch(e){
      console.log(e);
    }
  }
  

  // divisionList(){
  //   try{

  //     this.rest.divisionList().subscribe((res: any) => {
  //       // console.log("Division List======>",res)
  //       if(res.success){
  //         this.division_details = res.result;
  //         for(let i =0;i<this.division_details.length;i++){
  //           // console.log("this.division_details[i] >>>>>>>",this.division_details[i])
  //           this.division_codes = this.division_details[i]
  //           this.division_codes = this.division_codes.DI_CODE
  //           // console.log("sdfghj",this.division_codes)
  //           this.all_division_codes.push(this.division_codes)
  //         }
  //                     // console.log("All Division Codes===>",this.all_division_codes)


  //       }
  //     })
  //   }
    
  //   catch(e){
  //     console.log(e);
  //   }
  // }
  // divisionList(){
  //   try{

  //     for(let i =0;i<this.employee_details.length;i++){
  //           this.division_codes = this.employee_details[i]
  //           this.division_codes = this.division_codes.di_code
  //           if (!this.all_division_codes.includes(this.division_codes)) {
  //             this.all_division_codes.push(this.division_codes);
  //           }
  //           // this.all_division_codes.push(this.division_codes)
  //           // console.log("All Division Codes========>",this.all_division_codes)
  //         }

  //     // this.rest.divisionList().subscribe((res: any) => {
  //     //   // console.log("Division List======>",res)
  //     //   if(res.success){
  //     //     this.division_details = res.result;
  //     //     for(let i =0;i<this.division_details.length;i++){
  //     //       // console.log("this.division_details[i] >>>>>>>",this.division_details[i])
  //     //       this.division_codes = this.division_details[i]
  //     //       this.division_codes = this.division_codes.DI_CODE
  //     //       // console.log("sdfghj",this.division_codes)
  //     //       this.all_division_codes.push(this.division_codes)
  //     //     }
  //     //                 // console.log("All Division Codes===>",this.all_division_codes)


  //     //   }
  //     // })
  //   }
    
  //   catch(e){
  //     console.log(e);
  //   }
  // }

  //   departmentList(){
  //   try{

  //     this.rest.departmentMaster().subscribe((res: any) => {
  //       // console.log("Department List======>",res)
  //       if(res.success){
  //         this.department_details = res.result;
  //         for(let i =0;i<this.department_details.length;i++){
  //           this.department_codes = this.department_details[i]
  //           this.department_codes = this.department_codes.DI_CODE
  //           this.all_department_codes.push(this.department_codes)
  //           // console.log("All Department Codes===>",this.all_department_codes)
  //         }

  //       }
  //     })
  //   }
    
  //   catch(e){
  //     console.log(e);
  //   }
  // }

  // departmentList(){
  //   try{

  //     for(let i =0;i<this.employee_details.length;i++){
  //           this.department_codes = this.employee_details[i]
  //           this.department_codes = this.department_codes.dm_code
  //           if (!this.all_department_codes.includes(this.department_codes)) {
  //             this.all_department_codes.push(this.department_codes);
  //           }
  //           // this.all_department_codes.push(this.department_codes)
  //           // console.log("All Department Codes===>",this.all_department_codes)
  //         }

  //     // this.rest.departmentMaster().subscribe((res: any) => {
  //     //   // console.log("Department List======>",res)
  //     //   if(res.success){
  //     //     this.department_details = res.result;
  //     //     for(let i =0;i<this.department_details.length;i++){
  //     //       this.department_codes = this.department_details[i]
  //     //       this.department_codes = this.department_codes.DI_CODE
  //     //       this.all_department_codes.push(this.department_codes)
  //     //       // console.log("All Department Codes===>",this.all_department_codes)
  //     //     }

  //     //   }
  //     // })
  //   }
    
  //   catch(e){
  //     console.log(e);
  //   }
  // }

  //   sectionList(){
  //   try{

  //     this.rest.sectionList().subscribe((res: any) => {
  //       // console.log("Section List======>",res)
  //       if(res.success){
  //         this.section_details = res.result;
  //         for(let i =0;i<this.section_details.length;i++){
  //           this.section_codes = this.section_details[i]
  //           this.section_codes = this.section_codes.SM_CODE
  //           this.all_section_codes.push(this.section_codes)
  //           // console.log("All Department Codes===>",this.all_section_codes)
  //         }

  //       }
  //     })
  //   }
    
  //   catch(e){
  //     console.log(e);
  //   }
  // }

  // sectionList(){
  //   try{
      
  //     for(let i =0;i<this.employee_details.length;i++){
  //           this.section_codes = this.employee_details[i]
  //           this.section_codes = this.section_codes.sm_code
  //           if (!this.all_section_codes.includes(this.section_codes)) {
  //             this.all_section_codes.push(this.section_codes);
  //           }
  //           // this.all_section_codes.push(this.section_codes)
  //           // console.log("All Section Codes===>",this.all_section_codes)
  //         }

  //     // this.rest.sectionList().subscribe((res: any) => {
  //     //   // console.log("Section List======>",res)
  //     //   if(res.success){
  //     //     this.section_details = res.result;
  //     //     for(let i =0;i<this.section_details.length;i++){
  //     //       this.section_codes = this.section_details[i]
  //     //       this.section_codes = this.section_codes.SM_CODE
  //     //       this.all_section_codes.push(this.section_codes)
  //     //       // console.log("All Department Codes===>",this.all_section_codes)
  //     //     }

  //     //   }
  //     // })
  //   }
    
  //   catch(e){
  //     console.log(e);
  //   }
  // }

  onOptionChange(event: any) {
    this.selected_pm_code = event.target.value;
    this.resourceList()
  }
  onOptionChange1(event: any) {
    this.selected_pm_code = event.option.value;
    this.resourceList()
  }
  resourceList(){
    const data = {
      "PM_CODE":this.selected_pm_code
    }
    this.rest.resourcesList(data).subscribe((res: any) => {
      if(res.success){
        
        this.resource_list = res.result
      for(let i = 0; i < this.resource_list.length; i++) {      
      this.resource_id = this.resource_list[i]
      this.resource_id = this.resource_id.resource
      this.all_resource.push(this.resource_id);
     
    }
      }
      

    })
  }
  onPcOptionChange(event: any) {
    this.selected_pc_code = event.option.value;
    // console.log("this.selected_pm_code",this.selected_pm_code)
  }
  onSizeOptionChange(event: any) {
    this.selected_size = event.option.value;
    // console.log("this.selected_pm_code",this.selected_pm_code)
  }

  onDivisionOptionChange(event: any) {
    this.selected_division_code = event.target.value;
    // console.log("this.selected_division_code",this.selected_division_code)
  }

  onDepartmentOptionChange(event: any) {
    this.selected_department_code = event.option.value;
    // console.log("this.selected_department_code",this.selected_department_code)
  }
  onSectionOptionChange(event: any) {
    this.selected_section_code = event.option.value;
    // console.log("this.selected_section_code",this.selected_section_code)
  }

  


  onNoClick(): void {
    this.dialog.closeAll();
  }
  onResourceOptionChange(event:any){
    this.selected_resource_code = event.option.value
  }

  employeeeName(event:any){
    this.employee = event.target.value;
    // console.log("event >>>>",this.employee)
  }
  filteringEmployeeName(event:any){
    this.filtering_employee = event.target.value;
    // console.log("event >>>>",this.filtering_employee)
  }
  filteringTargetPressure(event:any){
    this.filtering_target_pressure = event.option.value;
    // console.log("event >>>>",this.filtering_employee)
  }
  filteringMinPressure(event:any){
    this.filtering_min_pressure = event.option.value;
    // console.log("event >>>>",this.filtering_employee)
  }
  filteringMaxPressure(event:any){
    this.filtering_max_pressure = event.option.value;
    // console.log("event >>>>",this.filtering_employee)
  }
  filteringEmployeeCode(event:any){
    this.filtering_employee_code = event.option.value;
    // console.log("event >>>>",this.filtering_employee_code)
  }
  filteringPmCode(event:any){
    this.filtering_pm_code = event.target.value;
    // console.log("event >>>>",this.filtering_pm_code)
  }
  filteringResourceCode(event:any){

    this.filtering_resource = event.option.value;
    // console.log("event >>>>",this.filtering_pm_code)
  }
  filteringPcCode(event:any){

    this.filtering_pc_code = event.option.value;
    // console.log("event >>>>",this.filtering_pm_code)
  }
  filteringSize(event:any){

    this.filtering_size_code = event.option.value;
    // console.log("event >>>>",this.filtering_pm_code)
  }
  
  filteringDivisionCode(event:any){
    this.filtering_division_code = event.option.value;
    // console.log("event >>>>",this.filtering_division_code)
  }
  filteringDepartmentCode(event:any){
    this.filtering_department_code = event.option.value;
    // console.log("event >>>>",this.filtering_department_code)
  }
  filteringSectionCode(event:any){
    this.filtering_section_code = event.option.value;
    // console.log("event >>>>",this.filtering_section_code)
  }
  
  targetPressure(event:any){
    this.targeted_pressure = event.target.value;
    // console.log("event >>>>",this.employee_code)
  }
  minPressure(event:any){
    this.min_pressure = event.target.value;
    // console.log("event >>>>",this.employee_code)
  }
  maxPressure(event:any){
    this.max_pressure = event.target.value;
    // console.log("event >>>>",this.employee_code)
  }
  

  pmCode(event:any){
    this.pm_code = event.target.value;
    // console.log("event >>>>",this.pm_code)
  }
  divisionCode(event:any){
    this.division_code = event.target.value;
    // console.log("event >>>>",this.division_code)
  }
  sectionCode(event:any){
    this.section_code = event.target.value;
    // console.log("event >>>>",this.section_code)
  }

  pressureList(){
    try{

      this.rest.pressureList().subscribe((res: any) => {
        if(res.success){
          // console.log("res >>>>>>>>>>>",res)
          this.resource_details = res.result;
          this.total_resource = this.resource_details.length;
          for(let i =0;i<this.resource_details.length;i++){
            this.resource_codes = this.resource_details[i]
            this.resource_codes = this.resource_codes.RESOUCE
            if (!this.all_resources_filter.includes(this.resource_codes)) {
              this.all_resources_filter.push(this.resource_codes);
            }
            this.pc_codess = this.resource_details[i]
            this.pc_codess = this.pc_codess.pc_code
            if (!this.all_pc_code_filter.includes(this.pc_codess)) {
              this.all_pc_code_filter.push(this.pc_codess);
            }
            this.target_pressures = this.resource_details[i]
            this.target_pressures = this.target_pressures.target_pressure
            if (!this.all_target_pressure_filter.includes(this.target_pressures)) {
              this.all_target_pressure_filter.push(this.target_pressures);
            }
            this.min_pressures = this.resource_details[i]
            this.min_pressures = this.min_pressures.min_pressure
            if (!this.all_min_pressure_filter.includes(this.min_pressures)) {
              this.all_min_pressure_filter.push(this.min_pressures);
            }
            this.max_pressures = this.resource_details[i]
            this.max_pressures = this.max_pressures.max_pressure
            if (!this.all_max_pressure_filter.includes(this.max_pressures)) {
              this.all_max_pressure_filter.push(this.max_pressures);
            }
            this.sizes = this.resource_details[i]
            this.sizes = this.sizes.size
            if (!this.all_size_filter.includes(this.sizes)) {
              this.all_size_filter.push(this.sizes);
            }
            
            

            // this.section_codes = this.resource_details[i]
            // this.section_codes = this.section_codes.sm_code
            // if (!this.all_section_codes_filter.includes(this.section_codes)) {
            //   this.all_section_codes_filter.push(this.section_codes);
            // }

            // for(let i =0;i<this.employee_details.length;i++){
            this.pm_codes = this.resource_details[i]
            this.pm_codes = this.pm_codes.pm_code
            if (!this.all_pm_codes_filter.includes(this.pm_codes)) {
              this.all_pm_codes_filter.push(this.pm_codes);
            }


            // this.all_division_codes.push(this.division_codes)
            // console.log("All Division Codes========>",this.all_division_codes)
          }
          // console.log("this.total_employee >>>>>>>",this.total_employee)

        }
      })
    }
    
    catch(e){
      console.log(e);
    }
  }

  addMaster(){

    try{

      let data = {

        "target_pressure" :           this.targeted_pressure,
        "min_pressure"    :           this.min_pressure,
        "max_pressure"    :           this.max_pressure,
        "pm_code"         :           this.selected_pm_code,
        "pc_code"         :           this.selected_pc_code,
        "size"            :           this.selected_size,
        "RESOUCE"         :           this.selected_resource_code
      }
      this.rest.addResourceMaster(data).subscribe((res: any) => {
      if(res.success){
        this.toastr.success('Pressure details added', 'Success', {timeOut: 4000});
        setTimeout(()=>{
          this.dialog.closeAll();
          this.pressureList();
        },2000)

      }
      

    })

    }catch(e){
      console.log(e);
    }
  }

  updateMaster(){
    try{

      let data = {
        "target_pressure" :           this.pre_target_pressure,
        "min_pressure"    :           this.pre_min_pressure,
        "max_pressure"    :           this.pre_max_pressure,
        "pm_code"         :           this.pre_selected_pm_code,
        "pc_code"         :           this.pre_selected_pc_code,
        "size"            :           this.pre_selected_size,
        "RESOUCE"         :           this.pre_selected_resource,
        "id"              :           this.row_id
        
      }
      // console.log("==============>",data)
      this.rest.updatePressureMaster(data).subscribe((res: any) => {
        // console.log("ressssssss",res)
        if(res.success){
          this.toastr.success(this.pre_target_pressure+' details updated', 'Success', {timeOut: 4000});
          setTimeout(()=>{
            this.dialog.closeAll();
            this.pressureList()
          },2000)
        }
      },(err:any)=>{
        // console.log("error response >>>>>>",err)
        this.toastr.error('Pressure details not updated.', 'Error', {timeOut: 4000});
      })

    }catch(e){
      console.log(e);
    }

  }

  searchMaster(){
    try{
      
      let data = {
        "pm_code" :this.filtering_pm_code,
        "RESOUCE" :this.filtering_resource,
        "size":this.filtering_size_code,
        "target_pressure":this.filtering_target_pressure,
        "min_pressure":this.filtering_min_pressure,
        "max_pressure":this.filtering_max_pressure
        
        
        // "EM_CODE" :this.filtering_employee_code,
        // "EM_NAME" :this.filtering_employee,
        // "di_code" :this.filtering_division_code,
        // "dm_code" :this.filtering_department_code,
        // "sm_code" :this.filtering_section_code
      }
      if(this.filtering_pm_code == "" && this.filtering_resource =="" && this.filtering_target_pressure == "" && this.filtering_min_pressure == "" && this.filtering_max_pressure == "" && this.filtering_size_code == ""){
        this.toastr.error('Please fill any data to filter','Error', {timeOut: 4000});
      }
      else{
        this.rest.filterPressure(data).subscribe((res: any) => {
        // console.log("res==========>",res)
        if(res.success){
          this.resource_details=res.result
          this.total_resource = this.resource_details.length;
          this.toastr.success(this.filtering_division_code+' Filtered Successfully.','Success', {timeOut: 4000});
          this.dialog.closeAll();
          this.p=1
          this.isFilterActive = !this.isFilterActive;
          this.filtering_pm_code="";
          this.filtering_resource=""
          this.filtering_target_pressure=""
          this.filtering_min_pressure=""
          this.filtering_max_pressure=""
          this.filtering_size_code=""
          // this.filtering_employee_code="";
          // this.filtering_employee="";
          // this.filtering_division_code="";
          // this.filtering_department_code="";
          // this.filtering_section_code="";
        }
      },(err:any)=>{
        this.toastr.error('Hot press details not updated.', 'Error', {timeOut: 4000});
      })
      }
      

    }catch(e){
      console.log(e);
    }

  }


  editHotPressDetails(press:any,i:any){
    this.row_id = this.resource_details[i]['id']
    this.pre_employee_code = this.resource_details[i]['EM_CODE'];
    this.pre_selected_pm_code = this.resource_details[i]['pm_code'];
    this.pre_selected_pc_code = this.resource_details[i]['pc_code'];
    this.pre_selected_size = this.resource_details[i]['size'];
    
    
    this.pre_selected_resource = this.resource_details[i]['RESOUCE'];
    // this.pre_selected_resource
    this.pre_selected_division_code = this.resource_details[i]['di_code'];
    this.pre_selected_department_code = this.resource_details[i]['dm_code'];
    this.pre_target_pressure = this.resource_details[i]['target_pressure'];
    this.pre_min_pressure = this.resource_details[i]['min_pressure'];
    this.pre_max_pressure = this.resource_details[i]['max_pressure'];
    
    
    this.pre_selected_section_code = this.resource_details[i]['sm_code'];
    
    const dialogRef = this.dialog.open(this.editDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  viewDivisionDetails(press:any,i:any){
    this.pre_employee_code = this.resource_details[i]['EM_CODE'];
    this.pre_selected_pm_code = this.resource_details[i]['pm_code'];
    this.pre_selected_pc_code = this.resource_details[i]['pc_code'];
    this.pre_selected_size = this.resource_details[i]['size'];
    
    this.pre_selected_resource = this.resource_details[i]['RESOUCE'];
    this.pre_target_pressure = this.resource_details[i]['target_pressure'];
    this.pre_selected_division_code = this.resource_details[i]['di_code'];
    this.pre_selected_department_code = this.resource_details[i]['dm_code'];
    // this.pre_employee = this.resource_details[i]['EM_NAME'];
    this.pre_selected_section_code = this.resource_details[i]['sm_code'];
    this.pre_min_pressure = this.resource_details[i]['min_pressure'];
    this.pre_max_pressure = this.resource_details[i]['max_pressure'];
    
    const dialogRef = this.dialog.open(this.viewDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }
    


  openConfirmationModal(press:any,i:any){
    this.resource_id = i+1 ;
    this.resource_index = i;
    this.resource_details_id =this.resource_details[i]['id']
    // console.log("this.employee_id",this.employee_id)
    try{

      const dialogRef = this.dialog.open(this.deleteDialog, {
      width: '25%',
      height: '35%',
      // panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
    }catch(e){
      console.log(e);
    }

    
  }

    submitForm(){
    try{
      let data = {
        "id": this.resource_details_id
      }

      this.rest.deletePressure(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success('Resource has been deleted', 'Success', {timeOut: 4000});
          this.resource_details.splice(this.resource_index,1);
          this.dialog.closeAll();
          this.pressureList()
        }
      },(err:any)=>{
        this.toastr.error('Resource is not deleted', 'Error', {timeOut: 4000});
      })

    }catch(e){
      console.log(e);
    }

    
  }

}
