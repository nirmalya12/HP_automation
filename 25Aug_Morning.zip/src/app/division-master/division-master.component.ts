import { Component, ViewChild, TemplateRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { RestApiService } from '../rest-api.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-division-master',
  templateUrl: './division-master.component.html',
  styleUrl: './division-master.component.css'
})
export class DivisionMasterComponent {

  @ViewChild('formDialog') formDialog!: TemplateRef<any>;
  @ViewChild('editDialog') editDialog!: TemplateRef<any>;
  @ViewChild('viewDialog') viewDialog!: TemplateRef<any>;
  @ViewChild('filterDialog') filterDialog!: TemplateRef<any>;
  @ViewChild('deleteDialog') deleteDialog!: TemplateRef<any>;



  constructor(public dialog: MatDialog, private rest: RestApiService, private toastr: ToastrService){}


  public pre_division_name        : String = '';
  public pre_division_code        : String = '';
  public division                 : String = "";
  public division_code            : String = "";
  public filtering_division_code  : String = "";
  public filtering_division       : String = "";  
  public row_id                   : String = "";
  public division_id              : String = "";
  public division_details_id      : String = "";
  public currentTime              : string = "";
  public currentDate              : String = "";
  public division_details                  = [];
  public pm_master_deatils                 = [];
  public pc_master_deatils                 = [];
  public total_division           : number = 0;
  public p                        : number = 1;
  public isFilterActive           : boolean= false;
  public division_id_index        : any;
  public division_names                     : any;
  public all_division_names                 : String[]= [];
  public division_codes                     : any;
  public all_division_codes                 : String[]= [];

  placeholders = Array(6);

  ngOnInit(): void {
    this.divisionList()
    const now = new Date();
    this.currentDate = now.toDateString();
    this.currentTime = now.toLocaleTimeString();

  }

  openFormDialog(): void {
    this.division = ""
    this.division_code = ""

    const dialogRef = this.dialog.open(this.formDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }
  inactive(): void {
    this.isFilterActive = false;
    this.divisionList()
    
  }
  openFilterDialog(): void {
    
    const dialogRef = this.dialog.open(this.filterDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  onNoClick(): void {
    this.dialog.closeAll();
  }

  divisionName(event:any){
    this.division = event.target.value;
    // console.log("event >>>>",this.division)
  }
  filteringDivisionName(event:any){
    this.filtering_division = event.target.value;
    // console.log("event >>>>",this.filtering_division)
  }

  divisionCode(event:any){
    this.division_code = event.target.value;
    // console.log("event >>>>",this.division_code)
  }
  filteringDivisionCode(event:any){
    this.filtering_division_code = event.option.value;
    // console.log("event >>>>",this.filtering_division_code)
  }

  divisionList(){
    try{

      this.rest.divisionList().subscribe((res: any) => {
        if(res.success){
          // console.log("res >>>>>>>>>>>",res)
          this.division_details = res.result;
          this.total_division = this.division_details.length;
          for(let i =0;i<this.division_details.length;i++){
            this.division_names = this.division_details[i]
            this.division_names = this.division_names.DI_NAME
            if (!this.all_division_names.includes(this.division_names)) {
              this.all_division_names.push(this.division_names);
            }

            this.division_codes = this.division_details[i]
            this.division_codes = this.division_codes.DI_CODE
            if (!this.all_division_codes.includes(this.division_codes)) {
              this.all_division_codes.push(this.division_codes);
            }
          }

        }
      })
    }
    
    catch(e){
      console.log(e);
    }
  }

  addMaster(){

    try{

      let data = {

        "DI_CODE" :           this.division_code,
        "DI_NAME" :           this.division

      }
      this.rest.addDivisionMaster(data).subscribe((res: any) => {
      if(res.success){
        this.toastr.success('Division details added', 'Success', {timeOut: 4000});
        setTimeout(()=>{
          this.dialog.closeAll();
          this.divisionList();
        },2000)

      }
      

    })

    }catch(e){
      console.log(e);
    }
  }

  updateMaster(){
    try{

      let data = {
        "DI_CODE" :this.pre_division_code,
        "DI_NAME" :this.pre_division_name,
        "id"      :this.row_id
      }
      this.rest.updateDivisionMaster(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success(this.pre_division_name+' details updated', 'Success', {timeOut: 4000});
          setTimeout(()=>{
            this.dialog.closeAll();
            this.divisionList()
          },2000)
        }
      },(err:any)=>{
        this.toastr.error('Division details not updated.', 'Error', {timeOut: 4000});
      })

    }catch(e){
      console.log(e);
    }

  }

  searchMaster(){
    try{
      
      let data = {
        "DI_CODE" :this.filtering_division_code,
        "DI_NAME" :this.filtering_division,
      }
      if(this.filtering_division_code == "" && this.filtering_division ==""){
        this.toastr.error('Please fill any data to filter','Error', {timeOut: 4000});
      }
      else{
        this.rest.filterDivision(data).subscribe((res: any) => {
        // console.log("res==========>",res)
        if(res.success){
          this.division_details=res.result
          this.total_division = this.division_details.length;
          this.toastr.success(this.filtering_division_code+' Filtered Successfully.','Success', {timeOut: 4000});
          this.dialog.closeAll();
          this.p=1
          this.isFilterActive = !this.isFilterActive;
          this.filtering_division_code="";
          this.filtering_division="";
        }
      },(err:any)=>{
        this.toastr.error('Hot press details not updated.', 'Error', {timeOut: 4000});
      })
      }
      

    }catch(e){
      console.log(e);
    }

  }


  editHotPressDetails(press:any,i:any){
    this.row_id = this.division_details[i]['id']
    this.pre_division_name = this.division_details[i]['DI_NAME'];
    this.pre_division_code = this.division_details[i]['DI_CODE'];
    
    const dialogRef = this.dialog.open(this.editDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  viewDivisionDetails(press:any,i:any){
    this.pre_division_name = this.division_details[i]['DI_NAME'];
    this.pre_division_code = this.division_details[i]['DI_CODE'];
    const dialogRef = this.dialog.open(this.viewDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }
    


  deleteDivision(press:any,i:any){
    try{

      let data = {
        "id": this.division_details[i]['id']
      }

      this.rest.deleteDivision(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success('Hot press - '+this.pre_division_name+' has been deleted', 'Success', {timeOut: 4000});
          this.division_details.splice(i,1);
        }
      },(err:any)=>{
        this.toastr.error('Hot press -'+this.pre_division_name+' is not deleted', 'Error', {timeOut: 4000});
      })



    }catch(e){
      console.log(e);
    }

    
  }

    openConfirmationModal(press:any,i:any){
    this.division_id = i+1 ;
    this.division_id_index = i;
    this.division_details_id =this.division_details[i]['id']
    // console.log("this.division_id",this.division_id)
    try{

      const dialogRef = this.dialog.open(this.deleteDialog, {
      width: '25%',
      height: '35%',
      // panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });

    }catch(e){
      console.log(e);
    }

    
  }

    submitForm(){
    try{

      let data = {
        "id": this.division_details_id
      }

      this.rest.deleteDivision(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success(this.pre_division_name+' has been deleted', 'Success', {timeOut: 4000});
          this.division_details.splice(this.division_id_index,1);
          this.dialog.closeAll();
          this.divisionList()
        }
      },(err:any)=>{
        this.toastr.error(this.pre_division_name+' is not deleted', 'Error', {timeOut: 4000});
      })



    }catch(e){
      console.log(e);
    }

    
  }



}