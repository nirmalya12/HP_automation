import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import {HTTP_INTERCEPTORS, HttpClientModule} from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
// import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { MatSelectModule } from '@angular/material/select';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatTreeModule } from '@angular/material/tree';
import {MatIconModule} from '@angular/material/icon';
import {MatButtonModule} from '@angular/material/button';
import {NgxPaginationModule} from 'ngx-pagination';
import { MatStepperModule } from '@angular/material/stepper';
import { ReactiveFormsModule } from '@angular/forms';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';

// import {MatRadioModule} from '@angular/material/radio';
// import {MatButtonModule} from '@angular/material/button';
// import {MatIconModule} from '@angular/material/icon';
// import {MatProgressBarModule} from '@angular/material/progress-bar';
// import {MatMenuModule} from '@angular/material/menu';
// import {MatCheckboxModule} from '@angular/material/checkbox';
// import {MatExpansionModule} from '@angular/material/expansion';
// import {MatDialogModule} from '@angular/material/dialog';
// import {MatSlideToggleModule} from '@angular/material/slide-toggle';



import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HeaderComponent } from './header/header.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { InfoComponent } from './info/info.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { HotpressMasterComponent } from './hotpress-master/hotpress-master.component';
import { ChangeDateShiftComponent } from './change-date-shift/change-date-shift.component';
import { ShiftMasterComponent } from './shift-master/shift-master.component';
import { DepartmentMasterComponent } from './department-master/department-master.component';
import { UserMasterComponent } from './user-master/user-master.component';
import { DivisionMasterComponent } from './division-master/division-master.component';
import { PcCodeMasterComponent } from './pc-code-master/pc-code-master.component';
import { PmCodeMasterComponent } from './pm-code-master/pm-code-master.component';
import { SectionMasterComponent } from './section-master/section-master.component';
import { EmployeeMasterComponent } from './employee-master/employee-master.component';
import { PressureMasterComponent } from './pressure-master/pressure-master.component';
import { ContractorMasterComponent } from './contractor-master/contractor-master.component';
import { PlantMasterComponent } from './plant-master/plant-master.component';
import { SizeMasterComponent } from './size-master/size-master.component';
import { ProductMasterComponent } from './product-master/product-master.component';
import { ThicknessMasterComponent } from './thickness-master/thickness-master.component';
import { TemperatureMasterComponent } from './temperature-master/temperature-master.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    HeaderComponent,
    SidebarComponent,
    InfoComponent,
    HotpressMasterComponent,
    ChangeDateShiftComponent,
    ShiftMasterComponent,
    DepartmentMasterComponent,
    UserMasterComponent,
    DivisionMasterComponent,
    PcCodeMasterComponent,
    PmCodeMasterComponent,
    SectionMasterComponent,
    EmployeeMasterComponent,
    PressureMasterComponent,
    ContractorMasterComponent,
    PlantMasterComponent,
    SizeMasterComponent,
    ProductMasterComponent,
    ThicknessMasterComponent,
    TemperatureMasterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    BrowserAnimationsModule,
    // FontAwesomeModule,
    MatSelectModule,
    MatAutocompleteModule,
    MatFormFieldModule,
    MatInputModule,
    MatSidenavModule,
    MatListModule,
    MatTreeModule,
    MatIconModule,
    MatButtonModule,
    NgxPaginationModule,
    MatStepperModule,
    ReactiveFormsModule,
    NgxSkeletonLoaderModule,
    ToastrModule.forRoot()
  ],
  providers: [
    provideClientHydration(),
    provideAnimationsAsync()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
