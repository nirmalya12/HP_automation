import { Component, ViewChild, TemplateRef} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { RestApiService } from '../rest-api.service';
import { ToastrService } from 'ngx-toastr';
import { FormControl } from '@angular/forms';
@Component({
  selector: 'app-section-master',
  templateUrl: './section-master.component.html',
  styleUrl: './section-master.component.css'
})
export class SectionMasterComponent {
  @ViewChild('formDialog') formDialog!: TemplateRef<any>;
  @ViewChild('editDialog') editDialog!: TemplateRef<any>;
  @ViewChild('viewDialog') viewDialog!: TemplateRef<any>;
  @ViewChild('filterDialog') filterDialog!: TemplateRef<any>;
  @ViewChild('deleteDialog') deleteDialog!: TemplateRef<any>;
  // section = new FormControl();


  constructor(public dialog: MatDialog, private rest: RestApiService, private toastr: ToastrService){}

  public pre_section_name         : String = '';
  public pre_section_code         : String = '';
  public pre_division_code        : String = '';
  public section_name             : String = "";
  public section_code             : String = "";
  public division_code            : String = "";
  public row_id                   : String = "";
  public filtering_section_name   : String = "";
  public filtering_section_code   : String = "";
  public filtering_division_code  : String = "";
  public section_id               : String = "";
  public section_details_id       : String = "";
  public currentTime              : string = "";
  public currentDate              : String = "";
  public section_details                   = [];
  public pm_master_deatils                 = [];
  public pc_master_deatils                 = [];
  public total_section            : number = 0;
  public p                        : number = 1;
  public isFilterActive           : boolean= false;
  public section_id_index              : any;
  public section_names                     : any;
  public all_section_names                 : String[]= [];
  public section_codes                     : any;
  public all_section_codes                 : String[]= [];
  public division_codes                     : any;
  public all_division_codes                 : String[]= [];
  placeholders = Array(6);
  


  ngOnInit(): void {
    this.sectionList()
    const now = new Date();
    this.currentDate = now.toDateString();
    this.currentTime = now.toLocaleTimeString();
  }
  
  openFormDialog(): void {
    this.section_name = ""
    this.section_code = ""
    this.division_code = ""

    const dialogRef = this.dialog.open(this.formDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  inactive(): void {
    this.isFilterActive = false;
    this.sectionList()
    
  }

  openFilterDialog(): void {
    const dialogRef = this.dialog.open(this.filterDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  onNoClick(): void {
    this.dialog.closeAll();
  }

  sectionName(event:any){
    this.section_name = event.target.value;
  }

  filteringSectionName(event:any){
    this.filtering_section_name = event.target.value;
  }

  sectionCode(event:any){
    this.section_code = event.target.value;
  }

  filteringSectionCode(event:any){
    this.filtering_section_code = event.option.value;
  }

  divisionCode(event:any){
    this.division_code = event.target.value;
  }

  filteringDivisionCode(event:any){
    this.filtering_division_code = event.option.value;
  }

  sectionList(){
    try{

      this.rest.sectionList().subscribe((res: any) => {
        if(res.success){
          this.section_details = res.result;
          // console.log("Section Details=====>",this.section_details)
          this.total_section = this.section_details.length;
          for(let i =0;i<this.section_details.length;i++){
            this.section_names = this.section_details[i]
            this.section_names = this.section_names.SM_NAME
            if (!this.all_section_names.includes(this.section_names)) {
              this.all_section_names.push(this.section_names);
            }

            this.section_codes = this.section_details[i]
            this.section_codes = this.section_codes.SM_CODE
            if (!this.all_section_codes.includes(this.section_codes)) {
              this.all_section_codes.push(this.section_codes);
            }

            this.division_codes = this.section_details[i]
            this.division_codes = this.division_codes.DM_CODE
            if (!this.all_division_codes.includes(this.division_codes)) {
              this.all_division_codes.push(this.division_codes);
            }
          }
          // console.log("all_section_names",this.all_section_names)
          // console.log("all_section_codes",this.all_section_codes)
          // console.log("all_division_codes",this.all_division_codes)
        }
      })
    }
    
    catch(e){
      console.log(e);
    }
  }

  addMaster(){

    try{

      let data = {

        "DM_CODE" :           this.division_code,
        "SM_NAME" :           this.section_name,
        "SM_CODE" :           this.section_code,

      }
      this.rest.addSectionMaster(data).subscribe((res: any) => {
      if(res.success){
        this.toastr.success('Hot press details added', 'Success', {timeOut: 4000});
        setTimeout(()=>{
          this.dialog.closeAll();
          this.sectionList()
        },2000)
      }
    })

    }catch(e){
      console.log(e);
    }
  }

  updateMaster(){
    try{

      let data = {

        "DM_CODE" :this.division_code,
        "SM_NAME" :this.section_name,
        "SM_CODE" :this.section_code,        
        "id"      :this.row_id

      }
      this.rest.updateSectionMaster(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success('Hot press - '+this.pre_section_name+' details updated', 'Success', {timeOut: 4000});
          setTimeout(()=>{
            this.dialog.closeAll();
            this.sectionList()
          },2000)
        }
      },(err:any)=>{
        this.toastr.error('Hot press details not updated.', 'Error', {timeOut: 4000});
      })

    }catch(e){
      console.log(e);
    }

  }

  searchMaster(){
    try{

      let data = {

        "DM_CODE" :this.filtering_division_code,
        "SM_NAME" :this.filtering_section_name,
        "SM_CODE" :this.filtering_section_code,        
       
      }
      // if(this.filteringSectionName == "" && this.section_name == "" && this.section_code == ""){
      //   this.toastr.error('Please fill any data to filter','Error', {timeOut: 4000});
      // }
      // else{
        this.rest.filterSection(data).subscribe((res: any) => {
        if(res.success){
          this.section_details = res.result;
          this.total_section = this.section_details.length;
          this.toastr.success(this.filtering_division_code+' Filtered Successfully.','Success', {timeOut: 4000});
          this.dialog.closeAll();
          this.p = 1;
          this.isFilterActive = !this.isFilterActive;
          this.filtering_division_code="";
          this.filtering_section_name="";
          this.filtering_section_code="";

        }
      },(err:any)=>{
        this.toastr.error('Hot press details not updated.', 'Error', {timeOut: 4000});
      })
      // }

    }catch(e){
      console.log(e);
    }

  }


  editSectionDetails(press:any,i:any){

    this.row_id = this.section_details[i]['id']
    this.pre_section_name = this.section_details[i]['SM_NAME'];
    this.pre_section_code = this.section_details[i]['SM_CODE'];    
    this.pre_division_code = this.section_details[i]['DM_CODE'];

    const dialogRef = this.dialog.open(this.editDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  viewSectionDetails(press:any,i:any){

    this.pre_section_name = this.section_details[i]['SM_NAME'];
    this.pre_section_code = this.section_details[i]['SM_CODE'];    
    this.pre_division_code = this.section_details[i]['DM_CODE'];

    const dialogRef = this.dialog.open(this.viewDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }
    


  deleteSection(press:any,i:any){
    try{

      let data = {
        "id": this.section_details[i]['id']
      }

      this.rest.deleteSection(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success('Hot press - '+this.pre_section_name+' has been deleted', 'Success', {timeOut: 4000});
          this.section_details.splice(i,1);
        }
      },(err:any)=>{
        this.toastr.error('Hot press -'+this.pre_section_name+' is not deleted', 'Error', {timeOut: 4000});
      })



    }catch(e){
      console.log(e);
    }

    
  }

  openConfirmationModal(press:any,i:any){
    this.section_id = i+1 ;
    this.section_id_index = i;
    this.section_details_id =this.section_details[i]['id']
    // console.log("this.section_id",this.section_id)
    try{

      const dialogRef = this.dialog.open(this.deleteDialog, {
      width: '25%',
      height: '35%',
      // panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
    }catch(e){
      console.log(e);
    }

    
  }

    submitForm(){
    try{

      let data = {
        "id": this.section_details_id
      }

      this.rest.deleteSection(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success(this.pre_section_name+' has been deleted', 'Success', {timeOut: 4000});
          this.section_details.splice(this.section_id_index,1);
          this.dialog.closeAll();
          this.sectionList()
        }
      },(err:any)=>{
        this.toastr.error(this.pre_section_name+' is not deleted', 'Error', {timeOut: 4000});
      })



    }catch(e){
      console.log(e);
    }

    
  }
}


