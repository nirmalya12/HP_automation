import { inject } from '@angular/core';
import { CanActivateFn,Router,ActivatedRouteSnapshot,RouterStateSnapshot } from '@angular/router';

export const authGuard: CanActivateFn = (route: ActivatedRouteSnapshot, state: RouterStateSnapshot) => {

  const _router = inject(Router);

  let isloggedIn = localStorage.getItem('isloggedIn');

  if(isloggedIn == 'false'){
    _router.navigate(['']);
    return false;
  }

  return true;
};
