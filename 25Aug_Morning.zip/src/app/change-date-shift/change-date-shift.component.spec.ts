import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangeDateShiftComponent } from './change-date-shift.component';

describe('ChangeDateShiftComponent', () => {
  let component: ChangeDateShiftComponent;
  let fixture: ComponentFixture<ChangeDateShiftComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ChangeDateShiftComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ChangeDateShiftComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
