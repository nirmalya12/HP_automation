import { Component, ViewChild, TemplateRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { RestApiService } from '../rest-api.service';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-pm-code-master',
  templateUrl: './pm-code-master.component.html',
  styleUrl: './pm-code-master.component.css'
})
export class PmCodeMasterComponent {

  @ViewChild('formDialog') formDialog!: TemplateRef<any>;
  @ViewChild('editDialog') editDialog!: TemplateRef<any>;
  @ViewChild('viewDialog') viewDialog!: TemplateRef<any>;
  @ViewChild('filterDialog') filterDialog!: TemplateRef<any>;
  @ViewChild('deleteDialog') deleteDialog!: TemplateRef<any>;


  constructor(public dialog: MatDialog, private rest: RestApiService, private toastr: ToastrService){}

  public pre_pm_code        : String = '';
  public pre_pm_name        : String = '';
  public pre_ppm_code       : String = "";
  public pm_code            : String = "";
  public pm_name            : String = "";
  public ppm_code           : String = "";
  public filtering_pm_code  : String = "";
  public filtering_pm_name  : String = "";
  public filtering_ppm_code : String = "";
  public row_id             : String = "";
  public pm_code_id         : String = "";
  public employee_id        : String = "";
  public pm_details_id      : String = "";
  public currentTime        : string = "";
  public currentDate        : String = "";
  public pm_details                  = [];
  public pm_master_deatils           = [];
  public pc_master_deatils           = [];
  public total_pm_code      : number = 0;
  public p                  : number = 1;
  public isFilterActive     : boolean= false; 
  public pm_id_index        : any;
  public pm_codes                     : any;
  public pm_names                     : any;
  public ppm_codes                     : any;
  public all_pm_codes                 : String[]= [];
  public all_pm_names                 : String[]= [];
  public all_ppm_codes                 : String[]= [];
  placeholders = Array(6);


  ngOnInit(): void {
    const now = new Date();
    this.currentDate = now.toDateString();
    this.currentTime = now.toLocaleTimeString();
    this.pmList()
  }

  openFormDialog(): void {
    this.pm_code = ""
    this.pm_name = ""
    this.ppm_code = ""

    const dialogRef = this.dialog.open(this.formDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  inactive(): void {
    this.isFilterActive = false;
    this.pmList()
    
  }

  openFilterDialog(): void {
    const dialogRef = this.dialog.open(this.filterDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  onNoClick(): void {
    this.dialog.closeAll();
  }

  pmCode(event:any){
    this.pm_code = event.target.value;
  }
  filteringPmCode(event:any){
    this.filtering_pm_code = event.target.value;
  }

  pmName(event:any){
    this.pm_name = event.target.value;
  }
  filteringPmName(event:any){
    this.filtering_pm_name = event.option.value;
  }
  ppmCode(event:any){
    this.ppm_code = event.target.value;
  }
  filteringPpmCode(event:any){
    this.filtering_ppm_code = event.option.value;
  }

  // allPmList(){
  //   try{

  //     for(let i =0;i<this.pm_details.length;i++){
  //           this.pm_codes = this.pm_details[i]
  //           this.pm_codes = this.pm_codes.PM_CODE
  //           if (!this.all_pm_codes.includes(this.pm_codes)) {
  //             this.all_pm_codes.push(this.pm_codes);
  //           }
  //           // this.all_pm_codes.push(this.pm_codes)
  //           console.log("All Pm Codes========>",this.all_pm_codes)
  //         }
  //   }
    
  //   catch(e){
  //     console.log(e);
  //   }
  // }
  pmList(){
    try{

      this.rest.pmList().subscribe((res: any) => {
        if(res.success){
          this.pm_details = res.result;
          // console.log("PM DETAILS=======>",this.pm_details)
          this.total_pm_code = this.pm_details.length;
          for(let i =0;i<this.pm_details.length;i++){
            this.pm_codes = this.pm_details[i]
            this.pm_codes = this.pm_codes.PM_CODE
            if (!this.all_pm_codes.includes(this.pm_codes)) {
              this.all_pm_codes.push(this.pm_codes);
            }
            this.pm_names = this.pm_details[i]
            this.pm_names = this.pm_names.PM_NAME
            if (!this.all_pm_names.includes(this.pm_names)) {
              this.all_pm_names.push(this.pm_names);
            }
            this.ppm_codes = this.pm_details[i]
            this.ppm_codes = this.ppm_codes.PPM_CODE
            if (!this.all_ppm_codes.includes(this.ppm_codes)) {
              this.all_ppm_codes.push(this.ppm_codes);
            }
            // console.log("All Pm Codes========>",this.all_pm_codes)
          }
          // console.log("All Pm Names========>",this.all_pm_names)
          // console.log("All Ppm Codes========>",this.all_ppm_codes)
        }
      })
    }
    
    catch(e){
      console.log(e);
    }
  }

  addMaster(){

    try{
      let data = {

        "PM_NAME" :           this.pm_name,
        "PM_CODE" :           this.pm_code,
        "PPM_CODE":           this.ppm_code

      }


      this.rest.addPmMaster(data).subscribe((res: any) => {
      if(res.success){
        this.toastr.success('Pm details added', 'Success', {timeOut: 4000});
        setTimeout(()=>{
          this.dialog.closeAll();
          this.pmList()
        },2000)

      }
      

    })

    }catch(e){
      console.log(e);
    }
  }

  updateMaster(){
    try{
      let data = {

        "PM_NAME" :this.pre_pm_name,
        "PM_CODE" :this.pre_pm_code,
        "id"      :this.row_id,
        "PPM_CODE":this.pre_ppm_code

      }
      this.rest.updatePmMaster(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success('Hot press - '+this.pre_pm_name+' details updated', 'Success', {timeOut: 4000});
          setTimeout(()=>{
            this.dialog.closeAll();
            this.pmList()
          },2000)

        }
      },(err:any)=>{
        this.toastr.error('Hot press details not updated.', 'Error', {timeOut: 4000});
      })

    }catch(e){
      console.log(e);
    }

  }
  searchMaster(){
    try{
      let data = {

        "PM_NAME" :this.filtering_pm_name,
        "PM_CODE" :this.filtering_pm_code,
        "PPM_CODE":this.filtering_ppm_code

      }
      if(this.filtering_pm_name == "" && this.filtering_pm_code == "" && this.filtering_ppm_code == "" ){
        this.toastr.error('Please fill any data to filter','Error', {timeOut: 4000});
      }
      else{
        this.rest.filterPm(data).subscribe((res: any) => {
        if(res.success){
          this.pm_details = res.result;
          this.total_pm_code = this.pm_details.length;
          this.toastr.success(this.filtering_pm_name+' Filtered Successfully.','Success', {timeOut: 4000});
          this.dialog.closeAll();
          this.p=1
          this.isFilterActive = !this.isFilterActive;
          this.filtering_pm_name="";
          this.filtering_pm_code="";
          this.filtering_ppm_code="";
        }
      },(err:any)=>{
        this.toastr.error('Hot press details not updated.', 'Error', {timeOut: 4000});
      })
      }

    }catch(e){
      console.log(e);
    }

  }


  editPmCodeDetails(press:any,i:any){
    this.row_id = this.pm_details[i]['id']
    this.pre_pm_code = this.pm_details[i]['PM_CODE'];
    this.pre_pm_name = this.pm_details[i]['PM_NAME'];
    this.pre_ppm_code = this.pm_details[i]['PPM_CODE'];
    const dialogRef = this.dialog.open(this.editDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  viewPmCodeDetails(press:any,i:any){
    this.pre_pm_code = this.pm_details[i]['PM_CODE'];
    this.pre_pm_name = this.pm_details[i]['PM_NAME'];
    this.pre_ppm_code = this.pm_details[i]['PPM_CODE'];
    
    const dialogRef = this.dialog.open(this.viewDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }
 
  openConfirmationModal(press:any,i:any){
    this.pm_code_id = i+1 ;
    this.pm_id_index = i;
    this.pm_details_id =this.pm_details[i]['id']
    // console.log("this.pm_code_id",this.pm_code_id)
    try{

      const dialogRef = this.dialog.open(this.deleteDialog, {
      width: '25%',
      height: '35%',
      // panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });

    }catch(e){
      console.log(e);
    }

    
  }

    submitForm(){

    try{
      let data = {
        "id": this.pm_details_id
      }

      this.rest.deletePm(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success(this.pre_pm_code+' has been deleted', 'Success', {timeOut: 4000});
          this.pm_details.splice(this.pm_id_index,1);
          this.dialog.closeAll();
          this.pmList()
        }
      },(err:any)=>{
        this.toastr.error(this.pre_pm_code+' is not deleted', 'Error', {timeOut: 4000});
      })

    }catch(e){
      console.log(e);
    }

    
  }




}