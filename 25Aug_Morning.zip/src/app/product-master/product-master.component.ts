import { Component, ViewChild, TemplateRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { RestApiService } from '../rest-api.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-product-master',
  templateUrl: './product-master.component.html',
  styleUrl: './product-master.component.css'
})
export class ProductMasterComponent {

@ViewChild('formDialog') formDialog!: TemplateRef<any>;
  @ViewChild('editDialog') editDialog!: TemplateRef<any>;
  @ViewChild('viewDialog') viewDialog!: TemplateRef<any>;
  @ViewChild('filterDialog') filterDialog!: TemplateRef<any>;
  @ViewChild('deleteDialog') deleteDialog!: TemplateRef<any>;



  constructor(public dialog: MatDialog, private rest: RestApiService, private toastr: ToastrService){}

  public pt_description : String = '';
  public pt_code  : String = '';
  public pre_pt_description : String = '';
  public pre_pt_code  : String = ''; 
  public row_id   : String = "";
  public currentTime : string = "";
  public currentDate : String = "";


  public product_details   = [];


  public total_product : number = 0;
  public current_id : number = 0;
  public row_header_id : number = 0;
  public p : number = 1;
  

  public isFilterActive           : boolean= false;

  placeholders = Array(6);

  ngOnInit(): void {
    this.updatedTime()
    this.productList()   

  }

  updatedTime(){
    const now = new Date();
    this.currentDate = now.toDateString();
    this.currentTime = now.toLocaleTimeString();
  }

  openFormDialog(): void {
    this.pt_code = ""
    this.pt_description = ""

    const dialogRef = this.dialog.open(this.formDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  inactive(): void {
    this.isFilterActive = false;
    this.productList()
    
  }
  openFilterDialog(): void {
    
    const dialogRef = this.dialog.open(this.filterDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  onNoClick(): void {
    this.dialog.closeAll();
  }

  ptDescription(event:any){
    this.pt_description = event.target.value;
  }

  ptCode(event:any){
    this.pt_code = event.target.value;
  }


  productList(){
    try{

      this.rest.getProductDetails().subscribe((res: any) => {
        if(res.success){
          console.log("product res >>>>>>>>>>>",res)
          this.product_details = res.result;
          this.total_product = this.product_details.length;
        }
      })
    }
    
    catch(e){
      console.log("productList error >>>>",e);
    }
  }

  addMaster(){

    try{

      let data = {

        "pt_code" :  this.pt_code,
        "description" :  this.pt_description
      }

      if(this.pt_code == '' || this.pt_description == ''){
        this.toastr.error('Please fill all the fields', 'Sorry !!', {timeOut: 4000});
      }
      else{
        this.rest.addProductDetails(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success('Product details added', 'Success', {timeOut: 200});
          setTimeout(()=>{
            this.dialog.closeAll();
            this.productList();
          },2000)

        }
      
        },(err:any)=>{
          this.toastr.error(err['error']['message'], 'Sorry !!', {timeOut: 4000});
        })
      }
      
    }catch(e){
      console.log(e);
    }
  }

  updateMaster(){
    try{

      let data = {
        "id"      :this.row_id,
        "pt_code" :  this.pre_pt_code,
        "description" :  this.pre_pt_description
      }

      this.rest.updateProductDetails(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success('Product details updated', 'Success', {timeOut: 1000});
          setTimeout(()=>{
            this.dialog.closeAll();
            this.productList()
          },2000)
        }

      },(err:any)=>{
        this.toastr.error(err['error']['message'], 'Error', {timeOut: 4000});
      })
      // }

    }catch(e){
      console.log(e);
    }

  }

  filterMaster(){
    try{
      
      let data = {
        "pt_code" :  this.pt_code,
        "description" :  this.pt_description
      }

      console.log("product filter data >>>>>",data)
      if(this.pt_code == "" && this.pt_description == ""){
        this.toastr.error('Please fill any data to filter','Error', {timeOut: 4000});
      }
      else{
        this.rest.filterProductDetails(data).subscribe((res: any) => {
        // console.log("res==========>",res)
        if(res.success){
          this.product_details=res.result
          this.total_product = this.product_details.length;
          this.toastr.success('Product details filtered successfully.','Success', {timeOut: 4000});
          this.dialog.closeAll();
          this.p=1
          this.isFilterActive = !this.isFilterActive;
          this.pt_code = ""
          this.pt_description = ""
          
        }
      },(err:any)=>{
        this.toastr.error('Product details not filtered.', 'Error', {timeOut: 4000});
      })
      }
      

    }catch(e){
      console.log(e);
    }

  }

  statusDialog(obj:any,i:any){
    this.row_id = this.product_details[i]['id']
    if(obj['isactive'] == 0){
      obj['isactive'] = 1
    }

    else if(obj['isactive'] == 1){
      obj['isactive'] = 0
    }

    console.log("obj active status >>>>>",obj['isactive'])

    try{

      let data = {
        "id" : this.row_id,
        "deleted" : "0",
        "isactive" : obj['isactive']
      }

      console.log("statusDialog data >>>>>>",data)

      this.rest.deleteProductDetails(data).subscribe((res: any) => {
        if(res.success){
          if(obj['isactive'] == 0){
            this.toastr.success('Product - '+this.pre_pt_code+' has been deactivated', 'Success', {timeOut: 4000});
          }

          else if(obj['isactive'] == 1){
            this.toastr.success('Product - '+this.pre_pt_code+' has been activated', 'Success', {timeOut: 4000});
          }
          
        }
      },(err:any)=>{
        this.toastr.error('Product status is not updating', 'Error', {timeOut: 4000});
      })



    }catch(e){
      console.log(e);
    }

  }


  editProductDetails(press:any,i:any){
    this.row_id = this.product_details[i]['id']
    this.pre_pt_code = this.product_details[i]['pt_code'];
    this.pre_pt_description = this.product_details[i]['description'];


    const dialogRef = this.dialog.open(this.editDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  viewProductDetails(press:any,i:any){
    this.row_id = this.product_details[i]['id']
    this.pre_pt_code = this.product_details[i]['pt_code'];
    this.pre_pt_description = this.product_details[i]['description'];
    
    const dialogRef = this.dialog.open(this.viewDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }


  deleteFormDialog(cont:any,i:any): void {
    this.current_id  = i;
    this.row_header_id = i+1;
    console.log("this.row_header_id >>>>",this.row_header_id)
    this.row_id = this.product_details[i]['id']
    console.log("this.row_id >>>>>>",this.row_id)
    const dialogRef = this.dialog.open(this.deleteDialog, {
      width: '25%',
      height: '35%',
      
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }


  deleteProduct(){
    try{

      let data = {
        "id" : this.row_id,
        "deleted" : "1",
        "isactive" : "0"
      }

      this.rest.deleteProductDetails(data).subscribe((res: any) => {
        if(res.success){
          this.p=1
          this.toastr.success('Product - '+this.pre_pt_code+' has been deleted', 'Success', {timeOut: 4000});
          this.product_details.splice(this.current_id,1);
          this.dialog.closeAll();
          this.productList()
        }
      },(err:any)=>{
        this.toastr.error('Product -'+this.pre_pt_code+' is not deleted', 'Error', {timeOut: 4000});
      })



    }catch(e){
      console.log(e);
    }

    
  }

}
