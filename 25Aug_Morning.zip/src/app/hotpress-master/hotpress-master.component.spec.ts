import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HotpressMasterComponent } from './hotpress-master.component';

describe('HotpressMasterComponent', () => {
  let component: HotpressMasterComponent;
  let fixture: ComponentFixture<HotpressMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HotpressMasterComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(HotpressMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
