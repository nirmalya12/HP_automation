import { Component, ViewChild, TemplateRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { RestApiService } from '../rest-api.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-temperature-master',
  templateUrl: './temperature-master.component.html',
  styleUrl: './temperature-master.component.css'
})
export class TemperatureMasterComponent {

  @ViewChild('formDialog') formDialog!: TemplateRef<any>;
  @ViewChild('editDialog') editDialog!: TemplateRef<any>;
  @ViewChild('viewDialog') viewDialog!: TemplateRef<any>;
  @ViewChild('filterDialog') filterDialog!: TemplateRef<any>;
  @ViewChild('deleteDialog') deleteDialog!: TemplateRef<any>;



  constructor(public dialog: MatDialog, private rest: RestApiService, private toastr: ToastrService){}

  public description : String = '';
  public pc_code  : String = '';
  public pt_code   : String = '';
  public pre_description : String = '';
  public pre_pc_code  : String = ''; 
  public row_id   : String = "";
  public pre_pt_code  : String = '';
  public currentTime : string = "";
  public currentDate : String = "";


  public pc_details   = [];


  public total_pc : number = 0;
  public current_id : number = 0;
  public row_header_id : number = 0;
  public p : number = 1;
  

  public isFilterActive           : boolean= false;

  placeholders = Array(6);

  ngOnInit(): void {
    this.updatedTime()
    // this.pmDetails()
    this.pcList()
    

  }

  updatedTime(){
    const now = new Date();
    this.currentDate = now.toDateString();
    this.currentTime = now.toLocaleTimeString();
  }

  openFormDialog(): void {
    this.pc_code = ""
    this.description = ""
    this.pt_code = ""

    const dialogRef = this.dialog.open(this.formDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  inactive(): void {
    this.isFilterActive = false;
    this.pcList()
    
  }
  openFilterDialog(): void {
    
    const dialogRef = this.dialog.open(this.filterDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  onNoClick(): void {
    this.dialog.closeAll();
  }


  curPcCode(event:any){
    this.pc_code = event.target.value;
    // console.log("event >>>>",this.division_code)
  }

  curDescription(event:any){
    this.description = event.target.value;
  }

  curPTCode(event:any){
    this.pt_code = event.target.value;
  }

  pcList(){
    try{

      this.rest.getPcDetails().subscribe((res: any) => {
        if(res.success){
          console.log("PC res >>>>>>>>>>>",res)
          this.pc_details = res.result;
          this.total_pc = this.pc_details.length;
        }
      })
    }
    
    catch(e){
      console.log("pcList error >>>>",e);
    }
  }

  addMaster(){

    try{

      let data = {

        "pc_code" :  this.pc_code,
        "description" :  this.description,
        "pt_code" : this.pt_code

      }

      if(this.pc_code == '' || this.description == '' || this.pt_code == ''){
        this.toastr.error('Please fill all the fields', 'Sorry !!', {timeOut: 4000});
      }
      else{
        this.rest.addPcDetails(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success('PC details added', 'Success', {timeOut: 200});
          setTimeout(()=>{
            this.dialog.closeAll();
            this.pcList();
          },2000)

        }
      
        },(err:any)=>{
          this.toastr.error(err['error']['message'], 'Sorry !!', {timeOut: 4000});
        })
      }
      
    }catch(e){
      console.log(e);
    }
  }

  updateMaster(){
    try{

      let data = {
        "id"      :this.row_id,
        "pc_code" :  this.pre_pc_code,
        "description" :  this.pre_description,
        "pt_code" : this.pre_pt_code

      }

      this.rest.updatePcDetails(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success('PC details updated', 'Success', {timeOut: 1000});
          setTimeout(()=>{
            this.dialog.closeAll();
            this.pcList()
          },2000)
        }

      },(err:any)=>{
        this.toastr.error(err['error']['message'], 'Error', {timeOut: 4000});
      })

    }catch(e){
      console.log(e);
    }

  }

  filterMaster(){
    try{
      
      let data = {
        "pc_code" :  this.pc_code,
        "description" :  this.description,
        "pt_code" : this.pt_code
      }

      console.log("Temperature data >>>>>",data)
      if(this.pc_code == "" && this.description == "" && this.pt_code == ""){
        this.toastr.error('Please fill any data to filter','Error', {timeOut: 4000});
      }
      else{
        this.rest.filterPcDetails(data).subscribe((res: any) => {
        // console.log("res==========>",res)
        if(res.success){
          this.pc_details=res.result
          this.total_pc = this.pc_details.length;
          this.toastr.success('PC details filtered successfully.','Success', {timeOut: 4000});
          this.dialog.closeAll();
          this.p=1
          this.isFilterActive = !this.isFilterActive;
          this.pc_code = ""
          this.description = ""
          this.pt_code = ""
        }
      },(err:any)=>{
        this.toastr.error('PC details not filtered.', 'Error', {timeOut: 4000});
      })
      }
      

    }catch(e){
      console.log(e);
    }

  }

  statusDialog(obj:any,i:any){
    this.row_id = this.pc_details[i]['id']

    if(obj['isactive'] == 0){
      obj['isactive'] = 1
    }

    else if(obj['isactive'] == 1){
      obj['isactive'] = 0
    }

    console.log("obj active status >>>>>",obj['isactive'])

    try{

      let data = {
        "id" : this.row_id,
        "deleted" : "0",
        "isactive" : obj['isactive']
      }

      console.log("statusDialog data >>>>>>",data)

      this.rest.deletePcDetails(data).subscribe((res: any) => {
        if(res.success){
          if(obj['isactive'] == 0){
            this.toastr.success('PC - '+this.pre_pc_code+' has been deactivated', 'Success', {timeOut: 4000});
          }

          else if(obj['isactive'] == 1){
            this.toastr.success('PC - '+this.pre_pc_code+' has been activated', 'Success', {timeOut: 4000});
          }
          
        }
      },(err:any)=>{
        this.toastr.error('PC status is not updating', 'Error', {timeOut: 4000});
      })



    }catch(e){
      console.log(e);
    }

  }


  editTempDetails(press:any,i:any){
    this.row_id = this.pc_details[i]['id']
    this.pre_description = this.pc_details[i]['description'];
    this.pre_pc_code = this.pc_details[i]['pc_code'];
    this.pre_pt_code = this.pc_details[i]['ptCode'];


    const dialogRef = this.dialog.open(this.editDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  viewTempDetails(press:any,i:any){
    this.row_id = this.pc_details[i]['id']
    this.pre_description = this.pc_details[i]['description'];
    this.pre_pc_code = this.pc_details[i]['pc_code'];
    this.pre_pt_code = this.pc_details[i]['ptCode'];
    
    const dialogRef = this.dialog.open(this.viewDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }


  deleteFormDialog(cont:any,i:any): void {
    this.current_id  = i;
    this.row_header_id = i+1;
    console.log("this.row_header_id >>>>",this.row_header_id)
    this.row_id = this.pc_details[i]['id']
    console.log("this.row_id >>>>>>",this.row_id)
    const dialogRef = this.dialog.open(this.deleteDialog, {
      width: '25%',
      height: '35%',
      
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }


  deletePC(){
    try{

      let data = {
        "id" : this.row_id,
        "deleted" : "1",
        "isactive" : "0"
      }

      this.rest.deletePcDetails(data).subscribe((res: any) => {
        if(res.success){
          this.p=1
          this.toastr.success('PC - '+this.pre_pc_code+' has been deleted', 'Success', {timeOut: 4000});
          this.pc_details.splice(this.current_id,1);
          this.dialog.closeAll();
          this.pcList()
        }
      },(err:any)=>{
        this.toastr.error('PC -'+this.pre_pc_code+' is not deleted', 'Error', {timeOut: 4000});
      })



    }catch(e){
      console.log(e);
    }

    
  }

}
