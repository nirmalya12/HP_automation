import { Component, ViewChild, TemplateRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { RestApiService } from '../rest-api.service';
import { ToastrService } from 'ngx-toastr';

// interface hotPressPMDetails{
//   capacity : number;
//   deleted : string;
//   id : number;
//   pm_code : string;
//   pm_name : string;
//   resource : string;
//   resource_name : string;
//   status : string
// }

@Component({
  selector: 'app-hotpress-master',
  templateUrl: './hotpress-master.component.html',
  styleUrl: './hotpress-master.component.css'
})
export class HotpressMasterComponent {

  @ViewChild('formDialog') formDialog!: TemplateRef<any>;
  @ViewChild('editDialog') editDialog!: TemplateRef<any>;
  @ViewChild('filterDialog') filterDialog!: TemplateRef<any>;
  @ViewChild('deleteDialog') deleteDialog!: TemplateRef<any>;
  @ViewChild('viewDialog') viewDialog!: TemplateRef<any>;

  constructor(public dialog: MatDialog, private rest: RestApiService, private toastr: ToastrService){}

  public selectedPMCode : String = "";
  public selectedPMName : String = "";
  public selectedStatus : String = "";
  public selectedFilStatus : String = "";
  public selectedPress : String = "";
  public pre_resource_name : String = '';
  public pre_machine_name : String = '';
  public pre_pm_name : String = '';
  public pre_pm_code : String = '';
  public pre_quantity : String = '';
  public pre_status : String = '';
  public quantity : String = "";
  public resource : String = "";
  public machine : String = "";
  public row_id : String = "";
  public currentTime : string = "";
  public currentDate  : String = "";



  public all_pm = [];
  public pm_deatils = [];
  public hp_details = [];
  public pc_deatils = [];
  public resource_master = [];
  public pm_master_deatils = [];
  public pc_master_deatils = [];
  public pm_code_master : string[] = [];


  public total_hotpresses : number = 0;
  public row_header_id : number = 0;
  public current_id : number = 0;
  public p : number  = 1;


  public isLoading: boolean = true;
  public isFilterActive : boolean= false;

  placeholders = Array(8);


  ngOnInit(): void {
    this.updatedTime()
    this.hotpressList()
    this.pmDetails()

  }

  updatedTime(){
    const now = new Date();
    this.currentDate = now.toDateString();
    this.currentTime = now.toLocaleTimeString();
  }


  inactive(): void {
    this.isFilterActive = false;
    this.selectedPress = '';
    this.selectedPMCode = '';
    this.selectedFilStatus = '';
    this.hotpressList()
    
  }
  

  openFormDialog(): void {

    this.selectedPMCode = '';
    this.selectedPMName = '';
    this.selectedStatus = '';
    this.quantity = '';
    this.resource = '';
    this.machine = '';

    const dialogRef = this.dialog.open(this.formDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  filterFormDialog():void{
    const dialogRef = this.dialog.open(this.filterDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });

  }

  
  deleteFormDialog(press:any,i:any): void {
    this.current_id  = i;
    this.row_header_id = i+1;
    console.log("this.row_header_id >>>>",this.row_header_id)
    this.row_id = this.hp_details[i]['id']
    console.log("this.row_id >>>>>>",this.row_id)
    const dialogRef = this.dialog.open(this.deleteDialog, {
      width: '25%',
      height: '35%',
      
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }


  onNoClick(): void {
    this.dialog.closeAll();
  }


  pmFilter(){
    this.pm_deatils = this.pm_master_deatils.filter((pm: any) => pm.PM_NAME.toLowerCase().includes(this.selectedPMName))
  }

  pcFilter(){
    this.pc_deatils = this.pc_master_deatils.filter((pm: any) => pm.PM_CODE.toLowerCase().includes(this.selectedPMCode))
  }

  onOptionChange(event: any) {
    console.log("event >>>>>>>",event)
    this.selectedPMCode = event.option.value;
    for(let arr of this.pc_deatils){
      if( arr['PM_CODE'] == this.selectedPMCode){
        console.log("PM Code matched >>>>>.")
        this.selectedPMName = arr['PM_NAME']
      }
    }

    for(let arr of this.pc_deatils){
      if( arr['PM_CODE'] == this.pre_pm_code){
        console.log(" edit PM Code matched >>>>>.")
        this.pre_pm_name = arr['PM_NAME']
      }
    }
  }


  onOptionPMChange(event: any) {
    console.log("event >>>>>>>",event)
    this.selectedPMName = event.option.value;
  }

  onOptionStatusChange(event: any){
    console.log("event >>>>>>>",event)
    this.selectedStatus = event.option.value;
  }

  onOptionPressChange(event:any){
    this.selectedPress = event.option.value;
    console.log("this.selectedPress >>>>>>>>",this.selectedPress)
  }

  onOptionFilterStatusChange(event:any){
    this.selectedFilStatus = event.option.value;
    console.log("this.selectedFilStatus >>>>>>>>",this.selectedFilStatus)
  }

  totalQuantity(event:any){
    this.quantity = event.target.value;
    console.log("event >>>>",this.quantity)
  }

  resourceName(event:any){
    this.resource = event.target.value;
    console.log("event >>>>",this.resource)
  }

  machineNumber(event:any){
    this.machine = event.target.value;
    console.log("event >>>>",this.machine)
  }
  

  pmDetails(){ 

    try{

      this.rest.get_pm_code_details().subscribe((res: any) => {
      if(res.success){
        console.log("res.response >>>>>>>>>",res)
        this.pm_deatils = res.result;
        this.pm_master_deatils = res.result;

        this.pc_deatils = res.result1;
        this.pc_master_deatils = res.result1;
      }
      

      })
    }

    catch(e){
      console.log(e);
    }

  }

  hotpressList(){
    try{

      this.rest.hotPressList().subscribe((res: any) => {
        if(res.success){
          console.log("res Hot>>>>>>>>>>>",res)
          this.hp_details = res.result;
          this.total_hotpresses = this.hp_details.length;
          this.resource_master = res.result1;
          // this.all_pm = this.hp_details.map(item => item.pm_code).filter((value,index,self)=>self.indexOf(value) === index);
          // console.log("this.all_pm >>>>>>",this.all_pm)

          for(let i=0; i<this.hp_details.length; i++){
              if(!this.all_pm.includes(this.hp_details[i]['pm_code'])){
                this.all_pm.push(this.hp_details[i]['pm_code'])
              }            
            
          }

          console.log("all_pm >>>>>",this.all_pm)
         
          console.log("this.total_hotpresses >>>>>>>",this.total_hotpresses)

        }
        this.isLoading = false;
      },(err:any)=>{
        console.log("Hotpress data error >>>>>>")
        this.isLoading = false;
      })
    }
    
    catch(e){
      console.log("hotpressList err >>",e);
      this.isLoading = false;
    }
  }

  addMaster(){

    try{

      let data = {

        "pm_code" :       this.selectedPMCode,
        "pm_name" :       this.selectedPMName,
        "resource" :      this.machine,
        "resource_name" : this.resource,
        "capacity" :      this.quantity,
        "status" :        this.selectedStatus

      }

      console.log("data >>>>",data)

      this.rest.addHotPressMaster(data).subscribe((res: any) => {
      if(res.success){
        this.toastr.success('Hot press details added', 'Success', {timeOut: 4000});
        setTimeout(()=>{
          this.dialog.closeAll();
        },2000)
        this.hotpressList()
      }
      

    },(err:any)=>{
      this.toastr.success(err['error']['message'],'Sorry !!', {timeOut: 4000});
    })

    }catch(e){
      console.log(e);
    }
  }

  updateMaster(){
    try{

      let data = {
        "id" : this.row_id,
        "pm_code" : this.pre_pm_code,
        "pm_name" : this.pre_pm_name,
        "resource" : this.pre_resource_name,
        "resource_name" : this.pre_machine_name,
        "capacity" : this.pre_quantity,
        "status" : this.pre_status
      }
      console.log("data >>>>",data)
      this.rest.updateHotPressMaster(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success('Hot press - '+this.pre_resource_name+' details updated', 'Success', {timeOut: 4000});
          setTimeout(()=>{
            this.dialog.closeAll();
          },2000)
          this.hotpressList()
        }
      },(err:any)=>{
        this.toastr.error('Hot press details not updated.', 'Error', {timeOut: 4000});
      })

    }catch(e){
      console.log(e);
    }
    
  }


  viewHotPressDetails(press:any,i:any){
    this.row_id = this.hp_details[i]['id']
    console.log("this.row_id >>>>>>",this.row_id);
    this.pre_resource_name = this.hp_details[i]['resource'];
    console.log("this.pre_resource_name >>>>>>>",this.pre_resource_name);
    this.pre_machine_name = this.hp_details[i]['resource_name'];
    console.log("this.pre_machine_name >>>>>>>",this.pre_machine_name);
    // this.pre_pm_name = this.hp_details[i]['pm_name'];
    this.pre_pm_name = this.hp_details[i]['PM_NAME'];
    console.log("this.pre_pm_name >>>>>>>",this.pre_pm_name);
    this.pre_pm_code = this.hp_details[i]['pm_code'];
    console.log("this.pre_pm_code >>>>>>>",this.pre_pm_code);
    this.pre_quantity = this.hp_details[i]['capacity'];
    console.log("this.pre_quantity >>>>>>>",this.pre_quantity);
    this.pre_status = this.hp_details[i]['deleted'];
    if(this.pre_status == '0'){
      this.pre_status = 'Running';
    }
    else{
      this.pre_status = 'Under Maintenance';
    }
    console.log("this.pre_status >>>>>>>",this.pre_status);
    const dialogRef = this.dialog.open(this.viewDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });

  }


  editHotPressDetails(press:any,i:any){
    this.row_id = this.hp_details[i]['id']
    console.log("this.row_id >>>>>>",this.row_id);
    this.pre_resource_name = this.hp_details[i]['resource'];
    console.log("this.pre_resource_name >>>>>>>",this.pre_resource_name);
    this.pre_machine_name = this.hp_details[i]['resource_name'];
    console.log("this.pre_machine_name >>>>>>>",this.pre_machine_name);
    // this.pre_pm_name = this.hp_details[i]['pm_name'];
    this.pre_pm_name = this.hp_details[i]['PM_NAME'];
    console.log("this.pre_pm_name >>>>>>>",this.pre_pm_name);
    this.pre_pm_code = this.hp_details[i]['pm_code'];
    console.log("this.pre_pm_code >>>>>>>",this.pre_pm_code);
    this.pre_quantity = this.hp_details[i]['capacity'];
    console.log("this.pre_quantity >>>>>>>",this.pre_quantity);
    this.pre_status = this.hp_details[i]['deleted'];
    if(this.pre_status == '0'){
      this.pre_status = 'Running';
    }
    else{
      this.pre_status = 'Under Maintenance';
    }
    console.log("this.pre_status >>>>>>>",this.pre_status);
    const dialogRef = this.dialog.open(this.editDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  filterMaster(){

    try{

      let data = {
        "pm_code" : this.selectedPMCode,
        "resource" : this.selectedPress,
        "status" : this.selectedFilStatus
      }

      console.log("data >>>>>>",data)

      this.rest.filterHotPress(data).subscribe((res: any) => {
        console.log("res >>>",res)
        if(res.success){
          this.p=1
          this.hp_details = res.result;
          this.total_hotpresses = this.hp_details.length;
          // this.hotpressList()
          setTimeout(()=>{
            this.dialog.closeAll();
            this.isFilterActive = !this.isFilterActive;

            if(this.selectedPMCode!= '' && this.selectedPress!= '' && this.selectedFilStatus!= ''){
              this.toastr.success('Hot Press details is filtered', 'Success', {timeOut: 4000});
            }

            else if(this.selectedPMCode!= ''){
              this.toastr.success('Hot Press details is filtered with PM Code - '+this.selectedPMCode, 'Success', {timeOut: 4000});
            }

            else if(this.selectedPress!= ''){
              this.toastr.success('Hot Press details is filtered with Resource - '+this.selectedPress, 'Success', {timeOut: 4000});
            }

            else if(this.selectedFilStatus!= ''){
              this.toastr.success('Hot Press details is filtered with Status - '+this.selectedFilStatus, 'Success', {timeOut: 4000});
            }

          },2000)

        }
      },(err:any)=>{
        this.toastr.error(err['error']['message'], 'Error', {timeOut: 4000});
      })

    }catch(e){
      console.log("filterMaster err >>>",e)
    }

  }


  deletePress(){

    try{
      console
      let data = {
        "id": this.row_id
      }

      this.rest.deleteHotPress(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success('Hot press - '+this.pre_resource_name+' has been deleted', 'Success', {timeOut: 4000});
          // this.hp_details.splice(i,1);
          this.hp_details.splice(this.current_id,1);
          setTimeout(()=>{
            this.dialog.closeAll();
            this.p=1
          },2000)
          this.hotpressList()
        }
      },(err:any)=>{
        this.toastr.error('Hot press -'+this.pre_resource_name+' is not deleted', 'Error', {timeOut: 4000});
      })

    }catch(e){
      console.log("deletePress err >>",e)
    }

  }

}
