import { Component, ViewChild, TemplateRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { RestApiService } from '../rest-api.service';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-thickness-master',
  templateUrl: './thickness-master.component.html',
  styleUrl: './thickness-master.component.css'
})
export class ThicknessMasterComponent {

  @ViewChild('formDialog') formDialog!: TemplateRef<any>;
  @ViewChild('editDialog') editDialog!: TemplateRef<any>;
  @ViewChild('viewDialog') viewDialog!: TemplateRef<any>;
  @ViewChild('filterDialog') filterDialog!: TemplateRef<any>;
  @ViewChild('deleteDialog') deleteDialog!: TemplateRef<any>;



  constructor(public dialog: MatDialog, private rest: RestApiService, private toastr: ToastrService){}


  public thickness : String = '';
  public description  : String = '';
  public gl_factor   : String = '';
  public na   : String = '';
  public pre_thickness : String = '';
  public pre_description  : String = ''; 
  public row_id   : String = "";
  public pre_gl  : String = '';
  public pre_na  : String = '';
  public currentTime : string = "";
  public currentDate : String = "";


  public thickness_details   = [];


  public total_thickness : number = 0;
  public current_id : number = 0;
  public row_header_id : number = 0;
  public p : number = 1;
  

  public isFilterActive           : boolean= false;

  placeholders = Array(6);

  ngOnInit(): void {
    this.updatedTime()
    // this.pmDetails()
    this.thicknessList()
    

  }

  updatedTime(){
    const now = new Date();
    this.currentDate = now.toDateString();
    this.currentTime = now.toLocaleTimeString();
  }

  openFormDialog(): void {
    this.thickness = ""
    this.description = ""
    this.gl_factor = ""
    this.na = ""

    const dialogRef = this.dialog.open(this.formDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  inactive(): void {
    this.isFilterActive = false;
    this.thicknessList()
    
  }
  openFilterDialog(): void {
    
    const dialogRef = this.dialog.open(this.filterDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  onNoClick(): void {
    this.dialog.closeAll();
  }

  curThickness(event:any){
    this.thickness = event.target.value;
    // console.log("event >>>>",this.division_code)
  }

  curDescription(event:any){
    this.description = event.target.value;
  }

  curFactor(event:any){
    this.gl_factor = event.target.value;
  }

  curNA(event:any){
    this.na = event.target.value;
  }

  

  thicknessList(){
    try{

      this.rest.getThicknessDetails().subscribe((res: any) => {
        if(res.success){
          console.log("thickness res >>>>>>>>>>>",res)
          this.thickness_details = res.result;
          this.total_thickness = this.thickness_details.length;

        }
      })
    }
    
    catch(e){
      console.log("contractorList error >>>>",e);
    }
  }

  addMaster(){

    try{

      let data = {

        "thickness" :  this.thickness,
        "description" :  this.description,
        "NA" : this.na,
        "gl_factor" : this.gl_factor
      }

      if(this.thickness == '' || this.description == '' || this.na == '' || this.gl_factor == ''){
        this.toastr.error('Please fill all the fields', 'Sorry !!', {timeOut: 4000});
      }
      else{
        this.rest.addThicknessDetails(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success('Thickness details added', 'Success', {timeOut: 200});
          setTimeout(()=>{
            this.dialog.closeAll();
            this.thicknessList();
          },2000)

        }
      
        },(err:any)=>{
          this.toastr.error(err['error']['message'], 'Sorry !!', {timeOut: 4000});
        })
      }
      
    }catch(e){
      console.log(e);
    }
  }

  updateMaster(){
    try{

      let data = {
        "id"      :this.row_id,
        "thickness" :  this.pre_thickness,
        "description" :  this.pre_description,
        "NA" : this.pre_na,
        "gl_factor" : this.pre_gl
      }

      // if(this.pre_ppm_code == '' || this.pre_contractor_code == '' || this.pre_contractor_name == ''){
      //   this.toastr.error('Please fill all the fields.', 'Error', {timeOut: 4000});
      // }

      // else{
      this.rest.updateThicknessDetails(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success('Size details updated', 'Success', {timeOut: 1000});
          setTimeout(()=>{
            this.dialog.closeAll();
            this.thicknessList()
          },2000)
        }

      },(err:any)=>{
        this.toastr.error(err['error']['message'], 'Error', {timeOut: 4000});
      })
      // }

    }catch(e){
      console.log(e);
    }

  }

  filterMaster(){
    try{
      
      let data = {
        "thickness" :  this.thickness,
        "description" :  this.description,
        "NA" : this.na,
        "gl_factor" : this.gl_factor
      }

      console.log("size data >>>>>",data)
      if(this.thickness == "" && this.description == "" && this.na == "" && this.gl_factor == ""){
        this.toastr.error('Please fill any data to filter','Error', {timeOut: 4000});
      }
      else{
        this.rest.filterThicknessDetails(data).subscribe((res: any) => {
        // console.log("res==========>",res)
        if(res.success){
          this.thickness_details=res.result
          this.total_thickness = this.thickness_details.length;
          this.toastr.success('Thickness details filtered successfully.','Success', {timeOut: 4000});
          this.dialog.closeAll();
          this.p=1
          this.isFilterActive = !this.isFilterActive;
          this.thickness = ""
          this.description = ""
          this.na = ""
          this.gl_factor = ""
        }
      },(err:any)=>{
        this.toastr.error('Thickness details not filtered.', 'Error', {timeOut: 4000});
      })
      }
      

    }catch(e){
      console.log(e);
    }

  }

  statusDialog(obj:any,i:any){
    this.row_id = this.thickness_details[i]['id']
    if(obj['isactive'] == 0){
      obj['isactive'] = 1
    }

    else if(obj['isactive'] == 1){
      obj['isactive'] = 0
    }

    console.log("obj active status >>>>>",obj['isactive'])

    try{

      let data = {
        "id" : this.row_id,
        "deleted" : "0",
        "isactive" : obj['isactive']
      }

      console.log("statusDialog data >>>>>>",data)

      this.rest.deletePlantDetails(data).subscribe((res: any) => {
        if(res.success){
          if(obj['isactive'] == 0){
            this.toastr.success('Thickness - '+this.pre_thickness+' has been deactivated', 'Success', {timeOut: 4000});
          }

          else if(obj['isactive'] == 1){
            this.toastr.success('Thickness - '+this.pre_thickness+' has been activated', 'Success', {timeOut: 4000});
          }
          
        }
      },(err:any)=>{
        this.toastr.error('Thickness status is not updating', 'Error', {timeOut: 4000});
      })



    }catch(e){
      console.log(e);
    }

  }


  editSizeDetails(press:any,i:any){
    this.row_id = this.thickness_details[i]['id']
    this.pre_thickness = this.thickness_details[i]['thickness'];
    this.pre_gl = this.thickness_details[i]['gl_factor'];
    this.pre_description = this.thickness_details[i]['description'];
    this.pre_na = this.thickness_details[i]['NA'];


    const dialogRef = this.dialog.open(this.editDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  viewSizeDetails(press:any,i:any){
    this.row_id = this.thickness_details[i]['id']
    this.pre_thickness = this.thickness_details[i]['thickness'];
    this.pre_gl = this.thickness_details[i]['gl_factor'];
    this.pre_description = this.thickness_details[i]['description'];
    this.pre_na = this.thickness_details[i]['NA'];
    
    const dialogRef = this.dialog.open(this.viewDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }


  deleteFormDialog(cont:any,i:any): void {
    this.current_id  = i;
    this.row_header_id = i+1;
    console.log("this.row_header_id >>>>",this.row_header_id)
    this.row_id = this.thickness_details[i]['id']
    console.log("this.row_id >>>>>>",this.row_id)
    const dialogRef = this.dialog.open(this.deleteDialog, {
      width: '25%',
      height: '35%',
      
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }


  deleteThickness(){
    try{

      let data = {
        "id" : this.row_id,
        "deleted" : "1",
        "isactive" : "0"
      }

      this.rest.deleteThicknessDetails(data).subscribe((res: any) => {
        if(res.success){
          this.p=1
          this.toastr.success('Thickness - '+this.pre_description+' has been deleted', 'Success', {timeOut: 4000});
          this.thickness_details.splice(this.current_id,1);
          this.dialog.closeAll();
          this.thicknessList()
        }
      },(err:any)=>{
        this.toastr.error('Thickness -'+this.pre_description+' is not deleted', 'Error', {timeOut: 4000});
      })



    }catch(e){
      console.log(e);
    }

    
  }

}
