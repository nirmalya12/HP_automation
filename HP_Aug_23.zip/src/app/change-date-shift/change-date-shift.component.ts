import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RestApiService } from '../rest-api.service';
import { ToastrService } from 'ngx-toastr';



interface PreSavedData {
  ct_code_name: string;
  di_name_code: string;
  dm_name_code: string;
  id: number;
  machine_name: string;
  operator_name: string;
  pm_code_name: string;
  resource_name: string;
  sc_name: string;
  sm_code_name: string;
  supervisor_name: string;
  user_name: string;
}

interface SearchDetail {
  [key: string]: any; // Allow additional properties dynamically
  id: number;
  isSelected?: boolean;
  start_time?: string;
  end_time?: string;
  PC_CODE?: string;
  size?: string;
  thickness?: string;
  item?: string;
  remark?: string;
  quantity?: string;
}


@Component({
  selector: 'app-change-date-shift',
  templateUrl: './change-date-shift.component.html',
  styleUrl: './change-date-shift.component.css'
})
export class ChangeDateShiftComponent {

  public pre_saved_data : PreSavedData= {
      ct_code_name: '',
      di_name_code: '',
      dm_name_code: '',
      id: 0,
      machine_name: '',
      operator_name: '',
      pm_code_name: '',
      resource_name: '',
      sc_name: '',
      sm_code_name: '',
      supervisor_name: '',
      user_name: ''
  };

  public dashFromDate : String = '';
  public dashToDate : String = '';
  public selectedPMCode : String = '';
  public selectedContractor : String = '';
  public selectedDICode : String = '';
  public selectedDMCode : String = '';
  public selectedMNCode : String = '';
  public selectedOperator : String = '';
  public selectedResourceCode : String = '';
  public selectedShiftCode : String = '';
  public selectedSMCode : String = '';
  public selectedSuperVisor : String = '';
  public selectedFromShiftCode : String = '';
  public selectedToShiftCode : String = '';
  public finalCode : String = '';
  public row_id : String = '';
  public to_row_id : String = '';


  public selectedIndex : number = 0;

  public shift_deatils = [];
  public search_details : SearchDetail[] = [];
  // public search_details = [];
  // public selectedItems = [];
  public selectedItems: SearchDetail[] = [];
  public selectedIndices: number[] = [];
  public selectedGroups: { [key: string]: number[] } = {};
  public selectedDetails: SearchDetail= {
    id: 0,
    isSelected: false,
    start_time: '',
    end_time: '',
    PC_CODE: '',
    size: '',
    thickness: '',
    item: '',
    remark: '',
    quantity: ''
  };


  ngOnInit(){

    // this.shiftDetails()
    this.resourceDetails()

    // this.shiftDetails(this.finalCode)
    this.dashFromDate = this.todayDateDate();
    console.log("this.dashDate >>>>>",this.dashFromDate)
  }

  constructor(private router: Router, private rest: RestApiService, private toastr: ToastrService){}


  todayDateDate(): any {
    const today = new Date;
    const dd = String(today.getDate()).padStart(2, '0');
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const yyyy = today.getFullYear();

    const todaydate = yyyy + '-' + mm + '-' + dd;

    return todaydate;

  }

  onOptionFromShiftChange(event:any){
    console.log("event >>>>>>>",event)
    this.selectedFromShiftCode = event.option.value;
    console.log('Selected shift :', this.selectedFromShiftCode);
    for(let item of this.shift_deatils){
      if(this.selectedFromShiftCode == item['sc_name']){
        this.row_id = item['id']
        console.log("this.row_id >>>>>>>",this.row_id)
      }
    }
  }

  onOptionFromToChange(event:any){
    console.log("event >>>>>>>",event)
    this.selectedToShiftCode = event.option.value;
    console.log('Selected shift :', this.selectedToShiftCode);
    for(let item of this.shift_deatils){
      if(this.selectedToShiftCode == item['sc_name']){
        this.to_row_id = item['id']
        console.log("this.to_row_id >>>>>>>",this.to_row_id)
      }
    }
  }

  resourceDetails(){

    try{
      let data = {
      "user_name" : localStorage.getItem('username')
    }
    console.log("data >>>>>>>>>",data)
    this.rest.preResourceInfo(data).subscribe((res: any) => {
      if(res.success){
        console.log("res >>>>>>>>",res)
        this.toastr.success('Resource Information for user name - '+localStorage.getItem('username'), 'Success', {timeOut: 4000});
        this.pre_saved_data = res.result;
        console.log("this.pre_saved_data >>>>>>>",this.pre_saved_data)
        this.selectedPMCode = this.pre_saved_data['pm_code_name'];
        console.log("this.selectedPMCode >>>>>>>>>",this.selectedPMCode)
        this.selectedContractor = this.pre_saved_data['ct_code_name'];
        console.log("this.selectedContractor >>>>>>>>>",this.selectedContractor)
        this.selectedDICode = this.pre_saved_data['di_name_code'];
        console.log("this.selectedDICode >>>>>>>>>",this.selectedDICode)
        this.selectedDMCode = this.pre_saved_data['dm_name_code'];
        console.log("this.selectedDMCode >>>>>>>>>",this.selectedDMCode)
        this.selectedMNCode = this.pre_saved_data['machine_name'];
        console.log("this.selectedMNCode >>>>>>>>>",this.selectedMNCode)
        this.selectedOperator = this.pre_saved_data['operator_name'];
        console.log("this.selectedOperator >>>>>>>>>",this.selectedOperator)
        this.selectedResourceCode = this.pre_saved_data['resource_name'];
        console.log("this.selectedResourceCode >>>>>>>>>",this.selectedResourceCode)
        this.selectedShiftCode = this.pre_saved_data['sc_name'];
        console.log("this.selectedShiftCode >>>>>>>>>",this.selectedShiftCode)
        this.selectedSMCode = this.pre_saved_data['sm_code_name'];
        console.log("this.selectedSMCode >>>>>>>>>",this.selectedSMCode)
        this.selectedSuperVisor = this.pre_saved_data['supervisor_name'];
        console.log("this.selectedSuperVisor >>>>>>>>>",this.selectedSuperVisor)

        
        this.shiftDetails(this.selectedPMCode)
      }

      else{
        this.toastr.error('Something went wrong', 'Error', {timeOut: 4000});
      }
      

      })

    // return this.selectedPMCode;

    }catch(e){
      console.log("resourceDetails err >",e)
    }
  }

  shiftDetails(pmCode:String){

    try{
        console.log("pmCode >>>>>>>",pmCode)
    //   let data = {
    //   "PM_CODE": this.selectedPMCode.split("(")[1].replace(")","").trim()
    // }

    // this.finalCode = this.resourceDetails()
    // console.log("this.finalCode >>>>>>>>>",this.finalCode)

    let data = {
      "PM_CODE": pmCode.split("(")[1].replace(")","").trim()
    }
    console.log("data >>>>>>",JSON.stringify(data))
    this.rest.get_shift_details(data).subscribe((res: any) => {
      if(res.success){
        // console.log(">>>> res.response >>>>>>>>>",res.result)
        // this.toastr.success('Shift details fetched', 'Success', {timeOut: 4000});
        this.shift_deatils = res.result;
        console.log("this.shift_deatils >>>>>>>>",this.shift_deatils);
      }
      

    })

    }catch(e){
      console.log("shiftDetails err >",e)
    }

    

  }

  searchDateShift(){

    try{
      console.log("this.row_id >>>>>>>",this.row_id)
      let data ={
        "shift_date": this.dashFromDate,
        "id": this.row_id
      }

      this.rest.getSearchMaster(data).subscribe((res: any) => {
      if(res.success){
        console.log(">>>> res.response >>>>>>>>>",res.result)
        this.search_details = res.result;
        for (let i = 0; i < this.search_details.length; i++) {
          if(i < 1){
            console.log("AAAAAAA")
            this.search_details[i]['sl'] = i+1;
            console.log("this.search_details[i]['sl'] >>>>>",this.search_details[i]['sl'])
            this.search_details[i]['slNo'] = i+1;
            console.log("this.search_details[i]['slNo'] >>>>>",this.search_details[i]['slNo'])
          }
          else if(i >= 1){
            console.log("BBBBBBBBB")
            console.log("res.result[i-1]['header_id'] >>>>>>>",res.result[i-1]['header_id'])
            console.log("res.result[i-1]['header_id'] >>>>>>>",res.result[i]['header_id'])
            if(res.result[i-1]['header_id'] != res.result[i]['header_id']){
              console.log("CCCCCCC")
              console.log("this.search_details[i]['sl'] >>>>>>>",this.search_details[i]['sl'])
              console.log("this.search_details[i-1]['sl']+1; >>>>>>>>",this.search_details[i-1]['sl']+1)
              this.search_details[i]['sl'] = this.search_details[i-1]['sl']+1;
              console.log("this.search_details[i]['sl'] >>>>>>>>>",this.search_details[i]['sl'])
              this.search_details[i]['slNo'] = this.search_details[i-1]['sl']+1;
              console.log("this.search_details[i]['slNo'] >>>>>>>>>",this.search_details[i]['slNo'])
            }else{
              console.log("")
              this.search_details[i]['sl'] = this.search_details[i-1]['sl'];
              this.search_details[i]['slNo'] = ''
            }
          }
        }
      }
      

      })

    }catch(e){
      console.log("searchDateShift err >>>",e)
    }
  }


  onCheckboxChange(item: SearchDetail,selectedCheckBoxId : number) {

    try{

      if (item.isSelected) {
        this.selectedItems.push(item);
        console.log("this.selectedItems >>>>",this.selectedItems)
        this.selectedDetails = item;
        console.log("this.selectedDetails >>>",this.selectedDetails)
        // this.selectedIndex = selectedCheckBoxId;
        // this.selectedIndices = this.search_details
        //   .map((row, idx) => row['slNo'] === item['slNo'] ? idx : -1)
        //   .filter(idx => idx !== -1);

        let startIndex = selectedCheckBoxId;
        let endIndex = selectedCheckBoxId;

        // Move backwards to find the start index of the group
        while (startIndex > 0 && this.search_details[startIndex - 1]['slNo'] === '') {
          startIndex--;
        }

        // Move forwards to find the end index of the group
        while (endIndex < this.search_details.length - 1 && this.search_details[endIndex + 1]['slNo'] === '') {
          endIndex++;
        }

        // Store the indices range
        const indices = [];
        for (let i = startIndex; i <= endIndex; i++) {
          // this.selectedIndices.push(i);
          indices.push(i);
        }

        console.log("indices >>>>>>.",indices)

        this.selectedGroups[item['slNo']] = indices;

      } else {
        const index = this.selectedItems.findIndex(selectedItem => selectedItem['id'] === item['id']);
        console.log("index >>>>>>>>>",index)
        if (index !== -1) {
          this.selectedItems.splice(index, 1);
        }
        delete this.selectedGroups[item['slNo']];

        // this.selectedIndices = [];
      }
      console.log(this.selectedItems);
    }
    catch(e){
      console.log("onCheckboxChange err >>>>>>>",e)
    }
    
  }

  transferButton(){
    try{
        var tempArr = []
        console.log("this.selectedDetails >>>>>>>",this.selectedDetails['PC_CODE'],this.selectedDetails['thickness']);
        for (let item of this.selectedItems){
          tempArr.push(item['id'])
        }
        console.log("tempArr >>>>>>>>",tempArr)
        // let data = {
        //   "PC_CODE" : this.selectedDetails['PC_CODE'],
        //   "size" :  this.selectedDetails['size'],
        //   "thickness" : this.selectedDetails['thickness'],
        //   "item" : this.selectedDetails['item'],
        //   "remark" : this.selectedDetails['remark'],
        //   "quantity" : this.selectedDetails['quantity'],
        //   "remark1" : 'test',
        //   "id" : this.selectedDetails['id'],
        //   "header_id" : this.selectedDetails['header_id'],
        //   "hpdId" : this.selectedDetails['hpdId']
        // }


        let data = {
          "date" : this.dashToDate,
          "shift" :  this.to_row_id,
          "hpdId" : tempArr
        }

        this.rest.transferShiftDetails(data).subscribe((res: any) => {
          if(res.success){
            // console.log(">>>> res.response >>>>>>>>>",res.result)
            this.toastr.success('Shift details transfered successfully','Success',{timeOut:4000})
            // this.search_details.splice(this.selectedIndex,1);
            
            // this.selectedIndices.sort((a, b) => b - a); // Sort indices in descending order
            // for (const idx of this.selectedIndices) {
            //     this.search_details.splice(idx, 1);
            // }

            const slNo = this.selectedDetails['slNo'];
            if (this.selectedGroups[slNo]) {
              this.selectedGroups[slNo].sort((a, b) => b - a); // Sort indices in descending order
              for (const idx of this.selectedGroups[slNo]) {
                this.search_details.splice(idx, 1);
              }
              // delete this.selectedGroups[slNo]; // Clear the indices for the slNo
            }
                  
            // this.searchDateShift()
          }
        },(err:any)=>{
          if(this.dashToDate === '' || this.to_row_id === ''){
            this.toastr.error('Please provide values for To Date & To Shift', 'Error', {timeOut: 4000});
          }

          else if(tempArr.length == 0){
            this.toastr.error('Please click on at least one checkbox to transfer', 'Error', {timeOut: 4000});
          }
        
      })

    }
    catch(e){
      console.log("transferButton err >>>>>",e)
    }
    
  }



}

// https://plnkr.co/edit/hJSoqXHsHZEDRjPu1CMJ?p=preview&preview
