import { Component, ViewChild, TemplateRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { RestApiService } from '../rest-api.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-contractor-master',
  templateUrl: './contractor-master.component.html',
  styleUrl: './contractor-master.component.css'
})
export class ContractorMasterComponent {

  @ViewChild('formDialog') formDialog!: TemplateRef<any>;
  @ViewChild('editDialog') editDialog!: TemplateRef<any>;
  @ViewChild('viewDialog') viewDialog!: TemplateRef<any>;
  @ViewChild('filterDialog') filterDialog!: TemplateRef<any>;
  @ViewChild('deleteDialog') deleteDialog!: TemplateRef<any>;



  constructor(public dialog: MatDialog, private rest: RestApiService, private toastr: ToastrService){}


  public pre_contractor_name        : String = '';
  public pre_contractor_code        : String = '';
  public contractor_name                 : String = "";
  public contractor_code            : String = "";
  public selectedPMCode            : String = "";
  public pre_pm_code            : String = "";
  // public filtering_division_code  : String = "";
  // public filtering_division       : String = "";  
  public row_id                   : String = "";
  // public division_details_id      : String = "";
  public currentTime              : string = "";
  public currentDate              : String = "";
  public filtered_contractor_name              : String = "";
  public filtered_contractor_code              : String = "";


  public pm_details  = [];
  public contractor_details   = [];
  // public pm_master_deatils  = [];
  // public pc_master_deatils  = [];
  public all_contractor_code  = [];
  public all_contractor_name  = [];
  public all_pm_code  = [];



  public total_contractor           : number = 0;
  public p                        : number = 1;
  public row_header_id        : number = 0;
  public current_id              : number = 0;

  public isFilterActive           : boolean= false;
  // public division_names                     : any;
  // public all_division_names                 : String[]= [];
  // public division_codes                     : any;
  // public all_division_codes                 : String[]= [];

  placeholders = Array(6);

  ngOnInit(): void {
    this.updatedTime()
    this.pmDetails()
    this.contractorList()
    

  }

  updatedTime(){
    const now = new Date();
    this.currentDate = now.toDateString();
    this.currentTime = now.toLocaleTimeString();
  }

  openFormDialog(): void {
    this.contractor_name = ""
    this.contractor_code = ""
    this.selectedPMCode = ""

    const dialogRef = this.dialog.open(this.formDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  inactive(): void {
    this.isFilterActive = false;
    this.contractorList()
    
  }
  openFilterDialog(): void {
    
    const dialogRef = this.dialog.open(this.filterDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  onNoClick(): void {
    this.dialog.closeAll();
  }

  onOptionChange(event: any) {
    console.log("event >>>>>>>",event)
    this.selectedPMCode = event.target.value;
    console.log("this.selectedPMCode >>>>",this.selectedPMCode)
  }

  onOptionContNameChange (event:any){
    this.filtered_contractor_name = event.target.value;
  }

  onOptionContCodeChange (event:any){
    this.filtered_contractor_code = event.target.value;
  }


  editOptionChange(event: any){
    this.selectedPMCode = event.target.value;
    console.log("this.selectedPMCode >>>>",this.selectedPMCode)
  }

  contractorName(event:any){
    this.contractor_name = event.target.value;
    // console.log("event >>>>",this.division)
  }

  contractorCode(event:any){
    this.contractor_code = event.target.value;
    // console.log("event >>>>",this.division_code)
  }
  

  pmDetails(){
     
    try{

      this.rest.getPMDetails().subscribe((res: any) => {
      if(res.success){
        console.log("res.response >>>>>>>>>",res)
        this.pm_details = res.result;
        // this.pm_master_deatils = res.result;
      }
      

      })
    }

    catch(e){
      console.log(e);
    }

  }

  contractorList(){
    try{

      this.rest.getContractorDetails().subscribe((res: any) => {
        if(res.success){
          console.log("cont res >>>>>>>>>>>",res)
          this.contractor_details = res.result;
          this.total_contractor = this.contractor_details.length;
          for(let i =0;i<this.contractor_details.length;i++){
            if(!this.all_contractor_code.includes(this.contractor_details[i]['CT_CODE'])){
              this.all_contractor_code.push(this.contractor_details[i]['CT_CODE'])
            }
            

            if(!this.all_contractor_name.includes(this.contractor_details[i]['CT_NAME'])){
              this.all_contractor_name.push(this.contractor_details[i]['CT_NAME'])
            }

            if(!this.all_pm_code.includes(this.contractor_details[i]['PM_CODE'])){
              this.all_pm_code.push(this.contractor_details[i]['PM_CODE'])
            }
            
          }

          console.log("all_contractor_code >",this.all_contractor_code)
          console.log("all_contractor_name >",this.all_contractor_name)

        }
      })
    }
    
    catch(e){
      console.log("contractorList error >>>>",e);
    }
  }

  addMaster(){

    try{

      let data = {

        "PM_CODE" :  this.selectedPMCode,
        "CT_CODE" :  this.contractor_code,
        "CT_NAME" :  this.contractor_name

      }

      if(this.selectedPMCode == '' || this.contractor_code == '' || this.contractor_name == ''){
        this.toastr.error('Please fill all the fields', 'Sorry !!', {timeOut: 4000});
      }
      else{
        this.rest.addContractor(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success('Contractor details added', 'Success', {timeOut: 200});
          setTimeout(()=>{
            this.dialog.closeAll();
            this.contractorList();
          },2000)

        }
      
        },(err:any)=>{
          this.toastr.error(err['error']['message'], 'Sorry !!', {timeOut: 4000});
        })
      }
      
    }catch(e){
      console.log(e);
    }
  }

  updateMaster(){
    try{

      let data = {
        "id"      :this.row_id,
        "PM_CODE" :  this.pre_pm_code,
        "CT_CODE" :  this.pre_contractor_code,
        "CT_NAME" :  this.pre_contractor_name
      }

      if(this.pre_pm_code == '' || this.pre_contractor_code == '' || this.pre_contractor_name == ''){
        this.toastr.error('Please fill all the fields.', 'Error', {timeOut: 4000});
      }

      else{
          this.rest.updateContractor(data).subscribe((res: any) => {
            if(res.success){
              this.toastr.success(this.pre_contractor_name+' details updated', 'Success', {timeOut: 4000});
              setTimeout(()=>{
                this.dialog.closeAll();
                this.contractorList()
              },2000)
            }

          },(err:any)=>{
            this.toastr.error(err['error']['message'], 'Error', {timeOut: 4000});
          })
      }

    }catch(e){
      console.log(e);
    }

  }

  filterMaster(){
    try{
      
      let data = {
        "PM_CODE" :this.selectedPMCode,
        "CT_CODE" :this.filtered_contractor_code,
        "CT_NAME" :this.filtered_contractor_name
      }
      if(this.selectedPMCode == "" && this.filtered_contractor_code =="" && this.filtered_contractor_name == ""){
        this.toastr.error('Please fill any data to filter','Error', {timeOut: 4000});
      }
      else{
        this.rest.filterContractorDetails(data).subscribe((res: any) => {
        
        if(res.success){
          console.log("res==========>",res)
          this.contractor_details=res.result
          this.total_contractor = this.contractor_details.length;
          this.toastr.success('Contractor details filtered successfully.','Success', {timeOut: 4000});
          this.dialog.closeAll();
          this.p=1
          this.isFilterActive = !this.isFilterActive;
          this.filtered_contractor_code="";
          this.filtered_contractor_name="";
          this.selectedPMCode="";
        }
      },(err:any)=>{
        this.toastr.error('Contractor details not filtered.', 'Error', {timeOut: 4000});
      })
      }
      

    }catch(e){
      console.log(e);
    }

  }

  statusDialog(obj:any,i:any){
    this.row_id = this.contractor_details[i]['id']
    if(obj['isactive'] == 0){
      obj['isactive'] = 1
    }

    else if(obj['isactive'] == 1){
      obj['isactive'] = 0
    }

    console.log("obj active status >>>>>",obj['isactive'])

    try{

      let data = {
        "id" : this.row_id,
        "deleted" : "0",
        "isactive" : obj['isactive']
      }

      console.log("statusDialog data >>>>>>",data)

      this.rest.deleteContractor(data).subscribe((res: any) => {
        if(res.success){
          if(obj['isactive'] == 0){
            this.toastr.success('Contractor - '+this.pre_contractor_name+' has been deactivated', 'Success', {timeOut: 4000});
          }

          else if(obj['isactive'] == 1){
            this.toastr.success('Contractor - '+this.pre_contractor_name+' has been activated', 'Success', {timeOut: 4000});
          }
          
        }
      },(err:any)=>{
        this.toastr.error('Contractor status is not updating', 'Error', {timeOut: 4000});
      })



    }catch(e){
      console.log(e);
    }

  }


  editContractorDetails(press:any,i:any){
    this.row_id = this.contractor_details[i]['id']
    this.pre_contractor_name = this.contractor_details[i]['CT_NAME'];
    this.pre_contractor_code = this.contractor_details[i]['CT_CODE'];
    this.pre_pm_code = this.contractor_details[i]['PM_CODE'];

    const dialogRef = this.dialog.open(this.editDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  viewContractorDetails(press:any,i:any){
    this.pre_contractor_name = this.contractor_details[i]['CT_NAME'];
    this.pre_contractor_code = this.contractor_details[i]['CT_CODE'];
    this.pre_pm_code = this.contractor_details[i]['PM_CODE'];

    const dialogRef = this.dialog.open(this.viewDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }


  deleteFormDialog(cont:any,i:any): void {
    this.current_id  = i;
    this.row_header_id = i+1;
    console.log("this.row_header_id >>>>",this.row_header_id)
    this.row_id = this.contractor_details[i]['id']
    console.log("this.row_id >>>>>>",this.row_id)
    const dialogRef = this.dialog.open(this.deleteDialog, {
      width: '25%',
      height: '35%',
      
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }


  deleteContractor(){
    try{

      let data = {
        "id" : this.row_id,
        "deleted" : "1",
        "isactive" : "0"
      }

      this.rest.deleteContractor(data).subscribe((res: any) => {
        if(res.success){
          this.p=1
          this.toastr.success('Contractor - '+this.pre_contractor_name+' has been deleted', 'Success', {timeOut: 4000});
          this.contractor_details.splice(this.current_id,1);
          this.dialog.closeAll();
        }
      },(err:any)=>{
        this.toastr.error('Contractor -'+this.pre_contractor_name+' is not deleted', 'Error', {timeOut: 4000});
      })



    }catch(e){
      console.log(e);
    }

    
  }

}
