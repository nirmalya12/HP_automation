import { Component, ViewChild, TemplateRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { RestApiService } from '../rest-api.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-size-master',
  templateUrl: './size-master.component.html',
  styleUrl: './size-master.component.css'
})
export class SizeMasterComponent {

  @ViewChild('formDialog') formDialog!: TemplateRef<any>;
  @ViewChild('editDialog') editDialog!: TemplateRef<any>;
  @ViewChild('viewDialog') viewDialog!: TemplateRef<any>;
  @ViewChild('filterDialog') filterDialog!: TemplateRef<any>;
  @ViewChild('deleteDialog') deleteDialog!: TemplateRef<any>;



  constructor(public dialog: MatDialog, private rest: RestApiService, private toastr: ToastrService){}

  public size : String = '';
  public sqm  : String = '';
  public matric   : String = '';
  public pre_size : String = '';
  public pre_sqm  : String = ''; 
  public row_id   : String = "";
  public pre_matric  : String = '';
  public currentTime : string = "";
  public currentDate : String = "";


  public pm_details  = [];
  public size_details   = [];


  public total_size : number = 0;
  public current_id : number = 0;
  public row_header_id : number = 0;
  public p : number = 1;
  

  public isFilterActive           : boolean= false;

  placeholders = Array(6);

  ngOnInit(): void {
    this.updatedTime()
    // this.pmDetails()
    this.sizeList()
    

  }

  updatedTime(){
    const now = new Date();
    this.currentDate = now.toDateString();
    this.currentTime = now.toLocaleTimeString();
  }

  openFormDialog(): void {
    this.size = ""
    this.matric = ""
    this.sqm = ""

    const dialogRef = this.dialog.open(this.formDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  inactive(): void {
    this.isFilterActive = false;
    this.sizeList()
    
  }
  openFilterDialog(): void {
    
    const dialogRef = this.dialog.open(this.filterDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  onNoClick(): void {
    this.dialog.closeAll();
  }

  // onOptionChange(event: any) {
  //   console.log("event >>>>>>>",event)
  //   this.selectedPMCode = event.target.value;
  //   console.log("this.selectedPMCode >>>>",this.selectedPMCode)
  // }

  // onOptionContNameChange (event:any){
  //   this.filtered_contractor_name = event.target.value;
  // }

  // onOptionContCodeChange (event:any){
  //   this.filtered_contractor_code = event.target.value;
  // }


  // editOptionChange(event: any){
  //   this.selectedPMCode = event.target.value;
  //   console.log("this.selectedPMCode >>>>",this.selectedPMCode)
  // }

  // contractorName(event:any){
  //   this.contractor_name = event.target.value;
  //   // console.log("event >>>>",this.division)
  // }

  curSize(event:any){
    this.size = event.target.value;
    // console.log("event >>>>",this.division_code)
  }

  curMatric(event:any){
    this.matric = event.target.value;
  }

  curSqm(event:any){
    this.sqm = event.target.value;
  }
  

  // pmDetails(){
     
  //   try{

  //     this.rest.getPMDetails().subscribe((res: any) => {
  //     if(res.success){
  //       console.log("res.response >>>>>>>>>",res)
  //       this.pm_details = res.result;
  //       // this.pm_master_deatils = res.result;
  //     }
      

  //     })
  //   }

  //   catch(e){
  //     console.log(e);
  //   }

  // }

  sizeList(){
    try{

      this.rest.getSizeDetails().subscribe((res: any) => {
        if(res.success){
          console.log("size res >>>>>>>>>>>",res)
          this.size_details = res.result;
          this.total_size = this.size_details.length;
          // for(let i =0;i<this.size_details.length;i++){
          //   if(!this.all_contractor_code.includes(this.size_details[i]['CT_CODE'])){
          //     this.all_contractor_code.push(this.size_details[i]['CT_CODE'])
          //   }
            

          //   if(!this.all_contractor_name.includes(this.size_details[i]['CT_NAME'])){
          //     this.all_contractor_name.push(this.size_details[i]['CT_NAME'])
          //   }

          //   if(!this.all_pm_code.includes(this.size_details[i]['PM_CODE'])){
          //     this.all_pm_code.push(this.size_details[i]['PM_CODE'])
          //   }
            
          // }

          // console.log("all_contractor_code >",this.all_contractor_code)
          // console.log("all_contractor_name >",this.all_contractor_name)

        }
      })
    }
    
    catch(e){
      console.log("contractorList error >>>>",e);
    }
  }

  addMaster(){

    try{

      let data = {

        "size" :  this.size,
        "matric" :  this.matric,
        "SQM" : this.sqm

      }

      if(this.size == '' || this.matric == '' || this.sqm == ''){
        this.toastr.error('Please fill all the fields', 'Sorry !!', {timeOut: 4000});
      }
      else{
        this.rest.addSizeDetails(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success('Size details added', 'Success', {timeOut: 200});
          setTimeout(()=>{
            this.dialog.closeAll();
            this.sizeList();
          },2000)

        }
      
        },(err:any)=>{
          this.toastr.error(err['error']['message'], 'Sorry !!', {timeOut: 4000});
        })
      }
      
    }catch(e){
      console.log(e);
    }
  }

  updateMaster(){
    try{

      let data = {
        "id"      :this.row_id,
        "size" :  this.pre_size,
        "matric" :  this.pre_matric,
        "SQM" : this.pre_sqm
      }

      // if(this.pre_ppm_code == '' || this.pre_contractor_code == '' || this.pre_contractor_name == ''){
      //   this.toastr.error('Please fill all the fields.', 'Error', {timeOut: 4000});
      // }

      // else{
      this.rest.updateSizeDetails(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success('Size details updated', 'Success', {timeOut: 1000});
          setTimeout(()=>{
            this.dialog.closeAll();
            this.sizeList()
          },2000)
        }

      },(err:any)=>{
        this.toastr.error(err['error']['message'], 'Error', {timeOut: 4000});
      })
      // }

    }catch(e){
      console.log(e);
    }

  }

  filterMaster(){
    try{
      
      let data = {
        "size" :  this.size,
        "matric" :  this.matric,
        "SQM" : this.sqm
      }

      console.log("size data >>>>>",data)
      if(this.size == "" && this.matric == "" && this.sqm == ""){
        this.toastr.error('Please fill any data to filter','Error', {timeOut: 4000});
      }
      else{
        this.rest.filterSizeDetails(data).subscribe((res: any) => {
        // console.log("res==========>",res)
        if(res.success){
          this.size_details=res.result
          this.total_size = this.size_details.length;
          this.toastr.success('Size details filtered successfully.','Success', {timeOut: 4000});
          this.dialog.closeAll();
          this.p=1
          this.isFilterActive = !this.isFilterActive;
          this.size = ""
          this.matric = ""
          this.sqm = ""
        }
      },(err:any)=>{
        this.toastr.error('Size details not filtered.', 'Error', {timeOut: 4000});
      })
      }
      

    }catch(e){
      console.log(e);
    }

  }

  statusDialog(obj:any,i:any){
    this.row_id = this.size_details[i]['id']
    if(obj['isactive'] == 0){
      obj['isactive'] = 1
    }

    else if(obj['isactive'] == 1){
      obj['isactive'] = 0
    }

    console.log("obj active status >>>>>",obj['isactive'])

    try{

      let data = {
        "id" : this.row_id,
        "deleted" : "0",
        "isactive" : obj['isactive']
      }

      console.log("statusDialog data >>>>>>",data)

      this.rest.deletePlantDetails(data).subscribe((res: any) => {
        if(res.success){
          if(obj['isactive'] == 0){
            this.toastr.success('Plant - '+this.pre_size+' has been deactivated', 'Success', {timeOut: 4000});
          }

          else if(obj['isactive'] == 1){
            this.toastr.success('Plant - '+this.pre_size+' has been activated', 'Success', {timeOut: 4000});
          }
          
        }
      },(err:any)=>{
        this.toastr.error('Plant status is not updating', 'Error', {timeOut: 4000});
      })



    }catch(e){
      console.log(e);
    }

  }


  editSizeDetails(press:any,i:any){
    this.row_id = this.size_details[i]['id']
    this.pre_size = this.size_details[i]['size'];
    this.pre_matric = this.size_details[i]['matric'];
    this.pre_sqm = this.size_details[i]['SQM'];


    const dialogRef = this.dialog.open(this.editDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  viewSizeDetails(press:any,i:any){
    this.row_id = this.size_details[i]['id']
    this.pre_size = this.size_details[i]['size'];
    this.pre_matric = this.size_details[i]['matric'];
    this.pre_sqm = this.size_details[i]['SQM'];
    
    const dialogRef = this.dialog.open(this.viewDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }


  deleteFormDialog(cont:any,i:any): void {
    this.current_id  = i;
    this.row_header_id = i+1;
    console.log("this.row_header_id >>>>",this.row_header_id)
    this.row_id = this.size_details[i]['id']
    console.log("this.row_id >>>>>>",this.row_id)
    const dialogRef = this.dialog.open(this.deleteDialog, {
      width: '25%',
      height: '35%',
      
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }


  deleteSize(){
    try{

      let data = {
        "id" : this.row_id,
        "deleted" : "1",
        "isactive" : "0"
      }

      this.rest.deleteSizeDetails(data).subscribe((res: any) => {
        if(res.success){
          this.p=1
          this.toastr.success('Size - '+this.pre_size+' has been deleted', 'Success', {timeOut: 4000});
          this.size_details.splice(this.current_id,1);
          this.dialog.closeAll();
          this.sizeList()
        }
      },(err:any)=>{
        this.toastr.error('Plant -'+this.pre_size+' is not deleted', 'Error', {timeOut: 4000});
      })



    }catch(e){
      console.log(e);
    }

    
  }

}
