import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TemperatureMasterComponent } from './temperature-master.component';

describe('TemperatureMasterComponent', () => {
  let component: TemperatureMasterComponent;
  let fixture: ComponentFixture<TemperatureMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TemperatureMasterComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(TemperatureMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
