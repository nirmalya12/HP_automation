import { Component, ViewChild, TemplateRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { RestApiService } from '../rest-api.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-pc-code-master',
  templateUrl: './pc-code-master.component.html',
  styleUrl: './pc-code-master.component.css'
})
export class PcCodeMasterComponent {
  @ViewChild('formDialog') formDialog!: TemplateRef<any>;
  @ViewChild('editDialog') editDialog!: TemplateRef<any>;
  @ViewChild('viewDialog') viewDialog!: TemplateRef<any>;
  @ViewChild('filterDialog') filterDialog!: TemplateRef<any>;
  @ViewChild('deleteDialog') deleteDialog!: TemplateRef<any>;


  constructor(public dialog: MatDialog, private rest: RestApiService, private toastr: ToastrService){}

  public selected_pm_code           : String = "";
  public selected_pc_code           : String = "";
  public selected_thickness         : String = "";
  public filtering_selected_pm_code : String = "";
  public pre_resource_name          : String = '';
  public pre_pc_code                : String = '';
  public pre_selected_pm_code       : String = '';
  public pre_min_temp               : String = '';
  public pre_max_temp               : String = '';
  public pre_max_temp_6_4           : String = '';
  public pre_min_temp_6_4           : String = '';
  public pre_pressing_time          : String = '';
  public pre_load_time              : String = '';
  public resource                   : String = "";
  public pc_code                    : String = "";
  public min_temp                   : String = "";
  public max_temp                   : String = "";
  public max_temp_6_4               : String = "";
  public min_temp_6_4               : String = "";
  public filtering_resource         : String = "";
  public filtering_pc_code          : String = "";
  public filtering_min_temp         : String = "";
  public filtering_max_temp         : String = "";
  public filtering_max_temp_6_4     : String = "";
  public filtering_min_temp_6_4     : String = "";
  public filtering_pressing_time    : String = "";
  public filtering_load_time        : String = "";
  public row_id                     : String = "";
  public pc_code_id                 : String = "";
  public pc_code_details_id         : String = "";
  public currentTime                : string = "";
  public currentDate                : String = "";
  public temp_val                   : String = "";


  public pm_codes                   : any;
  public pressing_time              : any;
  public load_time                  : any;

  public temp_details         = [];
  public pm_details           = [];
  public pc_details           = [];
  public pm_master_deatils    = [];
  public pc_master_deatils    = [];
  public thickness_details    = [];

  public all_pm_codes          : String[]= [];
  public all_pm_codes_filter   : String[]= [];
  public all_resources         : String[]= [];
  public all_pc_codes          : String[]= [];
  public all_min_temperatures  : String[]= [];
  public all_max_temperatures  : String[]= [];
  public all_pressing_times    : String[]= [];
  public all_load_times        : String[]= [];


  public total_temperature : number = 0;
  public p                 : number = 1;


  public pc_code_index    : any;
  public resources        : any;
  public pc_codes         : any;
  public min_temperatures : any;
  public max_temperatures : any;
  public pressing_times   : any;
  public load_times       : any;
  

  public isFilterActive : boolean= false;

  
  placeholders = Array(6);

  ngOnInit(): void {
    this.temperatureList()
    const now = new Date();
    this.currentDate = now.toDateString();
    this.currentTime = now.toLocaleTimeString();
    this.pmList()
    this.all_thickness()
    this.pcList()
  }
  

  openFormDialog(): void {
    this.resource = ""
    this.pc_code = ""
    this.selected_pm_code = ""
    this.min_temp = ""
    this.max_temp = ""
    this.max_temp_6_4 = ""
    this.min_temp_6_4 = ""
    this.pressing_time = ""
    this.load_time = ""

    try{

      let data = {
        "name":"temparature"
      }

      this.rest.getTempPressureDetails(data).subscribe((res: any) => {
        if(res.success){
          console.log("add res >>>",res)
          this.temp_val = res.result['value']
          console.log("this.temp_val >>>",this.temp_val)
        }
      },(err:any)=>{
        this.toastr.error('Thickness details not fetched','Sorry !!',{timeOut:3000})
      })
    }
    catch(e){
      console.log("add error >>>",e)
    }
    const dialogRef = this.dialog.open(this.formDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  inactive(): void {
    this.isFilterActive = false;
    this.temperatureList()
    this.pmList()
    
  }

  openFilterDialog(): void {
    this.pmList()
    const dialogRef = this.dialog.open(this.filterDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  onNoClick(): void {
    this.dialog.closeAll();
  }

  onOptionChange(event: any) {
    this.selected_pm_code = event.option.value;
    // console.log("this.selected_pm_code",this.selected_pm_code)
  }

  onOptionPCChange(event: any){
    this.selected_pc_code = event.option.value;
  }

  onFilteringOptionChange(event: any) {
    this.filtering_selected_pm_code = event.option.value;
  }

  onOptionThicknessChange(event: any){
    this.selected_thickness = event.option.value;
  }

  resourceName(event:any){
    this.resource = event.target.value;
  }
  filteringResourceName(event:any){
    this.filtering_resource = event.target.value;
  }

  pcCode(event:any){
    this.pc_code = event.target.value;
  }
  filterimgPcCode(event:any){
    this.filtering_pc_code = event.option.value;
  }
  minTemp(event:any){
    this.min_temp = event.target.value;
  }
  filteringMinTemp(event:any){
    this.filtering_min_temp = event.option.value;
  }
  maxTemp(event:any){
    this.max_temp = event.target.value;
  }
  filteringMaxTemp(event:any){
    this.filtering_max_temp = event.option.value;
  }
  maxTemp_6_4(event:any){
    this.max_temp_6_4 = event.target.value;
  }
  // filteringMaxTemp_6_4(event:any){
  //   this.filtering_max_temp_6_4 = event.target.value;
  // }
  minTemp_6_4(event:any){
    this.min_temp_6_4 = event.target.value;
  }
  // filteringMinTemp_6_4(event:any){
  //   this.filtering_min_temp_6_4 = event.target.value;
  // }
  pressingTime(event:any){
    this.pressing_time = event.target.value;
  }
  filteringPressingTime(event:any){
    this.filtering_pressing_time = event.option.value;
  }
  loadTime(event:any){
    this.load_time = event.target.value;
  }
  filteringLoadTime(event:any){
    this.filtering_load_time = event.option.value;
  }


  temperatureList(){
    try{

      this.rest.getTemperatureDetaiils().subscribe((res: any) => {
        if(res.success){
          this.temp_details = res.result;
          console.log("this.temp_details",this.temp_details)
          this.total_temperature = this.temp_details.length;
          for(let i =0;i<this.temp_details.length;i++){
            this.resources = this.temp_details[i]
            this.resources = this.resources.RESOUCE
            if (!this.all_resources.includes(this.resources)) {
              this.all_resources.push(this.resources);
            }

            this.pc_codes = this.temp_details[i]
            this.pc_codes = this.pc_codes.pc_code
            if (!this.all_pc_codes.includes(this.pc_codes)) {
              this.all_pc_codes.push(this.pc_codes);
            }

            this.pm_codes = this.temp_details[i]
            this.pm_codes = this.pm_codes.pm_code
            if (!this.all_pm_codes_filter.includes(this.pm_codes)) {
              this.all_pm_codes_filter.push(this.pm_codes);
            }

            this.min_temperatures = this.temp_details[i]
            this.min_temperatures = this.min_temperatures.min_temp
            if (!this.all_min_temperatures.includes(this.min_temperatures)) {
              this.all_min_temperatures.push(this.min_temperatures);
            }

            this.max_temperatures = this.temp_details[i]
            this.max_temperatures = this.max_temperatures.max_temp
            if (!this.all_max_temperatures.includes(this.max_temperatures)) {
              this.all_max_temperatures.push(this.max_temperatures);
            }

            this.pressing_times = this.temp_details[i]
            this.pressing_times = this.pressing_times.pressing_time
            if (!this.all_pressing_times.includes(this.pressing_times)) {
              this.all_pressing_times.push(this.pressing_times);
            }

            this.load_times = this.temp_details[i]
            this.load_times = this.load_times.loadtime
            if (!this.all_load_times.includes(this.load_times)) {
              this.all_load_times.push(this.load_times);
            }
            
          }
          
        }
      })
    }
    
    catch(e){
      console.log(e);
    }
  }



  pcList(){
    try{

      this.rest.getPcDetails().subscribe((res: any) => {
        if(res.success){
          this.pc_details = res.result;
        }
      },(err:any)=>{
          this.toastr.error('PC details not fetched','Sorry!!',{timeOut:3000})
      })
    }
    
    catch(e){
      console.log(e);
    }
  }

  pmList(){
      try{

        this.rest.getPMDetails().subscribe((res: any) => {
          if(res.success){
            this.pm_details = res.result;
          }
        },(err:any)=>{
          this.toastr.error('PM details not fetched','Sorry!!',{timeOut:3000})
        })
      }
      
      catch(e){
        console.log("pmList err >>>",e);
      }
    }


  addMaster(){

    try{

      let data = {

        "pm_code"       :       this.selected_pm_code,
        "pc_code"       :       this.pc_code,
        "resource"      :       this.resource,
        "min_temp"      :       this.min_temp,
        "max_temp"      :       this.max_temp,
        "max_temp_6_4"  :       this.max_temp_6_4,
        "min_temp_6_4"  :       this.min_temp_6_4,
        "pressing_time" :       this.pressing_time,
        "loadtime"      :       this.load_time,
        "thickness"     :       this.selected_thickness

      }

      if(this.selected_pm_code == "" || this.pc_code == "" || this.resource == "" || this.selected_thickness == "" || this.min_temp == "" || this.max_temp == "" || this.max_temp_6_4 == "" || this.min_temp_6_4 == "" || this.pressing_time == "" || this.load_time == ""){
        this.toastr.error('Please fill all the fields.', 'Sorry!!', {timeOut:3000})
      }
      else{

        this.rest.addTemperatureDetails(data).subscribe((res: any) => {
          if(res.success){
            this.toastr.success('Temperature details added', 'Success', {timeOut: 4000});
            setTimeout(()=>{
              this.dialog.closeAll();
              this.temperatureList()
            },2000)

          }
        })
      }

    }catch(e){
      console.log(e);
    }
  }

  updateMaster(){
    try{



      let data = {
        "pc_code"       :this.pre_pc_code,
        "resource"      :this.pre_resource_name,
        "pm_code"       :this.pre_selected_pm_code,
        "min_temp"      :this.pre_min_temp,
        "max_temp"      :this.pre_max_temp,
        "max_temp_6_4"  :this.pre_max_temp_6_4,
        "min_temp_6_4"  :this.pre_min_temp_6_4,
        "pressing_time" :this.pre_pressing_time,
        "loadtime"      :this.pre_load_time,
        "id"            :this.row_id
      }
      // console.log("data >>>>",data)
      this.rest.updateTemperatureDetails(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success('Temperature '+this.pre_pc_code+' details updated', 'Success', {timeOut: 4000});
          setTimeout(()=>{
            this.dialog.closeAll();
            this.temperatureList()
          },2000)

        }
      },(err:any)=>{
        // console.log("error response >>>>>>",err)
        this.toastr.error('Temperature details not updated.', 'Error', {timeOut: 4000});
      })

    }catch(e){
      console.log(e);
    }

  }

  searchMaster(){
    try{

      let data = {
        "pc_code"       :this.filtering_pc_code,
        "resource"      :this.filtering_resource,
        "pm_code"       :this.filtering_selected_pm_code,
        "min_temp"      :this.filtering_min_temp,
        "max_temp"      :this.filtering_max_temp,
        "pressing_time" :this.filtering_pressing_time,
        "loadtime"      :this.filtering_load_time,
      }
      if(this.filtering_pc_code == "" && this.filtering_resource =="" && this.filtering_selected_pm_code =="" && this.filtering_min_temp =="" && this.filtering_max_temp =="" && this.filtering_pressing_time =="" && this.filtering_load_time ==""){
        this.toastr.error('Please fill any data to filter','Error', {timeOut: 4000});
      }
      else{
        this.rest.filterTemperature(data).subscribe((res: any) => {
        if(res.success){
         this.temp_details = res.result;
         this.total_temperature = this.temp_details.length;
         this.toastr.success(this.filtering_pc_code+' Filtered Successfully.','Success', {timeOut: 4000});
         this.dialog.closeAll();
         this.p=1
         this.isFilterActive = !this.isFilterActive;
         this.filtering_pc_code="";
         this.filtering_resource="";
         this.filtering_selected_pm_code="";
         this.filtering_min_temp="";
         this.filtering_max_temp="";
         this.filtering_pressing_time="";
         this.filtering_load_time="";
    }
  },(err:any)=>{
        this.toastr.error('Hot press details not updated.', 'Error', {timeOut: 4000});
      })
      }
      

    }catch(e){
      console.log(e);
    }

  }


  editPcDetails(press:any,i:any){
    this.row_id = this.temp_details[i]['id']
    this.pre_resource_name = this.temp_details[i]['RESOUCE'];
    this.pre_pc_code = this.temp_details[i]['pc_code'];
    this.pre_selected_pm_code = this.temp_details[i]['pm_code'];
    this.pre_min_temp = this.temp_details[i]['min_temp'];
    this.pre_max_temp = this.temp_details[i]['max_temp'];
    this.pre_max_temp_6_4 = this.temp_details[i]['max_temp_6_4'];
    this.pre_min_temp_6_4 = this.temp_details[i]['min_temp_6_4'];
    this.pre_pressing_time = this.temp_details[i]['pressing_time'];
    this.pre_load_time = this.temp_details[i]['loadtime'];
    
    const dialogRef = this.dialog.open(this.editDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  viewPcDetails(press:any,i:any){
    this.pre_resource_name = this.temp_details[i]['RESOUCE'];
    this.pre_pc_code = this.temp_details[i]['pc_code'];
    this.pre_selected_pm_code = this.temp_details[i]['pm_code'];
    this.pre_min_temp = this.temp_details[i]['min_temp'];
    this.pre_max_temp = this.temp_details[i]['max_temp'];
    this.pre_max_temp_6_4 = this.temp_details[i]['max_temp_6_4'];
    this.pre_min_temp_6_4 = this.temp_details[i]['min_temp_6_4'];
    this.pre_pressing_time = this.temp_details[i]['pressing_time'];
    this.pre_load_time = this.temp_details[i]['loadtime'];
    // console.log("pre_selected_pm_code===>",this.pre_selected_pm_code)
    const dialogRef = this.dialog.open(this.viewDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }
    


  openConfirmationModal(press:any,i:any){
    this.pc_code_id = i+1 ;
    this.pc_code_index = i;
    this.pc_code_details_id =this.temp_details[i]['id']
    try{


      const dialogRef = this.dialog.open(this.deleteDialog, {
      width: '25%',
      height: '35%',
      // position: { right: '0' },
      // panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });

    }catch(e){
      console.log(e);
    }

    
  }

  submitForm(){

    try{
      let data = {
        "id": this.pc_code_details_id,
        "deleted" :  "1",
        "isactive" : "0"
      }
      // console.log("====>",data)

      this.rest.deleteTemperature(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success(this.pre_pc_code+' has been deleted', 'Success', {timeOut: 4000});
          this.temp_details.splice(this.pc_code_index,1);
          this.dialog.closeAll();
          this.temperatureList()
        }
      },(err:any)=>{
        this.toastr.error(this.pre_pc_code+' is not deleted', 'Error', {timeOut: 4000});
      })

    }catch(e){
      console.log(e);
    }

    
  }


  statusDialog(obj:any,i:any){
    this.row_id = this.temp_details[i]['id']
    if(obj['isactive'] == 0){
      obj['isactive'] = 1
    }

    else if(obj['isactive'] == 1){
      obj['isactive'] = 0
    }

    console.log("obj active status >>>>>",obj['isactive'])

    try{

      let data = {
        "id" : this.row_id,
        "deleted" : "0",
        "isactive" : obj['isactive']
      }

      console.log("statusDialog data >>>>>>",data)

      this.rest.deleteTemperature(data).subscribe((res: any) => {
        if(res.success){
          if(obj['isactive'] == 0){
            this.toastr.success('Plant - '+this.pre_pc_code+' has been deactivated', 'Success', {timeOut: 4000});
          }

          else if(obj['isactive'] == 1){
            this.toastr.success('Plant - '+this.pre_pc_code+' has been activated', 'Success', {timeOut: 4000});
          }
          
        }
      },(err:any)=>{
        this.toastr.error('Plant status is not updating', 'Error', {timeOut: 4000});
      })



    }catch(e){
      console.log(e);
    }

  }

  all_thickness(){

    try{

        this.rest.getThicknessDetails().subscribe((res: any) => {
          if(res.success){
            console.log("all_thickness >>>",res.result)
            this.thickness_details = res.result;

          }
        },(err:any)=>{
          this.toastr.error('Thickness details not fetched','Sorry !!',{timeOut:3000})
        })
      }
      
      catch(e){
        console.log("all_thickness err >>",e);
      }
  }


}