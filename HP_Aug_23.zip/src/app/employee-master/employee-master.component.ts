import { Component, ViewChild, TemplateRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { RestApiService } from '../rest-api.service';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-employee-master',
  templateUrl: './employee-master.component.html',
  styleUrl: './employee-master.component.css'
})
export class EmployeeMasterComponent {

  @ViewChild('formDialog') formDialog!: TemplateRef<any>;
  @ViewChild('editDialog') editDialog!: TemplateRef<any>;
  @ViewChild('viewDialog') viewDialog!: TemplateRef<any>;
  @ViewChild('filterDialog') filterDialog!: TemplateRef<any>;
  @ViewChild('deleteDialog') deleteDialog!: TemplateRef<any>;
  


  constructor(public dialog: MatDialog, private rest: RestApiService, private toastr: ToastrService){}


  public pre_division_code            : String = '';
  public employee                     : String = "";
  public employee_code                : String = "";
  public pm_code                      : String = "";
  public division_code                : String = "";
  public section_code                 : String = "";
  public pre_employee                 : String = "";
  public pre_employee_code            : String = "";
  public pre_pm_code                  : String = "";
  public pre_department_code          : String = "";
  public pre_section_code             : String = "";
  public selected_pm_code             : String = "";
  public pre_selected_pm_code         : String = "";
  public selected_division_code       : String = "";
  public pre_selected_division_code   : String ="";
  public selected_department_code     : String = "";
  public pre_selected_department_code : String ="";
  public selected_section_code        : String = "";
  public pre_selected_section_code    : String = "";
  public filtering_division_code      : String = "";
  public filtering_employee           : String = "";
  public filtering_employee_code      : String = "";
  public filtering_pm_code            : String = ""; 
  public filtering_department_code    : String = "";
  public filtering_section_code       : String = "";
  public row_id                       : String = "";
  public employee_id                  : String = "";
  public employee_details_id          : String = "";
  public currentTime                  : string = "";
  public currentDate                  : String = "";
  public all_division_codes           : String[]= [];
  public all_division_codes_filter           : String[]= [];
  public all_department_codes_filter           : String[]= [];
  public all_section_codes_filter           : String[]= [];
  public all_pm_codes_filter           : String[]= [];
  // public all_emp_codes_filter                 : String[]= [];
  
  
  
  
  public all_department_codes         : String[]= [];
  public all_section_codes            : String[]= [];
  public all_pm_codes                 : String[]= [];
  public all_emp_names                 : String[]= [];
  public all_emp_codes                 : String[]= [];
  public employee_details                      = [];
  public pm_master_deatils                     = [];
  public pc_master_deatils                     = [];
  public pm_details                            = [];
  public division_details                      = [];
  public department_details                    = [];
  public section_details                       = [];
  public total_employee               : number = 0;
  public p                            : number = 1;
  public isFilterActive               : boolean= false;
  public division_codes               : any;
  public department_codes             : any;
  public pm_codes                     : any;
  public emp_names                     : any;
  public emp_codes                     : any;
  public section_codes                : any;
  public employee_id_index            : any;
  

  placeholders = Array(6);
  


  ngOnInit(): void {
    
    const now = new Date();
    this.currentDate = now.toDateString();
    this.currentTime = now.toLocaleTimeString();
    this.employeeList()
    this.pmList()
    this.divisionList()
    this.departmentList()
    this.sectionList()
    this.allEmpNameList()
    this.allEmpCodeList()


  }

  openFormDialog(): void {
    this.employee=''
    this.employee_code=''
    this.selected_pm_code=''
    this.selected_division_code=''
    this.selected_department_code=''

    const dialogRef = this.dialog.open(this.formDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }
  inactive(): void {
    this.isFilterActive = false;
    this.employeeList()
    
  }
  openFilterDialog(): void {
    
    const dialogRef = this.dialog.open(this.filterDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }


  pmList(){
    try{

      this.rest.pmList().subscribe((res: any) => {
        if(res.success){
          this.pm_details = res.result;
          for(let i =0;i<this.pm_details.length;i++){
            this.pm_codes = this.pm_details[i]
            this.pm_codes = this.pm_codes.PM_CODE
            if (!this.all_pm_codes.includes(this.pm_codes)) {
              this.all_pm_codes.push(this.pm_codes);
            }
            // this.all_pm_codes.push(this.pm_codes)
          }

        }
      })
    }
    
    catch(e){
      console.log(e);
    }
  }

  allEmpNameList(){
    try{

      for(let i =0;i<this.employee_details.length;i++){
            this.emp_names = this.employee_details[i]
            this.emp_names = this.emp_names.EM_NAME
            if (!this.all_emp_names.includes(this.emp_names)) {
              this.all_emp_names.push(this.emp_names);
            }
            // this.all_emp_names.push(this.emp_names)
            // console.log("All Emp Names========>",this.all_emp_names)
          }
    }
    
    catch(e){
      console.log(e);
    }
  }

  allEmpCodeList(){
    try{

      for(let i =0;i<this.employee_details.length;i++){
            this.emp_codes = this.employee_details[i]
            this.emp_codes = this.emp_codes.EM_CODE
            // this.all_emp_codes.push(this.emp_codes)
            if (!this.all_emp_codes.includes(this.emp_codes)) {
              this.all_emp_codes.push(this.emp_codes);
            }
            // console.log("All Emp Codes========>",this.all_emp_codes)
          }
    }
    
    catch(e){
      console.log(e);
    }
  }

  divisionList(){
    try{

      this.rest.divisionList().subscribe((res: any) => {
        // console.log("Division List======>",res)
        if(res.success){
          this.division_details = res.result;
          for(let i =0;i<this.division_details.length;i++){
            // console.log("this.division_details[i] >>>>>>>",this.division_details[i])
            this.division_codes = this.division_details[i]
            this.division_codes = this.division_codes.DI_CODE
            // console.log("sdfghj",this.division_codes)
            if (!this.all_division_codes.includes(this.division_codes)) {
              this.all_division_codes.push(this.division_codes);
            }
            // this.all_division_codes.push(this.division_codes)
          }
                      // console.log("All Division Codes===>",this.all_division_codes)


        }
      })
    }
    
    catch(e){
      console.log(e);
    }
  }
  

    departmentList(){
    try{

      this.rest.getDepartmentDetails().subscribe((res: any) => {
        // console.log("Department List======>",res)
        if(res.success){
          this.department_details = res.result;
          for(let i =0;i<this.department_details.length;i++){
            this.department_codes = this.department_details[i]
            this.department_codes = this.department_codes.DI_CODE
            if (!this.all_department_codes.includes(this.department_codes)) {
              this.all_department_codes.push(this.department_codes);
            }
            // this.all_department_codes.push(this.department_codes)
            // console.log("All Department Codes===>",this.all_department_codes)
          }

        }
      })
    }
    
    catch(e){
      console.log(e);
    }
  }


  sectionList(){
    try{

      this.rest.sectionList().subscribe((res: any) => {
        // console.log("Section List======>",res)
        if(res.success){
          this.section_details = res.result;
          for(let i =0;i<this.section_details.length;i++){
            this.section_codes = this.section_details[i]
            this.section_codes = this.section_codes.SM_CODE
            if (!this.all_section_codes.includes(this.section_codes)) {
              this.all_section_codes.push(this.section_codes);
            }
            // this.all_section_codes.push(this.section_codes)
            // console.log("All Department Codes===>",this.all_section_codes)
          }

        }
      })
    }
    
    catch(e){
      console.log(e);
    }
  }

  onOptionChange(event: any) {
    this.selected_pm_code = event.option.value;
    // console.log("this.selected_pm_code",this.selected_pm_code)
  }

  onDivisionOptionChange(event: any) {
    this.selected_division_code = event.option.value;
    // console.log("this.selected_division_code",this.selected_division_code)
  }

  onDepartmentOptionChange(event: any) {
    this.selected_department_code = event.option.value;
    // console.log("this.selected_department_code",this.selected_department_code)
  }
  onSectionOptionChange(event: any) {
    this.selected_section_code = event.option.value;
    // console.log("this.selected_section_code",this.selected_section_code)
  }

  


  onNoClick(): void {
    this.dialog.closeAll();
  }

  employeeeName(event:any){
    this.employee = event.target.value;
    // console.log("event >>>>",this.employee)
  }
  filteringEmployeeName(event:any){
    this.filtering_employee = event.target.value;
    // console.log("event >>>>",this.filtering_employee)
  }
  filteringEmployeeCode(event:any){
    this.filtering_employee_code = event.option.value;
    // console.log("event >>>>",this.filtering_employee_code)
  }
  filteringPmCode(event:any){
    this.filtering_pm_code = event.option.value;
    // console.log("event >>>>",this.filtering_pm_code)
  }
  filteringDivisionCode(event:any){
    this.filtering_division_code = event.option.value;
    // console.log("event >>>>",this.filtering_division_code)
  }
  filteringDepartmentCode(event:any){
    this.filtering_department_code = event.option.value;
    // console.log("event >>>>",this.filtering_department_code)
  }
  filteringSectionCode(event:any){
    this.filtering_section_code = event.option.value;
    // console.log("event >>>>",this.filtering_section_code)
  }
  
  employeeCode(event:any){
    this.employee_code = event.target.value;
    // console.log("event >>>>",this.employee_code)
  }

  pmCode(event:any){
    this.pm_code = event.target.value;
    // console.log("event >>>>",this.pm_code)
  }
  divisionCode(event:any){
    this.division_code = event.target.value;
    // console.log("event >>>>",this.division_code)
  }
  sectionCode(event:any){
    this.section_code = event.target.value;
    // console.log("event >>>>",this.section_code)
  }

  employeeList(){
    try{

      this.rest.employeeList().subscribe((res: any) => {
        if(res.success){
          // console.log("res >>>>>>>>>>>",res)
          this.employee_details = res.result;
          this.total_employee = this.employee_details.length;
          for(let i =0;i<this.employee_details.length;i++){
            this.division_codes = this.employee_details[i]
            this.division_codes = this.division_codes.di_code
            if (!this.all_division_codes_filter.includes(this.division_codes)) {
              this.all_division_codes_filter.push(this.division_codes);
            }
            this.department_codes = this.employee_details[i]
            this.department_codes = this.department_codes.dm_code
            if (!this.all_department_codes_filter.includes(this.department_codes)) {
              this.all_department_codes_filter.push(this.department_codes);
            }

            this.section_codes = this.employee_details[i]
            this.section_codes = this.section_codes.sm_code
            if (!this.all_section_codes_filter.includes(this.section_codes)) {
              this.all_section_codes_filter.push(this.section_codes);
            }

            // for(let i =0;i<this.employee_details.length;i++){
            this.pm_codes = this.employee_details[i]
            this.pm_codes = this.pm_codes.PM_CODE
            if (!this.all_pm_codes_filter.includes(this.pm_codes)) {
              this.all_pm_codes_filter.push(this.pm_codes);
            }


            // this.all_division_codes.push(this.division_codes)
            // console.log("All Division Codes========>",this.all_division_codes)
          }
          // console.log("this.total_employee >>>>>>>",this.total_employee)

        }
      })
    }
    
    catch(e){
      console.log(e);
    }
  }

  addMaster(){

    try{

      let data = {

        "EM_CODE" :           this.employee_code,
        "EM_NAME" :           this.employee,
        "PM_CODE" :           this.selected_pm_code,
        "di_code" :           this.selected_division_code,
        "dm_code" :           this.selected_department_code,
        "sm_code" :           this.selected_section_code,

      }
      // console.log("========>",data)
      this.rest.addEmployeeMaster(data).subscribe((res: any) => {
      if(res.success){
        this.toastr.success('Hot press details added', 'Success', {timeOut: 4000});
        setTimeout(()=>{
          this.dialog.closeAll();
          this.employeeList();
        },2000)

      }
      

    })

    }catch(e){
      console.log(e);
    }
  }

  updateMaster(){
    try{

      let data = {
        "di_code" :this.pre_selected_division_code,
        "EM_CODE" :this.pre_employee_code,
        "PM_CODE" :this.pre_selected_pm_code,
        "dm_code" :this.pre_selected_department_code,
        "id"      :this.row_id,
        "EM_NAME" :this.pre_employee,
        "sm_code" :this.pre_selected_section_code
        
      }
      // console.log("==============>",data)
      this.rest.updateEmployeeMaster(data).subscribe((res: any) => {
        // console.log("ressssssss",res)
        if(res.success){
          this.toastr.success(this.pre_employee+' details updated', 'Success', {timeOut: 4000});
          setTimeout(()=>{
            this.dialog.closeAll();
            this.employeeList()
          },2000)
        }
      },(err:any)=>{
        // console.log("error response >>>>>>",err)
        this.toastr.error('Employee master details not updated.', 'Error', {timeOut: 4000});
      })

    }catch(e){
      console.log(e);
    }

  }

  searchMaster(){
    try{
      
      let data = {
        "PM_CODE" :this.filtering_pm_code,
        "EM_CODE" :this.filtering_employee_code,
        "EM_NAME" :this.filtering_employee,
        "di_code" :this.filtering_division_code,
        "dm_code" :this.filtering_department_code,
        "sm_code" :this.filtering_section_code
      }
      if(this.filtering_pm_code == "" && this.filtering_employee_code =="" && this.filtering_employee =="" && this.filtering_division_code =="" && this.filtering_department_code =="" && this.filtering_section_code ==""){
        this.toastr.error('Please fill any data to filter','Error', {timeOut: 4000});
      }
      else{
        this.rest.filterEmployee(data).subscribe((res: any) => {
        // console.log("res==========>",res)
        if(res.success){
          this.employee_details=res.result
          this.total_employee = this.employee_details.length;
          this.toastr.success(this.filtering_division_code+' Filtered Successfully.','Success', {timeOut: 4000});
          this.dialog.closeAll();
          this.p=1
          this.isFilterActive = !this.isFilterActive;
          this.filtering_pm_code="";
          this.filtering_employee_code="";
          this.filtering_employee="";
          this.filtering_division_code="";
          this.filtering_department_code="";
          this.filtering_section_code="";
        }
      },(err:any)=>{
        this.toastr.error('Hot press details not updated.', 'Error', {timeOut: 4000});
      })
      }
      

    }catch(e){
      console.log(e);
    }

  }


  editHotPressDetails(press:any,i:any){
    this.row_id = this.employee_details[i]['id']
    this.pre_employee_code = this.employee_details[i]['EM_CODE'];
    this.pre_selected_pm_code = this.employee_details[i]['PM_CODE'];
    this.pre_selected_division_code = this.employee_details[i]['di_code'];
    this.pre_selected_department_code = this.employee_details[i]['dm_code'];
    this.pre_employee = this.employee_details[i]['EM_NAME'];
    this.pre_selected_section_code = this.employee_details[i]['sm_code'];
    
    const dialogRef = this.dialog.open(this.editDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  viewDivisionDetails(press:any,i:any){
    this.pre_employee_code = this.employee_details[i]['EM_CODE'];
    this.pre_selected_pm_code = this.employee_details[i]['PM_CODE'];
    this.pre_employee = this.employee_details[i]['EM_NAME'];
    this.pre_selected_division_code = this.employee_details[i]['di_code'];
    this.pre_selected_department_code = this.employee_details[i]['dm_code'];
    this.pre_employee = this.employee_details[i]['EM_NAME'];
    this.pre_selected_section_code = this.employee_details[i]['sm_code'];
    
    const dialogRef = this.dialog.open(this.viewDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }
    


  openConfirmationModal(press:any,i:any){
    this.employee_id = i+1 ;
    this.employee_id_index = i;
    this.employee_details_id =this.employee_details[i]['id']
    // console.log("this.employee_id",this.employee_id)
    try{

      const dialogRef = this.dialog.open(this.deleteDialog, {
      width: '25%',
      height: '35%',
      // panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
    }catch(e){
      console.log(e);
    }

    
  }

    submitForm(){
    try{
      let data = {
        "id": this.employee_details_id
      }

      this.rest.deleteEmployee(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success(this.pre_employee+' has been deleted', 'Success', {timeOut: 4000});
          this.employee_details.splice(this.employee_id_index,1);
          this.dialog.closeAll();
          this.employeeList()
        }
      },(err:any)=>{
        this.toastr.error(this.pre_employee+' is not deleted', 'Error', {timeOut: 4000});
      })

    }catch(e){
      console.log(e);
    }

    
  }





}