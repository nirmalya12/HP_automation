import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PressureMasterComponent } from './pressure-master.component';

describe('PressureMasterComponent', () => {
  let component: PressureMasterComponent;
  let fixture: ComponentFixture<PressureMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PressureMasterComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PressureMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
