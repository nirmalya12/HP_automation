import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';



@Injectable({
  providedIn: 'root'
})

export class CommonService {
  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}

  // getUserName(): any {
  //   if (isPlatformBrowser(this.platformId)) {
  //     const data = localStorage.getItem('username');
  //     try {
  //       return JSON.parse(data || '{}');
  //     } catch (e) {
  //       console.error('Failed to parse JSON', e);
  //       return null; // or handle the error as needed
  //     }
  //   } else {
  //     console.warn('localStorage is not available');
  //     return null;
  //   }
  // }
}

