import { Component, ViewChild, TemplateRef } from '@angular/core';
import { Router } from '@angular/router';
import { RestApiService } from '../rest-api.service';
import { ToastrService } from 'ngx-toastr';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-department-master',
  templateUrl: './department-master.component.html',
  styleUrl: './department-master.component.css'
})
export class DepartmentMasterComponent {


  @ViewChild('formDialog') formDialog!: TemplateRef<any>;
  @ViewChild('editDialog') editDialog!: TemplateRef<any>;
  @ViewChild('filterDialog') filterDialog!: TemplateRef<any>;
  @ViewChild('deleteDialog') deleteDialog!: TemplateRef<any>;
  @ViewChild('viewDialog') viewDialog!: TemplateRef<any>;

  constructor(public dialog: MatDialog, private rest: RestApiService, private toastr: ToastrService){}

  // public selectedPMCode : String = "";
  // public selectedFromShiftCode : String = "";
  // public selectedFilStatus : String = "";
  // public selectedPress : String = "";
  // public pre_shift_name : String = '';
  // public pre_end_hr : String = '';
  // public pre_end_min : String = '';
  // public pre_pm_code : String = '';
  // public pre_start_hr : String = '';
  // public pre_start_min : String = '';
  // public startingHour : String = "";
  // public endingHour : String = "";
  // public startingMin : String = "";
  // public endingMin : String = "";
  // public pm_deatils = [];
  // public pc_deatils = [];  
  // public pm_master_deatils = [];
  // public pc_master_deatils = [];




  public selectedDMCode : String = '';
  public selectedDMName : String = '';
  public selectedDICode : String = '';
  public row_id : String = "";
  public diCode : String = "";
  public dmName : String = "";
  public dmCode : String = "";
  public pre_di_code : String = '';
  public pre_dm_name : String = '';
  public pre_dm_code : String = '';
  public currentTime : string = "";
  public currentDate  : String = "";


  public all_di_code = [];
  public all_dm_code = [];
  public all_dm_name = [];  
  public department_details = []; 
  public di_code_details = [];


  public total_departments : number = 0;
  public p : number  = 1;
  public current_id : number  = 0;
  public row_header_id : number  = 0;


  public isFilterActive : boolean= false;

  placeholders = Array(8);

  ngOnInit(): void {
    this.updatedTime()
    this.departmentList()
    this.diCodeDetails()

  }

   updatedTime(){
    const now = new Date();
    this.currentDate = now.toDateString();
    this.currentTime = now.toLocaleTimeString();
  }


   inactive(): void {
    this.isFilterActive = false;
    this.selectedDICode = '';
    this.selectedDMName = '';
    this.selectedDMCode = ''; 
    this.departmentList()
    
  }
  

  openFormDialog(): void {

    this.diCode = '';
    this.dmName = '';
    this.dmCode = '';

    const dialogRef = this.dialog.open(this.formDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  filterFormDialog():void{

    this.selectedDICode = '';
    this.selectedDMName = '';
    this.selectedDMCode = '';

    const dialogRef = this.dialog.open(this.filterDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });

  }

  deleteFormDialog(press:any,i:any): void {
    this.current_id  = i;
    this.row_header_id = i+1;
    console.log("this.row_header_id >>>>",this.row_header_id)
    this.row_id = this.department_details[i]['id']
    console.log("this.row_id >>>>>>",this.row_id)
    const dialogRef = this.dialog.open(this.deleteDialog, {
      width: '25%',
      height: '35%',
      
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  onNoClick(): void {
    this.dialog.closeAll();
  }


  enterDiCode(event:any){
    this.diCode = event.target.value;
    console.log("event >>>>",this.diCode)
  }

  enterDmName(event:any){
    this.dmName = event.target.value;
    console.log("event >>>>",this.dmName)
  }

  enterDmCode(event:any){
    this.dmCode = event.target.value;
    console.log("event >>>>",this.dmCode)
  }

  onOptionDICode(event:any){
    this.selectedDICode = event.option.value;
  }

  onOptionDMNameChange(event:any){
    this.selectedDMName = event.option.value;
  }

  onOptionDMCodeChange(event:any){
    this.selectedDMCode = event.option.value;
  }


  departmentList(){
    try{

      this.rest.getDepartmentDetails().subscribe((res: any) => {
        if(res.success){
          console.log("res 2 >>>>>>>>>>>",res)
          // this.toastr.success('Showing Hot Press Lists', 'Success', {timeOut: 4000});
          this.department_details = res.result;
          this.total_departments = this.department_details.length;
          console.log("this.total_departments >>>>>>>",this.total_departments)

          for(let i=0; i<this.department_details.length; i++){
            if(!this.all_di_code.includes(this.department_details[i]['DI_CODE'])){
              this.all_di_code.push(this.department_details[i]['DI_CODE'])
            }
            
          }

          for(let i=0; i<this.department_details.length; i++){
            if(!this.all_dm_code.includes(this.department_details[i]['DM_CODE'])){
              this.all_dm_code.push(this.department_details[i]['DM_CODE'])
            }
            
          }

          for(let i=0; i<this.department_details.length; i++){
            if(!this.all_dm_code.includes(this.department_details[i]['DM_NAME'])){
              this.all_dm_name.push(this.department_details[i]['DM_NAME'])
            }
            
          }          
          
        }
      })
    }
    
    catch(e){
      console.log(e);
    }
  }



  addMaster(){

    try{

      let data = {

        "DI_CODE" :   this.diCode,
        "DM_CODE" :   this.dmCode,
        "DM_NAME" :   this.dmName
      }

      console.log("data >>>>",data)

      this.rest.addDepartmentMaster(data).subscribe((res: any) => {
      if(res.success){
        this.toastr.success('Department details added', 'Success', {timeOut: 4000});
        setTimeout(()=>{
          this.dialog.closeAll();
          this.departmentList()
        },2000)
      }
      

    },(err:any)=>{
      console.log("add res >>>>>>",err['error']['message'])
      this.toastr.error(err['error']['message'], 'Sorry!!', {timeOut: 4000});
    })

    }catch(e){
      console.log(e);
    }
  }

  updateMaster(){
    try{

      let data = {
        "id" : this.row_id,
        "DI_CODE" :   this.pre_di_code,
        "DM_CODE" :   this.pre_dm_code,
        "DM_NAME" :   this.pre_dm_name
      }
      console.log("data >>>>",data)
      this.rest.updateDepartmentMaster(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success('Department - '+this.pre_dm_name+' details updated', 'Success', {timeOut: 4000});
          setTimeout(()=>{
            this.dialog.closeAll();
          },2000)
          this.departmentList()
        }
      },(err:any)=>{
        this.toastr.error(err['error']['message'], 'Error', {timeOut: 4000});
      })

    }catch(e){
      console.log(e);
    }
    
  }

  viewDeptDetails(dept:any,i:any){
    this.row_id = this.department_details[i]['id']
    console.log("this.row_id >>>>>>",this.row_id);
    this.pre_di_code = this.department_details[i]['DI_CODE'];
    console.log("this.pre_di_code >>>>>>>",this.pre_di_code);
    this.pre_dm_name = this.department_details[i]['DM_NAME'];
    console.log("this.pre_dm_name >>>>>>>",this.pre_dm_name);
    this.pre_dm_code = this.department_details[i]['DM_CODE'];
    console.log("this.pre_dm_code >>>>>>>",this.pre_dm_code);
    
   
    const dialogRef = this.dialog.open(this.viewDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  editDeptDetails(dept:any,i:any){
    this.row_id = this.department_details[i]['id']
    console.log("this.row_id >>>>>>",this.row_id);
    this.pre_di_code = this.department_details[i]['DI_CODE'];
    console.log("this.pre_di_code >>>>>>>",this.pre_di_code);
    this.pre_dm_name = this.department_details[i]['DM_NAME'];
    console.log("this.pre_dm_name >>>>>>>",this.pre_dm_name);
    this.pre_dm_code = this.department_details[i]['DM_CODE'];
    console.log("this.pre_dm_code >>>>>>>",this.pre_dm_code);
    
   
    const dialogRef = this.dialog.open(this.editDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }
    


  deletedept(){
    try{

      let data = {
        "id": this.row_id
      }

      this.rest.deleteDepartment(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success('Department - '+this.pre_dm_name+' has been deleted', 'Success', {timeOut: 4000});
          this.department_details.splice(this.current_id,1);
          setTimeout(()=>{
            this.dialog.closeAll();
            this.p=1
          },2000)
          this.departmentList()
        }
      },(err:any)=>{
        this.toastr.error('Department -'+this.pre_dm_name+' is not deleted', 'Error', {timeOut: 4000});
      })



    }catch(e){
      console.log("deletedept err >>>",e);
    }

  }


  diCodeDetails(){ 
    try{

      this.rest.getDivisionDetails().subscribe((res: any) => {
        if(res.success){
          console.log("diCodeDetails res >>>",res)
          this.di_code_details = res.result;
        }
      },(err:any)=>{
        this.toastr.error('DI Code details not fetched', 'Error', {timeOut: 4000});
      })

    }catch(e){
      console.log("diCodeDetails e >>",e)
    }
  }


  filterMaster(){
    try{

      let data = {

        "DI_CODE" :   this.selectedDICode,
        "DM_CODE" :   this.selectedDMCode,
        "DM_NAME" :   this.selectedDMName
      }
      console.log("data >>>>",data)
      this.rest.filterDepartmentDetails(data).subscribe((res: any) => {
        if(res.success){
          this.p =1
          this.department_details = res.result;
          this.total_departments = this.department_details.length;
          setTimeout(()=>{
            this.dialog.closeAll();
            this.isFilterActive = !this.isFilterActive;

            if(this.selectedDICode!= '' && this.selectedDMCode!= '' && this.selectedDMName!= ''){
              this.toastr.success('Department details is filtered', 'Success', {timeOut: 4000});
            }

            else if(this.selectedDICode!= ''){
              this.toastr.success('Department details is filtered with DI Code - '+this.selectedDICode, 'Success', {timeOut: 4000});
            }

            else if(this.selectedDMCode!= ''){
              this.toastr.success('Department details is filtered with DM Code - '+this.selectedDMCode, 'Success', {timeOut: 4000});
            }

            else if(this.selectedDMName!= ''){
              this.toastr.success('Department details is filtered with DM Name - '+this.selectedDMName, 'Success', {timeOut: 4000});
            }

          },2000)
          
        }
      },(err:any)=>{
        this.toastr.error('Department details not updated.', 'Error', {timeOut: 4000});
      })

    }catch(e){
      console.log(e);
    }
    
  }


}
