import { Component, OnInit, Inject, PLATFORM_ID } from '@angular/core';
import { Router } from '@angular/router';
import { RestApiService } from '../rest-api.service';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from '../common.service';
import { isPlatformBrowser } from '@angular/common';


interface PreSavedData {
  ct_code_name: string;
  di_name_code: string;
  dm_name_code: string;
  id: number;
  machine_name: string;
  operator_name: string;
  pm_code_name: string;
  resource_name: string;
  sc_name: string;
  sm_code_name: string;
  supervisor_name: string;
  user_name: string;
}

@Component({
  selector: 'app-info',
  templateUrl: './info.component.html',
  styleUrl: './info.component.css'
})
export class InfoComponent {

  public pm_code : String = '';
  public dashDate : String = '';
  public selectedDICode : String = '';
  public selectedPMCode : String = '';
  public selectedDMCode : String = '';
  public selectedSMCode : String = '';
  public selectedMNCode : String = '';
  public selectedShiftCode : String = '';
  public selectedResourceCode : String = '';
  public ppm_code : String = '';
  public selectedSuperVisor : String = '';
  public selectedOperator : String = '';
  public selectedContractor : String = '';
  public selectedRSCode : String = '';


  public di_deatils = [];
  public dm_deatils = [];
  public pm_deatils = [];
  public sm_deatils = [];
  public supervisor_details = [];
  public operator_details = [];
  public contractor_deatils = [];
  public resource_deatils = [];
  public machine_deatils = [];
  public shift_deatils = [];
  public di_master_details = [];
  public pm_master_deatils = [];
  public dm_master_deatils = [];
  public sm_master_deatils = [];
  public resource_master_deatils = [];
  public shift_master_deatils = [];
  public supervisor_master_details = [];
  public operator_master_details = [];
  public contractor_master_deatils = [];
  public machine_master_deatils = [];


  public pre_saved_data : PreSavedData= {
    ct_code_name: '',
    di_name_code: '',
    dm_name_code: '',
    id: 0,
    machine_name: '',
    operator_name: '',
    pm_code_name: '',
    resource_name: '',
    sc_name: '',
    sm_code_name: '',
    supervisor_name: '',
    user_name: ''
  };


  constructor(private router: Router, private rest: RestApiService, private toastr: ToastrService, private common: CommonService){}
  
  ngOnInit(): void {

    this.previousResourceDetails()
    // console.log("username info page >>>>>>>",localStorage.getItem('username'))
    this.pmDetails()
    this.dashDate = this.todayDateDate();
    console.log("this.dashDate >>>>>",this.dashDate)
    this.diCodeDetails()
    // this.resourceDetails()
    this.superDetails()
    this.opDetails()
  }

 


  todayDateDate(): any {
    const today = new Date;
    const dd = String(today.getDate()).padStart(2, '0');
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const yyyy = today.getFullYear();

    const todaydate = yyyy + '-' + mm + '-' + dd;

    return todaydate;

  }

  pmFilter(){
    // console.log(this.pm_deatils.filter((pm: any) => pm.pm_code_name.toLowerCase()))
    // this.pm_deatils = this.pm_master_deatils.filter((pm: any) => pm.pm_code_name.toUpperCase().includes(this.selectedPMCode) || pm.PM_CODE.toLowerCase().includes(this.selectedPMCode))
    // this.pm_deatils = this.pm_master_deatils.filter((pm: any) => pm.pm_code_name.toLowerCase().includes(this.selectedPMCode) || pm.PM_CODE.toLowerCase().includes(this.selectedPMCode))
    this.pm_deatils = this.pm_master_deatils.filter((pm: any) => pm.pm_code_name.toLowerCase().includes(this.selectedPMCode.split("(")[1].replace(")","").trim()) || pm.PM_CODE.toLowerCase().includes(this.selectedPMCode.split("(")[1].replace(")","").trim()))
  }

  diFilter(){
    this.di_deatils = this.di_master_details.filter((pm: any) => pm.di_name_code.toLowerCase().includes(this.selectedDICode.split("(")[1].replace(")","")) || pm.DI_CODE.toLowerCase().includes(this.selectedDICode.split("(")[1].replace(")","")))
  }

  dmFilter(){
    this.dm_deatils = this.dm_master_deatils.filter((pm: any) => pm.dm_name_code.toLowerCase().includes(this.selectedDMCode.split("(")[1].replace(")","")) || pm.DM_CODE.toLowerCase().includes(this.selectedDMCode.split("(")[1].replace(")","")))
  }

  smFilter(){
    this.sm_deatils = this.sm_master_deatils.filter((pm: any) => pm.sm_code_name.toLowerCase().includes(this.selectedSMCode) || pm.SM_CODE.toLowerCase().includes(this.selectedSMCode))
  }

  mnFilter(){
    console.log("Inside Filter :")
    this.machine_deatils = this.machine_master_deatils.filter((pm: any) => pm.machine_name.toLowerCase().includes(this.selectedMNCode))
  }

  rmFilter(){
    this.resource_deatils = this.resource_master_deatils.filter((pm: any) => pm.resource_name.toLowerCase().includes(this.selectedResourceCode) || pm.resource_name.toLowerCase().includes(this.selectedResourceCode))
  }

  shFilter(){
    this.shift_deatils = this.shift_master_deatils.filter((pm: any) => pm.sc_name.toLowerCase().includes(this.selectedShiftCode))
  }

  svFilter(){
    this.supervisor_details = this.supervisor_master_details.filter((pm: any) => pm.supervisor_name.toLowerCase().includes(this.selectedSuperVisor))
  }

  opFilter(){
    this.operator_details = this.operator_master_details.filter((pm: any) => pm.operator_name.toLowerCase().includes(this.selectedOperator))
  }

  conFilter(){
    try{
      this.contractor_deatils = this.contractor_master_deatils.filter((pm: any) => pm.ct_code_name.toLowerCase().includes(this.selectedContractor))
    }

    catch(e){
      console.log(e)
    }
  }

  onOptionChange(event: any) {
    console.log("event >>>>>>>",event)
    // this.selectedPMCode = event.value;
    this.selectedPMCode = event.option.value;
    console.log('Selected option ID:', this.selectedPMCode, this.selectedPMCode.split("(")[1].replace(")","").trim());
    for(let item of this.pm_deatils){
      console.log("item >>>>",item)
      if(this.selectedPMCode.split("(")[1].replace(")","").trim() == item['PM_CODE']){
        console.log("item['PPM_CODE'] >>>>>",item['PPM_CODE'])
        this.ppm_code = item['PPM_CODE']
      }
    }
    this.machineDetails()
    this.resourceDetails()
    this.shiftDetails()
    this.contractorDetails()
  }

  onOptionDIChange(event: any) {
    console.log("event >>>>>>>",event)
    this.selectedDICode = event.option.value;
    console.log('Selected DI :', this.selectedDICode);
    this.departmentDetails()
  }

  onOptionDMChange(event: any) {
    console.log("event >>>>>>>",event)
    this.selectedDMCode = event.option.value;
    console.log('Selected DM :', this.selectedDMCode);
    this.sectionDetails()
  }


  onOptionSMChange(event: any) {
    console.log("event >>>>>>>",event)
    this.selectedSMCode = event.option.value;
    console.log('Selected SM :', this.selectedSMCode);
    // this.resourceDetails()
  }

  onOptionMNChange(event: any) {
    console.log("event >>>>>>>",event)
    console.log('Selected MN :', this.selectedMNCode);
    this.selectedMNCode = event.option.value;
    
    // console.log("this.selectedRSCode >>>>",this.selectedRSCode)
    // this.selectedResourceCode = this.selectedRSCode
    // console.log("inside onOptionMNChange:",JSON.stringify(this.machine_deatils))
    for(let arr of this.machine_deatils){
      // console.log("AAAAAAAAAA")
      // this.selectedRSCode = this.machine_deatils[i]['resource_name']
      console.log("this.machine_deatils >>>>>",this.machine_deatils)
      console.log("arr['machine_name'] >>>>",arr['machine_name'])
      console.log("this.selectedMNCode >>>>",this.selectedMNCode)
      if(arr['machine_name'] == this.selectedMNCode){
        console.log("MACHINE Matched >>>>")
        this.selectedResourceCode = arr['resource_name']
      }
    }

        console.log("this.selectedRSCode >>>>>>",this.selectedRSCode)
  
    // this.resourceDetails()
  }

  onOptionResourceChange(event: any){
    console.log("event >>>>>>>",event)
    this.selectedResourceCode = event.option.value;
    console.log('Selected Resource :', this.selectedResourceCode);
  }

  onOptionShiftChange(event:any){
    console.log("event >>>>>>>",event)
    this.selectedShiftCode = event.option.value;
    console.log('Selected shift :', this.selectedShiftCode);
  }

  onOptionSuperChange(event:any){
    console.log("event >>>>>>>",event)
    this.selectedSuperVisor = event.option.value;
    console.log('Selected supervisor :', this.selectedSuperVisor);
  }

  onOptionOperatorChange(event:any){
    console.log("event >>>>>>>",event)
    this.selectedOperator = event.option.value;
    console.log('Selected operator :', this.selectedOperator);
  }

  onOptionContractorChange(event:any){
    console.log("event >>>>>>>",event)
    this.selectedContractor = event.option.value;
    console.log('Selected operator :', this.selectedContractor);
  }


  pmDetails(){
    // selectedOption = this.options[0].id;

    // let data = {}

    try{

      this.rest.get_pm_code_details().subscribe((res: any) => {
      if(res.success){
        console.log("res.response >>>>>>>>>",res.result)
        this.pm_deatils = res.result;
        this.pm_master_deatils = res.result;
        // this.pm_deatils.map((item: any) => item.Show_PM_NAME = ${item.PM_NAME} (${item.PM_CODE}));
      }
      

      })
    }

    catch(e){
      console.log(e);
    }

  }

  diCodeDetails(){

    // let data = {
    //   "DI_CODE": "1"
    // }

    this.rest.get_di_code().subscribe((res: any) => {
      if(res.success){
        // console.log("res.response >>>>>>>>>",res.result)
        this.di_deatils = res.result;
        this.di_master_details = res.result;

      }
      

    })
  }

  departmentDetails(){
    // console.log("this.selectedDICode >>>>>>",this.selectedDICode)
    let data = {
      "DI_CODE": this.selectedDICode.split("(")[1].replace(")","")
    }

      this.rest.get_department_details(data).subscribe((res: any) => {
      if(res.success){
        // console.log("=== res.response >>>>>>>>>",res.result)
        this.dm_deatils = res.result;
        this.dm_master_deatils = res.result;
      }
      

    })
  }

  sectionDetails(){

    // console.log("this.selectedDMCode >>>>>>",this.selectedDMCode)
    let data = {
      "DM_CODE": this.selectedDMCode.split("(")[1].replace(")","")
    }

      this.rest.get_section_details(data).subscribe((res: any) => {
      if(res.success){
        // console.log(">>>> res.response >>>>>>>>>",res.result)
        this.sm_deatils = res.result;
        this.sm_master_deatils = res.result;
      }
      

    })
  }

  machineDetails(){
    console.log("machine PM >>>>>>",this.selectedPMCode.split("(")[1].replace(")",""))
    let data = {
      "PM_CODE": this.selectedPMCode.split("(")[1].replace(")","").trim()
    }

     this.rest.get_machine_details(data).subscribe((res: any) => {
      if(res.success){
        console.log(">>>> machine res.response >>>>>>>>>",res.result)
        this.machine_deatils = res.result;
        this.machine_master_deatils = res.result;
        console.log("inside machine det:",JSON.stringify(this.machine_deatils))


      }
      

    })
  }


  resourceDetails(){

    console.log("this.selectedPMCode >>>>>>",this.selectedPMCode)
    let data = {
      // "PM_CODE": this.selectedPMCode
      "PM_CODE": this.selectedPMCode.split("(")[1].replace(")","").trim()
    }

     this.rest.get_resource_details(data).subscribe((res: any) => {
      if(res.success){
        // console.log(">>>> res.response >>>>>>>>>",res.result)
        this.resource_deatils = res.result;
        this.resource_master_deatils = res.result;

      }
      

    })

  }


  shiftDetails(){

    // console.log()
    let data = {
      "PM_CODE": this.selectedPMCode.split("(")[1].replace(")","").trim()
    }

     this.rest.get_shift_details(data).subscribe((res: any) => {
      if(res.success){
        // console.log(">>>> res.response >>>>>>>>>",res.result)
        this.shift_deatils = res.result;
        this.shift_master_deatils = res.result;
      }
      

    })

  }


  superDetails(){

   this.rest.get_supervisor_master().subscribe((res: any) => {
    if(res.success){
      // console.log(">>>> res.response >>>>>>>>>",res.result)
      this.supervisor_details = res.result;
      this.supervisor_master_details = res.result;

    }
    

    })

 }

  opDetails(){

   this.rest.get_operator_master().subscribe((res: any) => {
    if(res.success){
      // console.log(">>>> res.response >>>>>>>>>",res.result)
      this.operator_details = res.result;
      this.operator_master_details = res.result;

    }
    

    })

 }

 contractorDetails(){

  let data = {
    "PM_CODE": this.ppm_code
  }
  this.rest.get_contractor_code(data).subscribe((res: any) => {
    if(res.success){
      // console.log(">>>> res.response >>>>>>>>>",res.result)
      this.contractor_deatils = res.result;
      this.contractor_master_deatils = res.result;
    }
    

    })
 }

 previousResourceDetails(){
  try{

    let data = {
      "user_name" : localStorage.getItem('username')
    }
    console.log("data >>>>>>>>>",data)
    this.rest.preResourceInfo(data).subscribe((res: any) => {
      if(res.success){
        console.log("res >>>>>>>>",res)
        this.toastr.success('Resource Information for user name - '+localStorage.getItem('username'), 'Success', {timeOut: 4000});
        this.pre_saved_data = res.result;
        console.log("this.pre_saved_data >>>>>>>",this.pre_saved_data)
        this.selectedPMCode = this.pre_saved_data['pm_code_name'];
        console.log("this.selectedPMCode >>>>>>>>>",this.selectedPMCode)
        this.selectedContractor = this.pre_saved_data['ct_code_name'];
        console.log("this.selectedContractor >>>>>>>>>",this.selectedContractor)
        this.selectedDICode = this.pre_saved_data['di_name_code'];
        console.log("this.selectedDICode >>>>>>>>>",this.selectedDICode)
        this.selectedDMCode = this.pre_saved_data['dm_name_code'];
        console.log("this.selectedDMCode >>>>>>>>>",this.selectedDMCode)
        this.selectedMNCode = this.pre_saved_data['machine_name'];
        console.log("this.selectedMNCode >>>>>>>>>",this.selectedMNCode)
        this.selectedOperator = this.pre_saved_data['operator_name'];
        console.log("this.selectedOperator >>>>>>>>>",this.selectedOperator)
        this.selectedResourceCode = this.pre_saved_data['resource_name'];
        console.log("this.selectedResourceCode >>>>>>>>>",this.selectedResourceCode)
        this.selectedShiftCode = this.pre_saved_data['sc_name'];
        console.log("this.selectedShiftCode >>>>>>>>>",this.selectedShiftCode)
        this.selectedSMCode = this.pre_saved_data['sm_code_name'];
        console.log("this.selectedSMCode >>>>>>>>>",this.selectedSMCode)
        this.selectedSuperVisor = this.pre_saved_data['supervisor_name'];
        console.log("this.selectedSuperVisor >>>>>>>>>",this.selectedSuperVisor)
        

    // let params = new HttpParams().set("user_name",localStorage.getItem('username'));
    // // for (const key in paramsObject) {
    // //   if (paramsObject.hasOwnProperty(key)) {
    // //     params = params.set(key, paramsObject[key]);
    // //   }
    // // }
    // // return this.http.get(this.API_ROOT + 'resorce_info',{ params })
    //     return this.http.get(this.API_ROOT + 'resorce_info', {params})
        // setTimeout(() => {}, 5000)
        // this.router.navigate(['/dashboard']);
        // setTimeout(() => {
        //   this.router.navigate(['/dashboard']);
        // }, 2000);
        // // console.log(">>>> res.response >>>>>>>>>",res.result)
        // this.contractor_deatils = res.result;
        // this.contractor_master_deatils = res.result;
      }

      else{
        this.toastr.error('Something went wrong', 'Error', {timeOut: 4000});
      }
      

      })

  }
  catch(e){
    console.log("previousResourceDetails err",e)
  }

 }
  

 saveResourceDetails(){

  try{
      // console.log("username info page >>>>>>>",localStorage.getItem('username'))
    // if(this.selectedPMCode == ''){
    //   this.toastr.error('Please select PM Code','Error',{timeOut:3000})
    // }
    // else if(this.selectedDICode == ''){
    //   this.toastr.error('Please select DI Code','Error',{timeOut:3000})
    // }
    

    if(this.selectedPMCode != '' && this.selectedDICode != '' && this.selectedDMCode !='' && this.selectedSMCode != '' &&this.selectedMNCode != '' && this.selectedResourceCode != '' && this.selectedShiftCode != '' && this.selectedSuperVisor != '' &&  this.selectedOperator != ''){

      console.log("All Required field provided >>>>>")

      let data = {
      "user_name" :     localStorage.getItem('username'),
      "pm_code_name" :  this.selectedPMCode,
      "di_name_code" :  this.selectedDICode,
      "dm_name_code" :  this.selectedDMCode,
      "sm_code_name" :  this.selectedSMCode,
      "machine_name" :  this.selectedMNCode,
      "resource_name" : this.selectedResourceCode,
      "sc_name" :       this.selectedShiftCode,
      "supervisor_name":this.selectedSuperVisor,
      "operator_name" : this.selectedOperator,
      "ct_code_name" :  this.selectedContractor,
      "date" : this.dashDate

    }

    this.rest.updateResourceInfo(data).subscribe((res: any) => {
      if(res.success){
        this.toastr.success('Resource Information Saved Successfully', 'Success', {timeOut: 4000});
        setTimeout(() => {
          this.router.navigate(['/dashboard']);
        }, 2000);
        
      }
      else{
        this.toastr.error('Something went wrong', 'Error', {timeOut: 4000});
      }
      
      })

    }

    else{
        if(this.selectedPMCode == ''){
          this.toastr.error('Please select PM Code','Error',{timeOut:3000})
        }

        else if(this.selectedDICode == ''){
          this.toastr.error('Please select DI Code','Error',{timeOut:3000})
        }

        else if(this.selectedDMCode == ''){
          this.toastr.error('Please select DM Code','Error',{timeOut:3000})
        }
        else if(this.selectedSMCode == ''){
          this.toastr.error('Please select SM Code','Error',{timeOut:3000})
        }
        else if(this.selectedMNCode == ''){
          this.toastr.error('Please select Machine Number','Error',{timeOut:3000})
        }
        else if(this.selectedResourceCode == ''){
          this.toastr.error('Please select Resource','Error',{timeOut:3000})
        }
        else if(this.selectedShiftCode == ''){
          this.toastr.error('Please select Shift','Error',{timeOut:3000})
        }
        else if(this.selectedSuperVisor == ''){
          this.toastr.error('Please select Supervisor','Error',{timeOut:3000})
        }
        else if(this.selectedOperator == ''){
          this.toastr.error('Please select Operator','Error',{timeOut:3000})
        }


    }

    // let data = {
    //   "user_name" :     localStorage.getItem('username'),
    //   "pm_code_name" :  this.selectedPMCode,
    //   "di_name_code" :  this.selectedDICode,
    //   "dm_name_code" :  this.selectedDMCode,
    //   "sm_code_name" :  this.selectedSMCode,
    //   "machine_name" :  this.selectedMNCode,
    //   "resource_name" : this.selectedResourceCode,
    //   "sc_name" :       this.selectedShiftCode,
    //   "supervisor_name":this.selectedSuperVisor,
    //   "operator_name" : this.selectedOperator,
    //   "ct_code_name" :  this.selectedContractor

    // }

    // this.rest.updateResourceInfo(data).subscribe((res: any) => {
    //   if(res.success){
    //     this.toastr.success('Resource Information Saved Successfully', 'Success', {timeOut: 4000});
    //     setTimeout(() => {
    //       this.router.navigate(['/dashboard']);
    //     }, 2000);
        
    //   }
    //   else{
    //     this.toastr.error('Something went wrong', 'Error', {timeOut: 4000});
    //   }
      
    //   })
  }

  catch(e){
    console.log("saveResourceDetails err",e)
  }

 }

 resetValues(){

  try{

    this.selectedPMCode = '';
    this.selectedDICode = '';
    this.selectedDMCode = '';
    this.selectedSMCode = '';
    this.selectedMNCode = '';
    this.selectedResourceCode = '';
    this.selectedShiftCode = '';
    this.selectedSuperVisor = '';
    this.selectedOperator = '';
    this.selectedContractor = '';
    this.pmDetails()
    this.dm_deatils = [];
    this.machine_deatils = [];
    this.shift_deatils = [];
    this.contractor_deatils = [];

  }catch(e){
    console.log("resetValues err >>>>.",e)
  }

 }



}
