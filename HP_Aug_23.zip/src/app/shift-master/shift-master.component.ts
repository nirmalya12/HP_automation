import { Component, ViewChild, TemplateRef  } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { RestApiService } from '../rest-api.service';
import { ToastrService } from 'ngx-toastr';
import { MatAutocompleteTrigger } from '@angular/material/autocomplete';

@Component({
  selector: 'app-shift-master',
  templateUrl: './shift-master.component.html',
  styleUrl: './shift-master.component.css'
})
export class ShiftMasterComponent {


  @ViewChild('formDialog') formDialog!: TemplateRef<any>;
  @ViewChild('editDialog') editDialog!: TemplateRef<any>;
  @ViewChild('filterDialog') filterDialog!: TemplateRef<any>;
  @ViewChild('deleteDialog') deleteDialog!: TemplateRef<any>;
  @ViewChild(MatAutocompleteTrigger) autocompleteTrigger!: MatAutocompleteTrigger;
  @ViewChild('viewDialog') viewDialog!: TemplateRef<any>;

  constructor(public dialog: MatDialog, private rest: RestApiService, private toastr: ToastrService){}


  public selectedPMCode : String = "";
  public selectedFromShiftCode : String = "";
  public selectedFilStatus : String = "";
  public selectedScName : String = "";
  public selectedPmCode : String = "";
  public pre_shift_name : String = '';
  public pre_end_hr : String = '';
  public pre_end_min : String = '';
  public pre_pm_code : String = '';
  public pre_start_hr : String = '';
  public pre_start_min : String = '';
  public startingHour : String = "";
  public endingHour : String = "";
  public startingMin : String = "";
  public endingMin : String = "";
  public row_id : String = "";
  public currentTime : string = "";
  public currentDate  : String = "";


  public pm_deatils = [];
  public shift_details = [];
  public pc_deatils = [];
  public pm_master_deatils = [];
  public pc_master_deatils = [];
  public shift_data_details = [];
  public pm_code_details = [];
  public pm_code_shifts = [];
  public all_sc_name = [];


  public total_shifts : number = 0;
  public p : number  = 1;
  public current_id : number  = 0;
  public row_header_id : number  = 0;
  

  public dialogOpened: boolean = false;
  public isFilterActive : boolean= false;

  placeholders = Array(8);



  ngOnInit(): void {
    this.updatedTime()
    this.shiftList()
    this.pmDetails()
    this.pmCodeDetails()
  }

  updatedTime(){
    const now = new Date();
    this.currentDate = now.toDateString();
    this.currentTime = now.toLocaleTimeString();
  }


   inactive(): void {
    this.isFilterActive = false;
    this.selectedPmCode = '';
    this.selectedScName = '';
    this.shiftList()
    
  }


  openDropdown(autoComplete: any) {
    if (this.dialogOpened) {
      this.autocompleteTrigger.openPanel();
    }
  }
  

  openFormDialog(): void {

    this.selectedPMCode = '';
    this.selectedFromShiftCode = '';
    this.startingHour = '';
    this.endingHour = '';
    this.startingMin = '';
    this.endingMin = '';

    this.dialogOpened = true;
    const dialogRef = this.dialog.open(this.formDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  filterFormDialog():void{
    const dialogRef = this.dialog.open(this.filterDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });

  }

  deleteFormDialog(press:any,i:any): void {
    this.current_id  = i;
    this.row_header_id = i+1;
    console.log("this.row_header_id >>>>",this.row_header_id)
    this.row_id = this.shift_details[i]['id']
    console.log("this.row_id >>>>>>",this.row_id)
    const dialogRef = this.dialog.open(this.deleteDialog, {
      width: '25%',
      height: '35%',
      
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  onNoClick(): void {
    this.dialog.closeAll();
  }

  onOptionChange(event: any) {
    console.log("event >>>>>>>",event)
    // this.selectedPMCode = event.value;
    this.selectedPMCode = event.option.value;
    this.shiftDetails(this.selectedPMCode)
  }


  onOptionScNameChange(event: any){
    this.selectedScName = event.option.value;
  }

  onOptionPmCodeChange(event:any){
    this.selectedPmCode = event.option.value;
    console.log("this.selectedPmCode >>>>>>>>",this.selectedPmCode)
  }

  onOptionFilterStatusChange(event:any){
    this.selectedFilStatus = event.option.value;
    console.log("this.selectedFilStatus >>>>>>>>",this.selectedFilStatus)
  }

  startHour(event:any){
    this.startingHour = event.target.value;
    console.log("event >>>>",this.startingHour)
  }

  endHour(event:any){
    this.endingHour = event.target.value;
    console.log("event >>>>",this.endingHour)
  }

  startMin(event:any){
    this.startingMin = event.target.value;
    console.log("event >>>>",this.startingMin)
  }

  endMin(event:any){
    this.endingMin = event.target.value;
    console.log("event >>>>",this.endingMin)
  }

  shiftName(event:any){
    this.selectedFromShiftCode = event.target.value;
    console.log("event >>>>",this.selectedFromShiftCode)
  }

  onOptionFromShiftChange(event:any){
    console.log("event >>>>>>>",event)
    this.selectedFromShiftCode = event.option.value;
    console.log('Selected shift :', this.selectedFromShiftCode);
    for(let item of this.shift_data_details){
      if(this.selectedFromShiftCode == item['sc_name']){
        this.row_id = item['id']
        console.log("this.row_id >>>>>>>",this.row_id)
      }
    }

  }
  
  pmCodeDetails(){
    try{

      this.rest.getPMDetails().subscribe((res: any) => {
      if(res.success){
        console.log("pmCodeDetails >",res)
        this.pm_code_details = res.result;
      }

      },(err:any)=>{
        console.log(err)
      })

    }catch(e){
      console.log("pmCodeDetails err >>>>>>>",e)
    }
  }


  pmDetails(){
     
    try{

      this.rest.get_pm_code_details().subscribe((res: any) => {
      if(res.success){
        // console.log("res.response >>>>>>>>>",res)
        this.pm_deatils = res.result;
        this.pm_master_deatils = res.result;

        this.pc_deatils = res.result1;
        this.pc_master_deatils = res.result1;
        // this.pm_deatils.map((item: any) => item.Show_PM_NAME = ${item.PM_NAME} (${item.PM_CODE}));
      }
      

      })
    }

    catch(e){
      console.log(e);
    }

  }

  shiftList(){
    try{

      this.rest.getShiftMasterDetails().subscribe((res: any) => {
        if(res.success){
          console.log("shift res >>>>>>>>>>>",res)
          // this.toastr.success('Showing Hot Press Lists', 'Success', {timeOut: 4000});
          this.shift_details = res.result;
          this.total_shifts = this.shift_details.length;
          console.log("this.total_shifts >>>>>>>",this.total_shifts)

          for(let i=0; i<this.shift_details.length; i++){
            if(!this.pm_code_shifts.includes(this.shift_details[i]['pm_code'])){
              this.pm_code_shifts.push(this.shift_details[i]['pm_code'])
            }
          }

          for(let i=0; i<this.shift_details.length; i++){
            if(!this.all_sc_name.includes(this.shift_details[i]['sc_name'])){
              this.all_sc_name.push(this.shift_details[i]['sc_name'])
            }
          }

          console.log("this.pm_code_shifts >>>>>>>.",this.pm_code_shifts)
          console.log("this.all_sc_name >>>>>>>.",this.all_sc_name)
          
        }
      })
    }
    
    catch(e){
      console.log(e);
    }
  }


  shiftDetails(pmCode:String){

    try{
      console.log("pmCode >>>>>>>",pmCode)
      let data = {
        "PM_CODE": pmCode
      }
      console.log("data >>>>>>",JSON.stringify(data))
      this.rest.get_shift_details(data).subscribe((res: any) => {
        if(res.success){
          // console.log(">>>> res.response >>>>>>>>>",res.result)
          this.toastr.success('Shift details fetched', 'Success', {timeOut: 4000});
          this.shift_data_details = res.result;
          console.log("this.shift_data_details >>>>>>>>",this.shift_data_details);
        }
        

      })

    }catch(e){
      console.log("shiftDetails err >",e)
    }

    

  }

  addMaster(){

    try{

      let data = {

        "pm_code" :       this.selectedPMCode,
        "start_hr" :      this.startingHour,
        "start_min" :     this.startingMin,
        "end_hr" :        this.endingHour,
        "end_min" :       this.endingMin,
        "sc_name" :       this.selectedFromShiftCode

      }

      console.log("data >>>>",data)

      this.rest.addShiftMaster(data).subscribe((res: any) => {
      if(res.success){
        this.toastr.success('Shift details added', 'Success', {timeOut: 4000});
        setTimeout(()=>{
          this.dialog.closeAll();
          this.shiftList()
        },2000)
      }
      

    })

    }catch(e){
      console.log(e);
    }
  }

  updateMaster(){
    try{

      let data = {
        "id" : this.row_id,
        "pm_code" : this.pre_pm_code,
        "start_hr" : this.pre_start_hr,
        "start_min" : this.pre_start_min,
        "end_hr" : this.pre_end_hr,
        "end_min" : this.pre_end_min,
        "sc_name" : this.pre_shift_name
      }
      console.log("data >>>>",data)
      this.rest.updateShiftMaster(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success('Shift - '+this.pre_shift_name+' details updated', 'Success', {timeOut: 4000});
          setTimeout(()=>{
            this.dialog.closeAll();
          },2000)
          this.shiftList()
        }
      },(err:any)=>{
        this.toastr.error('Shift details not updated.', 'Error', {timeOut: 4000});
      })

    }catch(e){
      console.log(e);
    }
    
  }


  viewShiftDetails(shift:any,i:any){
    this.row_id = this.shift_details[i]['id']
    console.log("this.row_id >>>>>>",this.row_id);
    this.pre_shift_name = this.shift_details[i]['sc_name'];
    console.log("this.pre_shift_name >>>>>>>",this.pre_shift_name);
    this.pre_end_hr = this.shift_details[i]['end_hr'];
    console.log("this.pre_end_hr >>>>>>>",this.pre_end_hr);
    this.pre_end_min = this.shift_details[i]['end_min'];
    console.log("this.pre_end_min >>>>>>>",this.pre_end_min);
    this.pre_pm_code = this.shift_details[i]['pm_code'];
    console.log("this.pre_pm_code >>>>>>>",this.pre_pm_code);
    this.pre_start_hr = this.shift_details[i]['start_hr'];
    console.log("this.pre_start_hr >>>>>>>",this.pre_start_hr);
    this.pre_start_min = this.shift_details[i]['start_min'];
   
    const dialogRef = this.dialog.open(this.viewDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }


  editShiftDetails(shift:any,i:any){
    this.row_id = this.shift_details[i]['id']
    console.log("this.row_id >>>>>>",this.row_id);
    this.pre_shift_name = this.shift_details[i]['sc_name'];
    console.log("this.pre_shift_name >>>>>>>",this.pre_shift_name);
    this.pre_end_hr = this.shift_details[i]['end_hr'];
    console.log("this.pre_end_hr >>>>>>>",this.pre_end_hr);
    this.pre_end_min = this.shift_details[i]['end_min'];
    console.log("this.pre_end_min >>>>>>>",this.pre_end_min);
    this.pre_pm_code = this.shift_details[i]['pm_code'];
    console.log("this.pre_pm_code >>>>>>>",this.pre_pm_code);
    this.pre_start_hr = this.shift_details[i]['start_hr'];
    console.log("this.pre_start_hr >>>>>>>",this.pre_start_hr);
    this.pre_start_min = this.shift_details[i]['start_min'];
   
    const dialogRef = this.dialog.open(this.editDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }
    


  deleteShift(){
    try{

      let data = {
        "id": this.row_id
      }

      this.rest.deleteShift(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success('Shift - '+this.pre_shift_name+' has been deleted', 'Success', {timeOut: 4000});
          this.shift_details.splice(this.current_id,1);
          setTimeout(()=>{
            this.dialog.closeAll();
            this.p=1
          },2000)
          this.shiftList()

        }
      },(err:any)=>{
        this.toastr.error('Shift -'+this.pre_shift_name+' is not deleted', 'Error', {timeOut: 4000});
      })



    }catch(e){
      console.log(e);
    }

    
  }


  filterMaster(){

    try{

      let data = {
        "pm_code" : this.selectedPmCode,
        "sc_name" : this.selectedScName
      }

      this.rest.filterShiftDetails(data).subscribe((res: any) => {
        if(res.success){
          this.p = 1
          this.shift_details = res.result;
          this.total_shifts = this.shift_details.length;

          setTimeout(()=>{
            this.dialog.closeAll();
            this.isFilterActive = !this.isFilterActive;

            if(this.selectedPmCode!= '' && this.selectedScName!= ''){
              this.toastr.success('Shift details is filtered', 'Success', {timeOut: 4000});
            }

            else if(this.selectedPmCode!= ''){
              this.toastr.success('Shift details is filtered with PM Code - '+this.selectedPmCode, 'Success', {timeOut: 4000});
            }

            else if(this.selectedScName!= ''){
              this.toastr.success('Shift details is filtered with SC Name - '+this.selectedScName, 'Success', {timeOut: 4000});
            }
          },2000)
        }
      },(err:any)=>{
        this.toastr.error('Shift details is not filtered', 'Error', {timeOut: 4000});
      })

    }catch(e){
      console.log("filterMaster err >",e)
    }
  }



}
