import { Component, ViewChild, TemplateRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { RestApiService } from '../rest-api.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-pc-code-master',
  templateUrl: './pc-code-master.component.html',
  styleUrl: './pc-code-master.component.css'
})
export class PcCodeMasterComponent {
  @ViewChild('formDialog') formDialog!: TemplateRef<any>;
  @ViewChild('editDialog') editDialog!: TemplateRef<any>;
  @ViewChild('viewDialog') viewDialog!: TemplateRef<any>;
  @ViewChild('filterDialog') filterDialog!: TemplateRef<any>;
  @ViewChild('deleteDialog') deleteDialog!: TemplateRef<any>;


  constructor(public dialog: MatDialog, private rest: RestApiService, private toastr: ToastrService){}

  public selected_pm_code           : String = "";
  public filtering_selected_pm_code : String = "";
  public pre_resource_name          : String = '';
  public pre_pc_code                : String = '';
  public pre_selected_pm_code       : String = '';
  public pre_min_temp               : String = '';
  public pre_max_temp               : String = '';
  public pre_max_temp_6_4           : String = '';
  public pre_min_temp_6_4           : String = '';
  public pre_pressing_time          : String = '';
  public pre_load_time              : String = '';
  public resource                   : String = "";
  public pc_code                    : String = "";
  public min_temp                   : String = "";
  public max_temp                   : String = "";
  public max_temp_6_4               : String = "";
  public min_temp_6_4               : String = "";
  public filtering_resource         : String = "";
  public filtering_pc_code          : String = "";
  public filtering_min_temp         : String = "";
  public filtering_max_temp         : String = "";
  public filtering_max_temp_6_4     : String = "";
  public filtering_min_temp_6_4     : String = "";
  public filtering_pressing_time    : String = "";
  public filtering_load_time        : String = "";
  public row_id                     : String = "";
  public pc_code_id                 : String = "";
  public pc_code_details_id         : String = ""
  public pm_codes                   : any;
  public pressing_time              : any;
  public load_time                  : any;
  public all_pm_codes               : String[]= [];
  public pc_details                           = [];
  public pm_details                           = [];
  public pm_master_deatils                    = [];
  public pc_master_deatils                    = [];
  public total_pc_code              : number = 0;
  public p                          : number = 1;
  public isFilterActive             : boolean= false;
  public pc_code_index              : any;

  ngOnInit(): void {
    this.pcList()
    this.pmList()
  }
  

  openFormDialog(): void {
    const dialogRef = this.dialog.open(this.formDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  inactive(): void {
    this.isFilterActive = false;
    this.pcList()
    this.pmList()
    
  }

  openFilterDialog(): void {
    this.pmList()
    const dialogRef = this.dialog.open(this.filterDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  onNoClick(): void {
    this.dialog.closeAll();
  }

  onOptionChange(event: any) {
    this.selected_pm_code = event.option.value;
    // console.log("this.selected_pm_code",this.selected_pm_code)
  }
  onFilteringOptionChange(event: any) {
    this.filtering_selected_pm_code = event.option.value;
  }

  resourceName(event:any){
    this.resource = event.target.value;
  }
  filteringResourceName(event:any){
    this.filtering_resource = event.target.value;
  }

  pcCode(event:any){
    this.pc_code = event.target.value;
  }
  filterimgPcCode(event:any){
    this.filtering_pc_code = event.target.value;
  }
  minTemp(event:any){
    this.min_temp = event.target.value;
  }
  filteringMinTemp(event:any){
    this.filtering_min_temp = event.target.value;
  }
  maxTemp(event:any){
    this.max_temp = event.target.value;
  }
  filteringMaxTemp(event:any){
    this.filtering_max_temp = event.target.value;
  }
  maxTemp_6_4(event:any){
    this.max_temp_6_4 = event.target.value;
  }
  // filteringMaxTemp_6_4(event:any){
  //   this.filtering_max_temp_6_4 = event.target.value;
  // }
  minTemp_6_4(event:any){
    this.min_temp_6_4 = event.target.value;
  }
  // filteringMinTemp_6_4(event:any){
  //   this.filtering_min_temp_6_4 = event.target.value;
  // }
  pressingTime(event:any){
    this.pressing_time = event.target.value;
  }
  filteringPressingTime(event:any){
    this.filtering_pressing_time = event.target.value;
  }
  loadTime(event:any){
    this.load_time = event.target.value;
  }
  filteringLoadTime(event:any){
    this.filtering_load_time = event.target.value;
  }


  pcList(){
    try{

      this.rest.pcList().subscribe((res: any) => {
        if(res.success){
          this.pc_details = res.result;
          // console.log("this.pc_details",this.pc_details)
          this.total_pc_code = this.pc_details.length;
        }
      })
    }
    
    catch(e){
      console.log(e);
    }
  }
  pmList(){
    try{

      this.rest.pmList().subscribe((res: any) => {
        if(res.success){
          this.pm_details = res.result;
          for(let i =0;i<this.pm_details.length;i++){
            this.pm_codes = this.pm_details[i]
            this.pm_codes = this.pm_codes.PM_CODE
            this.all_pm_codes.push(this.pm_codes)
          }

        }
      })
    }
    
    catch(e){
      console.log(e);
    }
  }

  addMaster(){

    try{

      let data = {

        "pm_code"       :       this.selected_pm_code,
        "pc_code"       :       this.pc_code,
        "resource"      :       this.resource,
        "min_temp"      :       this.min_temp,
        "max_temp"      :       this.max_temp,
        "max_temp_6_4"  :       this.max_temp_6_4,
        "min_temp_6_4"  :       this.min_temp_6_4,
        "pressing_time" :       this.pressing_time,
        "loadtime"      :       this.load_time

      }

      this.rest.addPcMaster(data).subscribe((res: any) => {
      if(res.success){
        this.toastr.success('Pc details added', 'Success', {timeOut: 4000});
        setTimeout(()=>{
          this.dialog.closeAll();
          this.pcList()
        },2000)

      }
      

    })

    }catch(e){
      console.log(e);
    }
  }

  updateMaster(){
    try{



      let data = {
        "pc_code"       :this.pre_pc_code,
        "resource"      :this.pre_resource_name,
        "pm_code"       :this.pre_selected_pm_code,
        "min_temp"      :this.pre_min_temp,
        "max_temp"      :this.pre_max_temp,
        "max_temp_6_4"  :this.pre_max_temp_6_4,
        "min_temp_6_4"  :this.pre_min_temp_6_4,
        "pressing_time" :this.pre_pressing_time,
        "loadtime"      :this.pre_load_time,
        "id"            :this.row_id
      }
      // console.log("data >>>>",data)
      this.rest.updatePcMaster(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success(this.pre_pc_code+' details updated', 'Success', {timeOut: 4000});
          setTimeout(()=>{
            this.dialog.closeAll();
            this.pcList()
          },2000)

        }
      },(err:any)=>{
        // console.log("error response >>>>>>",err)
        this.toastr.error('Pc details not updated.', 'Error', {timeOut: 4000});
      })

    }catch(e){
      console.log(e);
    }

  }

  searchMaster(){
    try{

      let data = {
        "pc_code"       :this.filtering_pc_code,
        "resource"      :this.filtering_resource,
        "pm_code"       :this.filtering_selected_pm_code,
        "min_temp"      :this.filtering_min_temp,
        "max_temp"      :this.filtering_max_temp,
        "pressing_time" :this.filtering_pressing_time,
        "loadtime"      :this.filtering_load_time,
      }
      if(this.filtering_pc_code == "" && this.filtering_resource =="" && this.filtering_selected_pm_code =="" && this.filtering_min_temp =="" && this.filtering_max_temp =="" && this.filtering_pressing_time =="" && this.filtering_load_time ==""){
        this.toastr.error('Please fill any data to filter','Error', {timeOut: 4000});
      }
      else{
        this.rest.filterPc(data).subscribe((res: any) => {
        if(res.success){
         this.p=1
         this.pc_details = res.result;
         this.total_pc_code = this.pc_details.length;
         // this.toastr.success(this.filtering_pc_code+' Filtered Successfully.','Success', {timeOut: 4000});
         // this.dialog.closeAll();
         // this.p=1
         

         setTimeout(()=>{
            this.dialog.closeAll();

            if(this.filtering_pc_code!= '' && this.filtering_resource!= '' && this.filtering_selected_pm_code!= '' && this.filtering_min_temp!= '' && this.filtering_max_temp!= '' && this.filtering_pressing_time!= '' && this.filtering_load_time!= ''){
              this.toastr.success('PC details is filtered', 'Success', {timeOut: 4000});
            }

            else if(this.filtering_pc_code!= ''){
              this.toastr.success('PC details is filtered with PC Code - '+this.filtering_pc_code, 'Success', {timeOut: 4000});
            }

            else if(this.filtering_resource!= ''){
              this.toastr.success('PC details is filtered with Resource - '+this.filtering_resource, 'Success', {timeOut: 4000});
            }

            else if(this.filtering_selected_pm_code!= ''){
              this.toastr.success('PC details is filtered with PM Code - '+this.filtering_selected_pm_code, 'Success', {timeOut: 4000});
            }

            else if(this.filtering_min_temp!= ''){
              this.toastr.success('PC details is filtered with min temp - '+this.filtering_min_temp, 'Success', {timeOut: 4000});
            }

            else if(this.filtering_max_temp!= ''){
              this.toastr.success('PC details is filtered with max temp - '+this.filtering_max_temp, 'Success', {timeOut: 4000});
            }

            else if(this.filtering_pressing_time!= ''){
              this.toastr.success('PC details is filtered with pressing time - '+this.filtering_pressing_time, 'Success', {timeOut: 4000});
            }

            else if(this.filtering_load_time!= ''){
              this.toastr.success('PC details is filtered with load time - '+this.filtering_load_time, 'Success', {timeOut: 4000});
            }

            this.isFilterActive = !this.isFilterActive;
            this.filtering_pc_code="";
            this.filtering_resource="";
            this.filtering_selected_pm_code="";
            this.filtering_min_temp="";
            this.filtering_max_temp="";
            this.filtering_pressing_time="";
            this.filtering_load_time="";

          },2000)
        }
  },(err:any)=>{
        this.toastr.error('PC details not updated.', 'Error', {timeOut: 4000});
      })
      }
      

    }catch(e){
      console.log(e);
    }

  }


  editPcDetails(press:any,i:any){
    this.row_id = this.pc_details[i]['id']
    this.pre_resource_name = this.pc_details[i]['RESOUCE'];
    this.pre_pc_code = this.pc_details[i]['pc_code'];
    this.pre_selected_pm_code = this.pc_details[i]['pm_code'];
    this.pre_min_temp = this.pc_details[i]['min_temp'];
    this.pre_max_temp = this.pc_details[i]['max_temp'];
    this.pre_max_temp_6_4 = this.pc_details[i]['max_temp_6_4'];
    this.pre_min_temp_6_4 = this.pc_details[i]['min_temp_6_4'];
    this.pre_pressing_time = this.pc_details[i]['pressing_time'];
    this.pre_load_time = this.pc_details[i]['loadtime'];
    
    const dialogRef = this.dialog.open(this.editDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  viewPcDetails(press:any,i:any){
    this.pre_resource_name = this.pc_details[i]['RESOUCE'];
    this.pre_pc_code = this.pc_details[i]['pc_code'];
    this.pre_selected_pm_code = this.pc_details[i]['pm_code'];
    this.pre_min_temp = this.pc_details[i]['min_temp'];
    this.pre_max_temp = this.pc_details[i]['max_temp'];
    this.pre_max_temp_6_4 = this.pc_details[i]['max_temp_6_4'];
    this.pre_min_temp_6_4 = this.pc_details[i]['min_temp_6_4'];
    this.pre_pressing_time = this.pc_details[i]['pressing_time'];
    this.pre_load_time = this.pc_details[i]['loadtime'];
    // console.log("pre_selected_pm_code===>",this.pre_selected_pm_code)
    const dialogRef = this.dialog.open(this.viewDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }
    


  openConfirmationModal(press:any,i:any){
    this.pc_code_id = i+1 ;
    this.pc_code_index = i;
    this.pc_code_details_id =this.pc_details[i]['id']
    try{

      const dialogRef = this.dialog.open(this.deleteDialog, {
      width: '25%',
      height: '35%',
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });

    }catch(e){
      console.log(e);
    }

    
  }

  submitForm(){
    
    try{
      let data = {
        "id": this.pc_code_details_id
      }
      // console.log("====>",data)

      this.rest.deletePc(data).subscribe((res: any) => {
        if(res.success){
          this.p=1
          this.toastr.success(this.pre_pc_code+' has been deleted', 'Success', {timeOut: 4000});
          this.pc_details.splice(this.pc_code_index,1);
          this.dialog.closeAll();
          this.pcList()
        }
      },(err:any)=>{
        this.toastr.error(this.pre_pc_code+' is not deleted', 'Error', {timeOut: 4000});
      })

    }catch(e){
      console.log(e);
    }

    
  }


}