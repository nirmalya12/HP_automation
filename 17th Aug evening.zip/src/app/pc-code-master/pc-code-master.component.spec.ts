import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PcCodeMasterComponent } from './pc-code-master.component';

describe('PcCodeMasterComponent', () => {
  let component: PcCodeMasterComponent;
  let fixture: ComponentFixture<PcCodeMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PcCodeMasterComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PcCodeMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
