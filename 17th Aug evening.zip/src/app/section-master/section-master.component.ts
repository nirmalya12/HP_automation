import { Component, ViewChild, TemplateRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { RestApiService } from '../rest-api.service';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-section-master',
  templateUrl: './section-master.component.html',
  styleUrl: './section-master.component.css'
})
export class SectionMasterComponent {
  @ViewChild('formDialog') formDialog!: TemplateRef<any>;
  @ViewChild('editDialog') editDialog!: TemplateRef<any>;
  @ViewChild('viewDialog') viewDialog!: TemplateRef<any>;
  @ViewChild('filterDialog') filterDialog!: TemplateRef<any>;
  @ViewChild('deleteDialog') deleteDialog!: TemplateRef<any>;


  constructor(public dialog: MatDialog, private rest: RestApiService, private toastr: ToastrService){}

  public pre_section_name         : String = '';
  public pre_section_code         : String = '';
  public pre_division_code        : String = '';
  public section_name             : String = "";
  public section_code             : String = "";
  public division_code            : String = "";
  public row_id                   : String = "";
  public filtering_section_name   : String = "";
  public filtering_section_code   : String = "";
  public filtering_division_code  : String = "";
  public section_id               : String = "";
  public section_details_id       : String = "";
  public section_details                   = [];
  public pm_master_deatils                 = [];
  public pc_master_deatils                 = [];
  public total_section            : number = 0;
  public p                        : number = 1;
  public isFilterActive           : boolean= false;
  public section_id_index              : any;


  ngOnInit(): void {
    this.sectionList()
  }
  
  openFormDialog(): void {
    const dialogRef = this.dialog.open(this.formDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  inactive(): void {
    this.isFilterActive = false;
    this.sectionList()
    
  }

  openFilterDialog(): void {
    const dialogRef = this.dialog.open(this.filterDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  onNoClick(): void {
    this.dialog.closeAll();
  }

  sectionName(event:any){
    this.section_name = event.target.value;
  }

  filteringSectionName(event:any){
    this.filtering_section_name = event.target.value;
  }

  sectionCode(event:any){
    this.section_code = event.target.value;
  }

  filteringSectionCode(event:any){
    this.filtering_section_code = event.target.value;
    console.log("this.filtering_section_code >>>>>>",this.filtering_section_code)
  }

  divisionCode(event:any){
    this.division_code = event.target.value;
  }

  filteringDivisionCode(event:any){
    this.filtering_division_code = event.target.value;
  }

  sectionList(){
    try{

      this.rest.sectionList().subscribe((res: any) => {
        if(res.success){
          this.section_details = res.result;
          this.total_section = this.section_details.length;
        }
      })
    }
    
    catch(e){
      console.log(e);
    }
  }

  addMaster(){

    try{

      let data = {

        "DM_CODE" :           this.division_code,
        "SM_NAME" :           this.section_name,
        "SM_CODE" :           this.section_code,

      }
      this.rest.addSectionMaster(data).subscribe((res: any) => {
      if(res.success){
        this.toastr.success('Section details added', 'Success', {timeOut: 4000});
        setTimeout(()=>{
          this.dialog.closeAll();
          this.sectionList()
        },2000)
      }
    })

    }catch(e){
      console.log(e);
    }
  }

  updateMaster(){
    try{

      let data = {

        "DM_CODE" :this.division_code,
        "SM_NAME" :this.section_name,
        "SM_CODE" :this.section_code,        
        "id"      :this.row_id

      }
      this.rest.updateSectionMaster(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success('Section - '+this.pre_section_name+' details updated', 'Success', {timeOut: 4000});
          setTimeout(()=>{
            this.dialog.closeAll();
            this.sectionList()
          },2000)
        }
      },(err:any)=>{
        this.toastr.error('Section details not updated.', 'Error', {timeOut: 4000});
      })

    }catch(e){
      console.log(e);
    }

  }

  searchMaster(){
    try{

      let data = {

        "DM_CODE" :this.filtering_division_code,
        "SM_NAME" :this.filtering_section_name,
        "SM_CODE" :this.filtering_section_code,        
       
      }
      if(this.filtering_division_code == "" && this.filtering_section_name == "" && this.filtering_section_code == ""){
        this.toastr.error('Please fill any data to filter','Error', {timeOut: 4000});
      }
      else{
        this.rest.filterSection(data).subscribe((res: any) => {
        if(res.success){
          this.p = 1;
          this.section_details = res.result;
          this.total_section = this.section_details.length;

          setTimeout(()=>{
            this.dialog.closeAll();

            if(this.filtering_division_code!= '' && this.filtering_section_name!= '' && this.filtering_section_code!= ''){
              this.toastr.success('Section details is filtered', 'Success', {timeOut: 4000});
            }

            else if(this.filtering_division_code!= ''){
              this.toastr.success('Section details is filtered with division Code - '+this.filtering_division_code, 'Success', {timeOut: 4000});
            }

            else if(this.filtering_section_name!= ''){
              this.toastr.success('Section details is filtered with section name - '+this.filtering_section_name, 'Success', {timeOut: 4000});
            }

            else if(this.filtering_section_code!= ''){
              this.toastr.success('Section details is filtered with section code - '+this.filtering_section_code, 'Success', {timeOut: 4000});
            }

            this.isFilterActive = !this.isFilterActive;
            this.filtering_division_code = ''
            this.filtering_section_name = ''
            this.filtering_section_code = ''
            // this.division_code="";
            // this.section_name="";
            // this.section_code="";

          },2000)
          
        }
      },(err:any)=>{
        this.toastr.error('section details not updated.', 'Error', {timeOut: 4000});
      })
      }

    }catch(e){
      console.log(e);
    }

  }


  editSectionDetails(press:any,i:any){

    this.row_id = this.section_details[i]['id']
    this.pre_section_name = this.section_details[i]['SM_NAME'];
    this.pre_section_code = this.section_details[i]['SM_CODE'];    
    this.pre_division_code = this.section_details[i]['DM_CODE'];

    const dialogRef = this.dialog.open(this.editDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  viewSectionDetails(press:any,i:any){

    this.pre_section_name = this.section_details[i]['SM_NAME'];
    this.pre_section_code = this.section_details[i]['SM_CODE'];    
    this.pre_division_code = this.section_details[i]['DM_CODE'];

    const dialogRef = this.dialog.open(this.viewDialog, {
      width: '25%',
      height: '100%',
      position: { right: '0' },
      panelClass: 'custom-dialog-container'
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }
    


  deleteSection(press:any,i:any){
    try{

      let data = {
        "id": this.section_details[i]['id']
      }

      this.rest.deleteSection(data).subscribe((res: any) => {
        if(res.success){
          this.toastr.success('Section - '+this.pre_section_name+' has been deleted', 'Success', {timeOut: 4000});
          this.section_details.splice(i,1);
        }
      },(err:any)=>{
        this.toastr.error('Section -'+this.pre_section_name+' is not deleted', 'Error', {timeOut: 4000});
      })



    }catch(e){
      console.log(e);
    }

    
  }

  openConfirmationModal(press:any,i:any){
    this.section_id = i+1 ;
    this.section_id_index = i;
    this.section_details_id =this.section_details[i]['id']
    // console.log("this.section_id",this.section_id)
    try{

      const dialogRef = this.dialog.open(this.deleteDialog, {
      width: '25%',
      height: '35%',
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
    }catch(e){
      console.log(e);
    }

    
  }

    submitForm(){
    try{

      let data = {
        "id": this.section_details_id
      }

      this.rest.deleteSection(data).subscribe((res: any) => {
        if(res.success){
          this.p=1
          this.toastr.success(this.pre_section_name+' has been deleted', 'Success', {timeOut: 4000});
          this.section_details.splice(this.section_id_index,1);
          this.dialog.closeAll();
          this.sectionList()
        }
      },(err:any)=>{
        this.toastr.error(this.pre_section_name+' is not deleted', 'Error', {timeOut: 4000});
      })



    }catch(e){
      console.log(e);
    }

    
  }
}



