import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PmCodeMasterComponent } from './pm-code-master.component';

describe('PmCodeMasterComponent', () => {
  let component: PmCodeMasterComponent;
  let fixture: ComponentFixture<PmCodeMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PmCodeMasterComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PmCodeMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
