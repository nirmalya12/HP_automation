import { Component, EventEmitter, OnInit, Output, inject } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { RestApiService } from '../rest-api.service';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {

  @Output() sideNavToggled = new EventEmitter<boolean>();
  menustatus : boolean = false;

  public userShortname : string = '';
  private RestApiService = inject(RestApiService);

  constructor(private router : Router, private toastr : ToastrService){}

  ngOnInit(){
    // If we define a string variable with capital 'S' as String then we have to use below -
    // this.userShortname = localStorage.getItem('username' || '{}')

    // =========== when we define a string variable with small 's' as string then we can use following -
    const storedUsername = localStorage.getItem('username') || '';
    this.userShortname = this.capitalizeFirstLetter(storedUsername);
    console.log("this.userShortname >>>>>>>",this.userShortname)

  }


  capitalizeFirstLetter(text: string): string {
    if (!text) return '';
    return text.charAt(0).toUpperCase();
    // return text.charAt(0).toUpperCase() + text.slice(1);
  }

  sideNavToggle(){
    this.menustatus = !this.menustatus;
    this.sideNavToggled.emit(this.menustatus);
    this.RestApiService.changeProfile(this.menustatus);
  }

  logout(){
    try{
      this.router.navigate(['']);
      this.toastr.success("You've been logged out","Success", {timeOut:4000})
      localStorage.setItem('isloggedIn','false');
    }catch(e){
      console.log("logout err ",e)
    }
    
  }

}
