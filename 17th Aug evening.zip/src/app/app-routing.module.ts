import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { InfoComponent } from './info/info.component';
import { HotpressMasterComponent } from './hotpress-master/hotpress-master.component';
import { ChangeDateShiftComponent } from './change-date-shift/change-date-shift.component';
import { ShiftMasterComponent } from './shift-master/shift-master.component';
import { DepartmentMasterComponent } from './department-master/department-master.component';
import { UserMasterComponent } from './user-master/user-master.component';
import { DivisionMasterComponent } from './division-master/division-master.component';
import { PcCodeMasterComponent } from './pc-code-master/pc-code-master.component';
import { PmCodeMasterComponent } from './pm-code-master/pm-code-master.component';
import { SectionMasterComponent } from './section-master/section-master.component';
import { EmployeeMasterComponent } from './employee-master/employee-master.component';
import { authGuard } from './auth.guard';


const routes: Routes = [

{path:'', component:LoginComponent},
{path:'settings', component:InfoComponent},
{path:'hotpress-details', component:HotpressMasterComponent},
{path:'dashboard', component:DashboardComponent, canActivate:[authGuard]},
{path:'change-date-shift', component:ChangeDateShiftComponent},
{path:'shift-details', component:ShiftMasterComponent},
{path:'department-details', component:DepartmentMasterComponent},
{path:'user-details', component:UserMasterComponent},
{path:'division-details', component:DivisionMasterComponent},
{path:'pc-details', component:PcCodeMasterComponent},
{path:'pm-details', component:PmCodeMasterComponent},
{path:'section-details', component:SectionMasterComponent},
{path:'employee-details', component:EmployeeMasterComponent},
{path: '', redirectTo: '/dashboard', pathMatch: 'full' }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
