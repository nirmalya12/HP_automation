import { Component } from '@angular/core';
import { RouterOutlet, NavigationEnd, Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'HP_Automation';


  isLoginPage: boolean = false;
  sideNavStatus : boolean = false;


  constructor(private router: Router) {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.isLoginPage = this.router.url === '/';
      }
    });
  }


}
