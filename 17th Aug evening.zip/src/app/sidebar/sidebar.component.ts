import { Component, Input, OnInit, inject } from '@angular/core';
import {ArrayDataSource} from '@angular/cdk/collections';
import {NestedTreeControl, CdkTreeModule} from '@angular/cdk/tree';
import { MatTreeNestedDataSource } from '@angular/material/tree';
import { RestApiService } from '../rest-api.service'

// interface CourseNode{
//   name: string,
//   icon?: string,
//   children?: CourseNode[];
// }

interface CourseNode{
  module_name: string;
  icon?: string;
  submodule_name: string;
  module_id?: string;
  submodules?: CourseNode[];
  module_path?: string;
  submodule_path?: string;
}

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.css'
})

export class SidebarComponent implements OnInit{
  @Input() sideNavStatus: boolean = false;
  isCollapsed = false;

  expandableImg: string = '<img src="../../assets/images/expandable.png" alt="expand">';
  collapsableImg: string = '<img src="../../assets/images/collapsable.png" alt="collapse">';

  public moduleList : CourseNode[] = [];
  private RestApiService = inject(RestApiService);
  private currentlyExpandedNode: CourseNode | null = null;

  constructor(private rest: RestApiService){}

  backIcon(event : any) {
    // console.log("EVENT >>>>>>>>",this.isCollapsed)
    this.isCollapsed = !this.isCollapsed;
  }

  // list = [

  //   {
  //     number: '1',
  //     name: 'Master',
  //     icon: 'fa-solid fa-house'
  //   },

  //   {
  //     number: '2',
  //     name: 'Production',
  //     icon: 'fa-solid fa-box'
  //   },

  //   {
  //     number: '3',
  //     name: 'Report',
  //     icon: 'fa-solid fa-chart-line'
  //   },

  //   {
  //     number: '4',
  //     name: 'Settings',
  //     icon: 'fa-solid fa-gear'
  //   }

  // ]

//   public TREE_DATA: CourseNode[] = [
//   {
//     name: 'Fruit',
//     icon: 'fa-solid fa-house',
//     children: [{name: 'Apple'}, {name: 'Banana'}, {name: 'Fruit loops'}],
//   },
//   {
//     name: 'Vegetables',
//     icon: 'fa-solid fa-box',
//     children: [
//       {
//         name: 'Green',
//         children: [{name: 'Broccoli'}, {name: 'Brussels sprouts'}],
//       },
//       {
//         name: 'Orange',
//         children: [{name: 'Pumpkins'}, {name: 'Carrots'}],
//       },
//     ],
//   },
// ];

  // nestedDataSource = new MatTreeNestedDataSource<CourseNode>();

  // // nestedTreeControl = new NestedTreeControl<CourseNode>(node => node.children);
  // nestedTreeControl = new NestedTreeControl<CourseNode>(node => node.submodules);

  nestedDataSource = new MatTreeNestedDataSource<CourseNode>();
  // nestedTreeControl = new NestedTreeControl<CourseNode>(node => node.submodules);
  nestedTreeControl = new NestedTreeControl<CourseNode>(node => node.submodules);
  // console.log("nestedTreeControl >>>>>",nestedTreeControl())

  ngOnInit() : void{
    this.RestApiService.currentProfile.subscribe(profile=>{
      console.log("sidebar profile >>>>>>",profile);

      if (profile) {
        // Collapse all nodes when profile is true
        this.nestedTreeControl.collapseAll();
      }
    })
    this.moduleDetails()
    // this.nestedDataSource.data = this.TREE_DATA;

  }


  // hasNestedChild = (_: number, node: CourseNode) => !!node.submodules && node.submodules.length > 0;
  hasNestedChild(index: number, node:CourseNode){
    return (node.submodules ?? []).length > 0
    // return (node.submodules ?? []).length > 0
  }


  moduleDetails(){
    try{

      let data = {
        "user_name":localStorage.getItem('username')
      }

      this.rest.specificUserModule(data).subscribe((res: any) => {
        if(res.success){
          console.log("module res >>>>>>>>>>>",res)
          this.moduleList = res.result;
          this.nestedDataSource.data = this.moduleList;
          // nestedTreeControl = new NestedTreeControl<CourseNode>(node => node.children);
        }
        
        },(err:any)=>{
          console.log("moduleDetails error >>>>>",err)
        })

    }catch(e){
      console.log("moduleDetails err >>>>",e)
    }
  }

  // getNodeLink(node: CourseNode): string {
  //   return node.module_path ? `/${node.module_path.toLowerCase()}` : `/${node.submodule_path.toLowerCase()}`;
  // }

  getNodeLink(node: CourseNode): string {
    const modulePath = node.module_path ? node.module_path.toLowerCase() : '';
    const submodulePath = node.submodule_path ? node.submodule_path.toLowerCase() : '';
    return `/${modulePath || submodulePath}`;
  }


  // toggleNode(node: CourseNode) {
  //   // if (this.currentlyExpandedNode && this.currentlyExpandedNode !== node) {
  //   //   // Collapse the currently expanded node
  //   //   this.nestedTreeControl.collapse(this.currentlyExpandedNode);
  //   // }

  //   // // Expand the clicked node
  //   // this.nestedTreeControl.toggle(node);

  //   // // Update the currently expanded node
  //   // if (this.nestedTreeControl.isExpanded(node)) {
  //   //   this.currentlyExpandedNode = node;
  //   // } else {
  //   //   this.currentlyExpandedNode = null;
  //   // }



  //   this.nestedTreeControl.dataNodes.forEach(n => {
  //     if (n !== node && this.nestedTreeControl.isExpanded(n)) {
  //       this.nestedTreeControl.collapse(n);
  //     }
  //   });

  //   // Expand or collapse the clicked node
  //   this.nestedTreeControl.toggle(node);

  //   // Update the currently expanded node
  //   this.currentlyExpandedNode = this.nestedTreeControl.isExpanded(node) ? node : null;
  // }

  // toggleNode(node: CourseNode) {
  //   // Check if there's a previously expanded node and collapse it
  //   if (this.currentlyExpandedNode && this.currentlyExpandedNode !== node) {
  //     this.collapseNodeAndChildren(this.currentlyExpandedNode);
  //   }

  //   // Toggle the current node
  //   this.nestedTreeControl.toggle(node);

  //   // Update the currently expanded node
  //   this.currentlyExpandedNode = this.nestedTreeControl.isExpanded(node) ? node : null;
  // }

  // collapseNodeAndChildren(node: CourseNode) {
  //   // Collapse the node itself
  //   this.nestedTreeControl.collapse(node);

  //   // Collapse all children of this node
  //   if (node.submodules) {
  //     node.submodules.forEach(child => this.collapseNodeAndChildren(child));
  //   }
  // }


  nodeClicked(node: CourseNode) {
    if (this.nestedTreeControl.isExpanded(node)) {
      let parent: CourseNode | null = null;

      let index = this.nestedTreeControl.dataNodes.findIndex((n) => n === node);

      for (let i = index; i >= 0; i--) {
        if (this.nestedTreeControl.getLevel(node) > this.nestedTreeControl.getLevel(this.nestedTreeControl.dataNodes[i])) {
          parent = this.nestedTreeControl.dataNodes[i];
          break;
        }
      }

      if (parent) {
        this.nestedTreeControl.collapseDescendants(parent);
        this.nestedTreeControl.expand(parent);
      } else {
        this.nestedTreeControl.collapseAll();
      }
      this.nestedTreeControl.expand(node);
    }

  }


}