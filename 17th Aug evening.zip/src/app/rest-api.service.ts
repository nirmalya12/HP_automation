import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders, HttpParams} from '@angular/common/http';
import { Observable , BehaviorSubject } from 'rxjs';

const httpOptions = {
    headers: new HttpHeaders({'Content-Type': 'application/json'})
};

@Injectable({
  providedIn: 'root'
})
export class RestApiService {

  private profileSource = new BehaviorSubject<any>(null);
  currentProfile = this.profileSource.asObservable();

  // public API_ROOT : String = 'http://192.168.7.126:5000/';
  // public API_ROOT : String = 'http://192.168.5.148:5000/';
  // public API_ROOT : String = 'http://192.168.15.184:5000/';
  public API_ROOT : String = 'https://marketing.srmb.co.in:6055/';

  constructor(private http: HttpClient) { }

  changeProfile(profile : any){
    console.log("profile 1>>>>>>",profile)
    this.profileSource.next(profile);
  }


  sign_in(data:any){
      return this.http.post(this.API_ROOT + 'login',data);
      // return this.http.post(this.API_ROOT + 'login_new',data);
  }

  get_pm_code_details(){
    return this.http.get(this.API_ROOT + 'plant_master');
  }

  get_di_code(){
    return this.http.get(this.API_ROOT + 'divisionMasterList');
  }

  get_department_details(data:any){
    return this.http.post(this.API_ROOT + 'departmentMasterList',data);
  }

  get_section_details(data:any){
    return this.http.post(this.API_ROOT + 'sectionMasterList',data);
  }

  get_machine_details(data:any){
    return this.http.post(this.API_ROOT + 'getMachineList',data);
  }

  get_resource_details(data:any){
    return this.http.post(this.API_ROOT + 'getResourceMasterList',data);
  }

  get_shift_details(data:any){
    return this.http.post(this.API_ROOT + 'getShiftMaster',data);
  }

  get_supervisor_master(){
    return this.http.get(this.API_ROOT + 'getSupervisorMaster')
  }

  get_operator_master(){
    return this.http.get(this.API_ROOT + 'getOperatoreMaster')
  }

  get_contractor_code(data:any){
    return this.http.post(this.API_ROOT + 'contractorMasterList',data)
  }

  updateResourceInfo(data:any){
    return this.http.post(this.API_ROOT + 'resorce_info',data)
  }

  // preResourceInfo(paramsObject:any): Observable<any>{
  //   const myHeaders = new HttpHeaders({
  //     'Content-Type': 'application/json'
  //   });

  //   let params1 = new HttpParams().set("user_name",localStorage.getItem('username') || '{}');
  //   for (const key in paramsObject) {
  //     if (paramsObject.hasOwnProperty(key)) {
  //       params1 = params1.set(key, paramsObject[key]);
  //     }
  //   }
  //   // return this.http.get(this.API_ROOT + 'resorce_info',{ params })
  //   return this.http.get(this.API_ROOT + 'resorce_info', {headers:myHeaders, params:params1})
  // }

  preResourceInfo(data:any){
    return this.http.post(this.API_ROOT + 'get_resource',data)
  }

  addHotPressMaster(data:any){
    return this.http.post(this.API_ROOT + 'hotpress_master',data)
  }

  hotPressList(){
    return this.http.get(this.API_ROOT + 'get_hotpress')
  }

  updateHotPressMaster(data:any){
    return this.http.put(this.API_ROOT + 'hotpress_master',data)
  }
  
  deleteHotPress(data:any){
    return this.http.post(this.API_ROOT + 'delete_hotpress',data)
  }

  filterHotPress(data:any){
    return this.http.post(this.API_ROOT + 'get_hotpress',data)
  }

  getSearchMaster(data:any){
    return this.http.post(this.API_ROOT + 'getHpHeaderDetails',data)
  }

  transferShiftDetails(data:any){
    return this.http.post(this.API_ROOT + 'updateHpHeader',data)
  }

  getShiftMasterDetails(){
    return this.http.get(this.API_ROOT + 'getShiftMasterdata')
  }

  filterShiftDetails(data:any){
    return this.http.post(this.API_ROOT + 'getShiftMasterdata',data)
  }

  addShiftMaster(data:any){
    return this.http.post(this.API_ROOT + 'add_update_shift_master',data)
  }

  updateShiftMaster(data:any){
    return this.http.put(this.API_ROOT + 'add_update_shift_master',data)
  }

  deleteShift(data:any){
    return this.http.post(this.API_ROOT + 'delete_shift',data)
  }

  getDepartmentDetails(){
    return this.http.get(this.API_ROOT + 'get_department_master')
  }

  filterDepartmentDetails(data:any){
    return this.http.post(this.API_ROOT + 'get_department_master',data)
  }

  addDepartmentMaster(data:any){
    return this.http.post(this.API_ROOT + 'dmcode_add_update',data)
  }
  
  updateDepartmentMaster(data:any){
    return this.http.put(this.API_ROOT + 'dmcode_add_update',data)
  }

  deleteDepartment(data:any){
    return this.http.post(this.API_ROOT + 'delete_department',data)
  }

  createUser(data:any){
    return this.http.post(this.API_ROOT + 'create_user',data)
  }

  updateUserDetails(data:any){
    return this.http.put(this.API_ROOT + 'create_user',data)
  }

  getUserDetails(){
    return this.http.get(this.API_ROOT + 'get_user')
  }

  filterUserDetails(data:any){
    return this.http.post(this.API_ROOT + 'get_user',data)
  }

  deleteUserDetails(data:any){
    return this.http.post(this.API_ROOT + 'delete_user',data)
  }

  userModuleAccess(data:any){
    return this.http.post(this.API_ROOT + 'user_module',data)
  }

  getModuleDetails(){
    return this.http.get(this.API_ROOT + 'getmodule')
  }

  specificUserModule(data:any){
    return this.http.post(this.API_ROOT + 'get_user_specific_module',data)
  }

// ========================== these APIs can be matched with Koushik ======================
  getDivisionDetails(){
    return this.http.get(this.API_ROOT + 'get_division') 
  }

  getPMDetails(){
    return this.http.get(this.API_ROOT + 'get_pmcode')
  }

// =============================================================================================


// ============================== Division Master =======================================

  divisionList(){
    return this.http.get(this.API_ROOT + 'get_division')
  }
  addDivisionMaster(data:any){
    return this.http.post(this.API_ROOT + 'division_master',data)
  }
  updateDivisionMaster(data:any){
    return this.http.put(this.API_ROOT + 'division_master',data)
  }
  deleteDivision(data:any){
    return this.http.post(this.API_ROOT + 'delete_division',data)
  }
  filterDivision(data:any){
    return this.http.post(this.API_ROOT + 'get_division',data)
  }

// ========================================================================================


// ======================= PC Master =====================================================

  pcList(){
    return this.http.get(this.API_ROOT + 'get_pccode_master')
  }
  addPcMaster(data:any){
    return this.http.post(this.API_ROOT + 'pccode_master',data)
  }
  updatePcMaster(data:any){
    return this.http.put(this.API_ROOT + 'pccode_master',data)
  }
  deletePc(data:any){
    return this.http.post(this.API_ROOT + 'delete_pccode',data)
  }
  filterPc(data:any){
    return this.http.post(this.API_ROOT + 'get_pccode_master',data)
  }

// =======================================================================================

// ================================ PM Master ===========================================

  pmList(){
    return this.http.get(this.API_ROOT + 'get_pmcode')
  }
  addPmMaster(data:any){
    return this.http.post(this.API_ROOT + 'pm_code_master',data)
  }
  updatePmMaster(data:any){
    return this.http.put(this.API_ROOT + 'pm_code_master',data)
  }
  deletePm(data:any){
    return this.http.post(this.API_ROOT + 'delete_pmcode',data)
  }
  filterPm(data:any){
    return this.http.post(this.API_ROOT + 'get_pmcode',data)
  }

// ======================================================================================

// ============================ Section Master ==========================================

  sectionList(){
    return this.http.get(this.API_ROOT + 'get_smcode_master')
  }
  addSectionMaster(data:any){
    return this.http.post(this.API_ROOT + 'sccode_add_update',data)
  }
  updateSectionMaster(data:any){
    return this.http.put(this.API_ROOT + 'sccode_add_update',data)
  }
  deleteSection(data:any){
    return this.http.post(this.API_ROOT + 'delete_smcode',data)
  }
  filterSection(data:any){
    return this.http.post(this.API_ROOT + 'get_smcode_master',data)
  }

// ======================================================================================

// ========================= employee Master ===========================================

  employeeList(){
    return this.http.get(this.API_ROOT + 'get_employee_master')
  }
  addEmployeeMaster(data:any){
    return this.http.post(this.API_ROOT + 'employee_add_update',data)
  }
  updateEmployeeMaster(data:any){
    return this.http.put(this.API_ROOT + 'employee_add_update',data)
  }
  deleteEmployee(data:any){
    return this.http.post(this.API_ROOT + 'delete_employee',data)
  }
  filterEmployee(data:any){
    return this.http.post(this.API_ROOT + 'get_employee_master',data)
  }

// =====================================================================================


}
