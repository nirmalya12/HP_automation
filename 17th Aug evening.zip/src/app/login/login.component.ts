import { Component } from '@angular/core';
import {Router} from '@angular/router';
import {RestApiService} from '../rest-api.service';
import { ToastrService } from 'ngx-toastr';
import { PlatformLocation } from '@angular/common';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {


  public username : String = '';
  public password : String = '';
  public companyCode : String = '';

  constructor(private router: Router, private rest: RestApiService, private toastr: ToastrService, private platformLocation : PlatformLocation) { 

    history.pushState(null,'',location.href);
    this.platformLocation.onPopState(()=>{
      history.pushState(null,'',location.href);
    });
  }

  // ngOnInit(){
  //   localStorage.setItem('isloggedIn', "false")
  // }

  signIn(event: Event) {

  try{

      event.preventDefault();
      var errCounter  = 0;
      var emailreg =  RegExp(
      /^[a-zA-Z0-9.!#$%&’+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)$/);
      
      if (this.username.trim() === '' || this.password === '') {
        errCounter++;
      }
     
      if(errCounter==0){
        const data = {
          user_name: this.username,
          password: this.password
        };
        this.rest.sign_in(data).subscribe((res:any)=>{
          console.log("=========>",res)
          if(res.success){
            console.log(res)
            // alert('Valid Username & password')
            // localStorage.setItem('userName',res.response.name)
            // localStorage.setItem('userId',res.response.id)
            // localStorage.setItem('roleId',res.response.roleId)
            // localStorage.setItem('companyId',res.response.companyId)
            localStorage.setItem('username',String(this.username));
            localStorage.setItem('isloggedIn', "true");
            
            this.toastr.success(res['message'], 'Welcome', {timeOut: 1000});
            setTimeout(()=>{
              this.router.navigate(['/settings']);
            },2000)

          }
          else{
            localStorage.setItem('isloggedIn', "false");
          }
        },(err:any)=>{
          this.toastr.error('Invalid Credentials !!', 'Sorry', {timeOut: 5000});
        })
      }
      
    }

    catch(e){
      console.log("signIn error >>>>",e)
    }
      

  } 

   

}
